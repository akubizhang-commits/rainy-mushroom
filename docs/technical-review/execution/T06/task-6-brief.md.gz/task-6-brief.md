# T06 本地实施与验收边界

已有 root 实施：scripts/cocos/release-assets.mjs、tests/release-assets.test.mjs、release/asset-policy.json（后者目前被gitignore，应明确放行或force add）。12/12专项；实际380→378文件，129023940→119979319 bytes，所有保留path/type/UUID已和旧构建config核对。旧构建因包含排除UUID被正确拒绝。stage源保留，实际临时副本路径见task-6-inventory.json。

仍需实现：构建集成、策略加入T01输入、实际新构建UUID/内容验证、逻辑分组共享给T07并输出报告。原图/历史付费源全部保留；只过滤两张PNG和各自meta。禁止物理删原资源/重采样/改分辨率/删除既有VFX。

建议构建路径：显式 --staged-assets 生成新的干净Creator项目副本，原Web/微信预览默认行为保留用于前后对照。fingerprint增加resourcePolicy=all|reviewed并把asset-policy.json存在性和内容加入输入；不能让同一指纹同时声称包含/排除资源。有效config使用绝对buildPath输出原repo隔离目标，Creator --project指向stage；完成后验证全部stage输入和resources config（typed path+UUID），再包装/转换/stamp。仅通过后拷贝asset-release.json manifest；Tap中间包在转换前验证，游戏ZIP仍由T03校验。保留临时stage用于证据，不清理用户原项目。

新runtimeSelectionDigest锁所有脚本/场景/Prefab内容，仅排除明确生成的布尔TowerBuildCapabilities.ts及meta；QA和production都能用同一资产审计。其他源码变化必须重新审查，再显式更新reviewedRuntimeDigest，不能每次build自动刷新。T04只加capability不会改变路径；T07只加QA采样需检查无新加载资源后更新策略。

需要意义明确的测试：已含hash/meta/path/duplicate/replacement/symlink/currentruntime变更/retainedbytes/typedUUID/旧UUID泄漏/实际audio-clip。补充构建flag、策略指纹变化、stage映射检验失败没有stamp、QA/production一致资源。纯逻辑resourceGroup应移到共享js/xianxia模块并由builder和QA trace共同读取，不要双份维护。

可完成部分是精确发行清单+逻辑分组+加载trace。当前buildBattle仍全量预载高阶VFX；未验证全部技能动态切换下的加载时序前，不为了下载数减少而让首个技能缺帧。实体bundle/CDN与真实Tap限额仍待账号，因此T06最终只能标本地部分完成、整体待验收，不宣称达到平台包体限制。
