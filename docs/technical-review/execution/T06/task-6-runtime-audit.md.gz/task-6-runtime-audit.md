# Runtime policy audit

T07 adds bounded QA frame/resource diagnostics, wraps existing load callbacks and persistence/simulation/draw calls, and imports the pure resource grouping function. No new dynamic resource path or asset-selection branch is introduced. Production capability still disables collector creation. The full script/scene/prefab digest was refreshed manually after this review: d4e1be1b4cffb4cc5830581524763d1279c5b8e2676a1e135dbb43ffe5615cc1.

Generated shared TowerResourceGroups.ts has a deterministic UUID meta. No retained resource or metadata bytes changed. Original excluded files remain in source; release-stage copy omits exactly the two reviewed old PNGs and their meta.

Re-review after platform lifecycle correction: TowerView.hide/shown now only notify the existing sampler; no resource selection changes. New digest: 28595c5a737f788f344f393f6d262b00e64e71f93a89b2f5ad177acc27409d7d.

Final UI re-review: TowerMenu restores an existing HP label binding; TowerView moves the pause hit target with equal opposite visual offset. No resource paths, textures, or loading branches changed. Digest: 15ebddf504de9abd0f3c8dccc33b1170f9c1c8bf59d305284af7e6ca1729c8b0.

Deferred-destruction fix review: TowerView.render only reactivates children still valid under strict pending-destroy semantics. It introduces no resource paths or loading branches, and preserves valid children's restoration. The host test's mock and new regression select no runtime assets. Refreshed digest: ea59163e13c7cbc4d930a4da2bea3d1e433d93819234687dfcbb7736ca78c979.
