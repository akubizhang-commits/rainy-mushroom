# T05 实际资源调用点审计

此清单覆盖当前顶层脚本中的 `resources.load(` 源码调用点；循环/动态路径运行时可能展开为多个请求。函数内注释不计数。音频路径保持原有非阻塞策略。

所有未显式声明 `rollback` / `retryable` 的绑定 **不得原地重播**。一旦异常逸出回调，阻塞批次保持失败：Web 完整页面重载；无已确认重启能力的平台要求关闭游戏后重新打开。不能只销毁宿主，因为部分旧回调在登记 owner 前已有局部分配。

| 文件 | 源码行 | 本次策略／既有内部处理 |
|---|---|---|
| `cocos-pilot/assets/scripts/BumieAuraArt.ts` | 11 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/ConvergenceArt.ts` | 16 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/CrossBurstArt.ts` | 16 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/FlightStreamArt.ts` | 12 | 本次接入 rollback：失败销毁全部已登记帧/纹理并释放消费者图片引用，允许原地重试。 |
| `cocos-pilot/assets/scripts/FlightSwordArt.ts` | 9 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/JianguAuraArt.ts` | 12 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/JianxinAuraArt.ts` | 11 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/LiangyiFormationArt.ts` | 37 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/NingshenAuraArt.ts` | 11 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/OrbitSwordArt.ts` | 32, 98 | 既有内部 catch 清理并使用几何回退（32/98）；未逸出的异常不由队列重新判定。逸出异常无原地重试。 |
| `cocos-pilot/assets/scripts/QingpingAudio.ts` | 8 | AudioClip 可选项直通；缺失不阻塞画面，既有 error/dead 检查保留。 |
| `cocos-pilot/assets/scripts/SixiangFormationArt.ts` | 37 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/SwordArcArt.ts` | 30 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/SwordBurstArt.ts` | 13, 14 | 图片无原地重试契约，抛错要求完整重启；AudioClip 独立可选直通。 |
| `cocos-pilot/assets/scripts/SwordLineArt.ts` | 31, 41 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/SwordQiArt.ts` | 36 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/SwordShadowArt.ts` | 23 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/SwordTiandiArt.ts` | 35, 49, 57 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerBreakthroughArt.ts` | 23 | 加载回调只持有图片；draw/create 另有既有 catch/release/false 的绘制回退，属于队列之外。 |
| `cocos-pilot/assets/scripts/TowerBreakthroughAudio.ts` | 6 | AudioClip 可选项直通；缺失不阻塞画面，既有 error/dead 检查保留。 |
| `cocos-pilot/assets/scripts/TowerBreathArt.ts` | 16 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerChainArt.ts` | 16 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerCharacterArt.ts` | 223, 322, 327, 356, 360 | held 装备切片无契约，抛错完整重启；主/施法 atlas prepare 内既有 catch/release/failed 后回退。 |
| `cocos-pilot/assets/scripts/TowerCoreArt.ts` | 17 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerCrystalArt.ts` | 17 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerEggArt.ts` | 17 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerEnvironmentArt.ts` | 13 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerFallingRockArt.ts` | 16 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerLibraryPanel.ts` | 258 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerLightningArt.ts` | 16 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerLoadingScreen.ts` | 60 | 本次接入 rollback：移除部分 spriteFrame，销毁帧/纹理并释放消费者图片引用，允许原地重试。 |
| `cocos-pilot/assets/scripts/TowerMenu.ts` | 973 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerMiasmaArt.ts` | 16 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerMonsterArt.ts` | 72, 159, 298, 303, 308 | 静态图 finish 与动作 prepare 既有 catch/release 后返回回退；逸出异常完整重启。 |
| `cocos-pilot/assets/scripts/TowerPillarArt.ts` | 17 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerPlayerHud.ts` | 186, 203 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerProjectileArt.ts` | 89 | 既有 catch 销毁帧/纹理/图片并保留 shaped fallback；逸出异常完整重启。 |
| `cocos-pilot/assets/scripts/TowerResources.ts` | 7, 18 | 基础适配：队列 transport 与无会话/AudioClip 直通，不是 Art 绑定。 |
| `cocos-pilot/assets/scripts/TowerSafeSealArt.ts` | 16 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerSectScene.ts` | 87 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerShockwaveArt.ts` | 14 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerSkillIcons.ts` | 73 | finish 既有 catch/release；保留原文字图标回退，逸出异常完整重启。 |
| `cocos-pilot/assets/scripts/TowerSpiderWebArt.ts` | 16 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |
| `cocos-pilot/assets/scripts/TowerStoneArt.ts` | 28 | finish 既有 catch/release；保留原几何拾取物回退，逸出异常完整重启。 |
| `cocos-pilot/assets/scripts/TowerWindbladeArt.ts` | 16 | 未声明原地重试契约；绑定逸出异常标为需完整重启，绝不重播这个失败回调。 |

## 内部回退边界

`TowerCharacterArt.prepare/release`、`TowerMonsterArt.finish/prepareMotion`、`TowerSkillIcons.finish`、`TowerStoneArt.finish`、`TowerProjectileArt` 与 `OrbitSwordArt` 已有内部错误处理并保留几何、文字或静态回退；这些函数正常返回，因此不是本次修复的“异常逸出后仍标 ready”。本次不删除或扩大回退，也不把这些回退等同于验收画质。资源下载失败仍按阻塞三次自动重试/手动重试处理，不会因为这些回调有 fallback 就放过下载错误。

内部回退无法从队列外推证明全部视觉内容完整；如后续要求 GPU 构造失败也必须硬阻断，需要单独改变这些旧返回合同并做真实视觉验收。当前任务只改变未捕获绑定异常的完成/恢复语义，不宣称覆盖这一额外合同。

## 不可采用仅重建宿主的证据

`TowerEnvironmentArt.ts:13` 附近在加入 `loaded` 前构造 Texture/Frame；`TowerCharacterArt.ts:223` 附近在加入 `heldArt` 前构造切片；`CrossBurstArt.ts:16` 与 `ConvergenceArt.ts:16` 也有延后登记。它们的中途异常可能让正常 destroy 无法找到局部对象，因此不能标注 `retryable:true`，也不能以宿主重建代替完整运行环境重启。

## 本次可重试的实际回调

- `FlightStreamArt`：先登记纹理和每个帧，再设置可抛错属性；rollback 释放全部已登记内容。第13帧注入异常后，13帧与纹理全部销毁，图片仅剩队列1引用；重试后恰有32帧且图片2引用（队列+Art）；销毁后归零。
- `TowerLoadingScreen`：纹理上传或第1帧属性设置失败均清理；成功后再由正常界面生命周期释放。保留已下载图片，不额外请求或重复增加队列引用。
- cleanup 本身抛错：不可再原地重试，转完整重启；`retryable:true` 只允许已证明本身事务化的同步回调，当前生产调用点没有使用裸该选项。
