export const SCREEN = Object.freeze({
  HOME: 'home',
  ROUTES: 'routes',
  EXPLORE: 'explore',
  IDENTIFY: 'identify',
  DECIDE: 'decide',
  RESULT: 'result',
  COLLECTION: 'collection',
  GUIDE: 'guide'
})

export const SAVE_KEY = 'rainy-mushroom-profile-v1'
export const PROFILE_VERSION = 1

export const THEME = Object.freeze({
  ink: '#19352f',
  muted: '#688078',
  paper: '#f7f3e8',
  paperDeep: '#eee6d4',
  moss: '#527a58',
  mossDark: '#315343',
  mint: '#b9d8b4',
  rain: '#7ca5aa',
  amber: '#d79b51',
  coral: '#d67462',
  white: '#fffdf7',
  shadow: 'rgba(21, 48, 40, 0.16)'
})

export const TOOLS = Object.freeze([
  {
    id: 'lens',
    name: '雨纹镜',
    icon: '镜',
    description: '第一次观察直接获得两条线索'
  },
  {
    id: 'sampleBox',
    name: '软苔盒',
    icon: '盒',
    description: '每次采集额外获得 4 枚护林券'
  },
  {
    id: 'tracker',
    name: '寻菌铃',
    icon: '铃',
    description: '优先遇见路线内尚未目击的菌物'
  }
])

export const WEATHERS = Object.freeze([
  { id: 'drizzle', name: '细雨初歇', hint: '腐竹背阴面格外湿润', humidity: 78 },
  { id: 'mist', name: '竹海薄雾', hint: '微光和轮廓更容易被看见', humidity: 84 },
  { id: 'sunbreak', name: '云隙见光', hint: '林缘菌物舒展了菌盖', humidity: 68 },
  { id: 'nightRain', name: '昨夜急雨', hint: '低洼落叶间积满雨珠', humidity: 91 }
])

export const DECISIONS = Object.freeze([
  { id: 'photo', label: '拍照记录', detail: '+1 券，+1 研究点', tone: 'rain' },
  { id: 'collect', label: '采成熟体', detail: '+6 券，生态 -3', tone: 'amber' },
  { id: 'leave', label: '留种观察', detail: '+2 研究点，生态 +3', tone: 'moss' }
])

export const clamp = (value, min, max) => Math.max(min, Math.min(max, value))
