// Approved v3 poses, scaled from the 158px preview actor to the 108px game actor.
// Simulation time only: pause, restore and replay cannot move these swords.
const SCALE = 108 / 158
const TAU = Math.PI * 2
const clamp = (x, a, b) => Math.max(a, Math.min(b, x))
const ease = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x) }
const POSES = [
  [[[70,-126],[108,-191],[144,-104],[180,-159],[214,-216]],
    [[72,-174],[110,-102],[147,-211],[182,-144],[216,-187]]],
  [[[76,-181],[112,-111],[149,-206],[185,-142],[221,-103]],
    [[70,-116],[107,-194],[143,-142],[180,-90],[216,-218]]],
  [Array.from({length:5}, (_,r) => [64+30*r,-121-12*r-2*r*r]),
    Array.from({length:5}, (_,r) => [64+30*r,-121-12*r-2*r*r])],
]
export const YUJIAN_LENGTH = 64 * SCALE
export const YUJIAN_TAIL = .25
export function yujianHoverPose(index, time, center) {
  const side = index % 2, rank = Math.floor(index / 2), q = ((time % 18) + 18) % 18
  const phase = q < 7 ? 0 : q < 14 ? 1 : 2
  const local = phase === 0 ? q : phase === 1 ? q - 7 : q - 14
  const u = ease((local - (phase === 2 ? 1 : 4) - rank*.1 - side*.04) / 2.5)
  const a = POSES[phase][side][rank], b = POSES[(phase+1)%3][side][rank]
  const x = a[0] + (b[0]-a[0])*u + 7*Math.sin(Math.PI*u) + Math.sin(time*1.25+index*.8)
  const y = a[1] + (b[1]-a[1])*u + 4*Math.sin(Math.PI*u) + 2.1*Math.sin(time*1.6+index*.7)
  return { x: center.x + (side ? 1 : -1)*x*SCALE, y: center.y - y*SCALE }
}
export function newYujianState(player, time) {
  const face = player.faceX < 0 ? -1 : 1, angle = face < 0 ? Math.PI : 0
  return {version:1, face, from:angle, to:angle, at:time, x:player.x, y:player.y}
}
export function yujianHeading(state, time) {
  return state.from + (state.to-state.from)*ease((time-state.at)/.32)
}
export function turnYujian(state, face, time) {
  face = face < 0 ? -1 : 1
  if (face === state.face) return
  const current = yujianHeading(state,time), desired = face < 0 ? Math.PI : 0
  state.from = current
  state.to = current + Math.atan2(Math.sin(desired-current),Math.cos(desired-current))
  state.face = face; state.at = time
  // Keep angles bounded through arbitrarily many turns without a visual jump.
  if (Math.abs(state.from)>TAU*2) {
    const offset = Math.round(state.from/TAU)*TAU
    state.from-=offset; state.to-=offset
  }
}
export function validYujianState(state, time) {
  return state === undefined || state?.version===1 && [-1,1].includes(state.face)
    && ['from','to','at','x','y'].every(k=>Number.isFinite(state[k]))
    && state.at>=0 && state.at<=time && Math.abs(state.to-state.from)<=Math.PI+1e-8
}
export function validYujianShot(p) {
  if (p.yujianSlot === undefined) return true
  return p.source==='sj_yujian' && !p.hostile && Number.isInteger(p.yujianSlot)
    && p.yujianSlot>=0 && p.yujianSlot<10 && [-1,1].includes(p.launchFace)
    && ['gatherAt','flightAt','hoverX','hoverY','hoverAngle'].every(k=>Number.isFinite(p[k]))
    && p.gatherAt>=0 && p.flightAt>=p.gatherAt
    && (p.dissolveAt===null || Number.isFinite(p.dissolveAt))
    && Array.isArray(p.trail) && p.trail.length<=24
    && p.trail.every(a=>['x','y','angle','at'].every(k=>Number.isFinite(a[k])))
}
// Changes velocity only. TowerRun owns swept movement, walls and one-hit damage.
export function stepYujianFlight(shot, target, time, dt) {
  if (time < shot.flightAt + .12) {
    shot.vx=shot.launchFace*680; shot.vy=0; return
  }
  if (!target || target.hp<=0) return
  const distance=Math.hypot(target.x-shot.x,target.y-shot.y)
  const current=Math.atan2(shot.vy,shot.vx)
  const bend=distance<32?0:(shot.yujianSlot%2 ? 1 : -1)*.45*clamp(1-(time-shot.flightAt)/.65,0,1)
  const desired=Math.atan2(target.y-shot.y,target.x-shot.x)+bend
  const delta=Math.atan2(Math.sin(desired-current),Math.cos(desired-current))
  const speed=clamp(distance*6,180,680)
  // Tighten the turn as the target approaches: a fixed turning radius can orbit
  // small enemies forever. Terminal guidance also prevents circling at contact.
  const turn=Math.max(8,speed/Math.max(8,distance*.45))*dt
  const angle=distance<32?desired:current+clamp(delta,-turn,turn)
  shot.vx=Math.cos(angle)*speed; shot.vy=Math.sin(angle)*speed
}
export function yujianVisualPose(shot,time) {
  if (time<shot.flightAt) {
    const u=ease((time-shot.gatherAt)/Math.max(.001,shot.flightAt-shot.gatherAt))
    const v=1-u, end={x:shot.x,y:shot.y+46}
    const highY=Math.max(shot.hoverY,end.y)+38
    const c1={x:shot.hoverX,y:highY}, c2={x:end.x-shot.launchFace*38,y:end.y}
    const x=v*v*v*shot.hoverX+3*v*v*u*c1.x+3*v*u*u*c2.x+u*u*u*end.x
    const y=v*v*v*shot.hoverY+3*v*v*u*c1.y+3*v*u*u*c2.y+u*u*u*end.y
    const dx=3*v*v*(c1.x-shot.hoverX)+6*v*u*(c2.x-c1.x)+3*u*u*(end.x-c2.x)
    const dy=3*v*v*(c1.y-shot.hoverY)+6*v*u*(c2.y-c1.y)+3*u*u*(end.y-c2.y)
    const tangent=Math.hypot(dx,dy)>.01?Math.atan2(dy,dx):shot.hoverAngle
    const delta=Math.atan2(Math.sin(tangent-shot.hoverAngle),Math.cos(tangent-shot.hoverAngle))
    return {x,y,angle:shot.hoverAngle+delta*ease(u*4)}
  }
  return {x:shot.x,y:shot.y+Math.max(14,46-(time-shot.flightAt)*60),
    angle:Math.atan2(shot.vy,shot.vx)}
}
