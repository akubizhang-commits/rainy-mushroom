// Fixed-step, JSON-only monster controllers. All damage is authored enemy damage,
// never a fraction of the current player's HP. Cooldowns start after recovery.
import { ARCHETYPES, FLOOR01 } from './TowerContent.js'
import { insideHex, clipHexRay } from './TowerArena.js'
import { clearPillars, clipPillars, pillarSight } from './TowerObstacles.js'
import { towerEnemyStats } from './TowerEnemyStats.js'
const STEP=1/60, EPS=1e-7, TAU=Math.PI*2
const archetypes=new Map(ARCHETYPES.map(a=>[a.id,a]))
const rows=[
 ['镜魄分身',20,30,2,1.5,2],['血怒狂暴',0,0,1,1.5,0],['汲灵回生',25,35,2,1.5,2],
 ['岩甲蛰伏',0,0,1,1.5,2],['号令群妖',15,25,3,2.2,2],['裂岩冲锋',6,8,0,1.3,2],
 ['裂地重踏',8,10,0,1.5,2],['回旋尾扫',6,8,0,1.2,2],['撼岳掀浪',12,14,0,1.5,2.5],
 ['缚足蛛网',10,15,0,1.3,2.2],['寒瘴泥沼',12,18,4,1.5,1],['毒痕追猎',18,22,3,2,2],
 ['落雷点名',10,12,0,1.5,1.5],['连环落石',15,20,4,1.2,3],['环形震波',18,20,4,1.8,2.5],
 ['摆首妖息',15,20,4,2,3],['风刃封侧',12,16,0,1.5,2],['狱锁禁锢',20,25,2,1.8,2],
 ['六门避劫',30,35,2,3,4],['引兽破阵',0,0,1,1.3,2],['镇妖破甲阵',0,0,1,1.5,0],
 ['噬灵妖卵',20,25,3,1.5,2],['妖核暴露',0,0,0,0,4],['濒死绝唱',0,0,1,3,4]
]
export const MONSTER_SKILLS=Object.freeze(Object.fromEntries(rows.map((r,i)=>{
 const id=`M${String(i+1).padStart(2,'0')}`;return [id,Object.freeze({id,name:r[0],first:r[1],cooldown:r[2],limit:r[3],windup:r[4],recovery:r[5]})]
})))
export const BOSS_MECHANIC_LOADOUTS=Object.freeze([
 ['M06','M02'],['M01','M05'],['M10','M22','M11'],['M08','M12','M02'],
 ['M03','M16','M11'],['M04','M07','M09'],['M20','M06','M07'],['M19','M15','M05'],['M06','M01','M19','M02']
].map(Object.freeze))
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y)
const count=(s,id,kind)=>s.enemies.filter(e=>e.hp>0&&e.temporary?.ownerId===id&&(!kind||e.temporary.kind===kind)).length
const ELITE_SKILLS=Object.freeze({boar:'M06',wolf:'M05',spider:'M10',crocodile:'M08',bear:'M02'})
const TEMP_RATIOS=Object.freeze({clone:[.22,.25],core:[.016,0],crystal:[.016,0],pillar:[.035,0],egg:[.016,0],lock:[.012,0]})
const objectives=new Set(['core','crystal','pillar','egg','lock'])
const finite=Number.isFinite
const positive=n=>finite(n)&&n>=0
function state(run){return run.state.monsterMechanics}
export function initializeMonsterMechanics(run,e){
 if(!state(run)||e.temporary||!['boss','elite'].includes(e.role)||e.mechanic)return
 const elite=ELITE_SKILLS
 const skills=e.role==='boss'?[...BOSS_MECHANIC_LOADOUTS[run.state.floor-1]]:[elite[e.family]||'M07']
 e.mechanic={version:1,skills,phase:'idle',skillId:'',label:'',enraged:false,spawnedAt:run.state.time,
  startedAt:0,activatesAt:0,until:0,cooldowns:Object.fromEntries(skills.map(id=>[id,run.state.time+MONSTER_SKILLS[id].first])),
  uses:Object.fromEntries(skills.map(id=>[id,0])),vulnerableUntil:0,vulnerability:0,healed:0,healBudget:0,
  batch:0,rewardedBatch:0,armorUntil:0,armor:0,nextPulseAt:0,pulses:0,chargeX:e.x,chargeY:e.y,spawnPoints:[],healRemaining:0,setupUntil:0,chargeStarted:false}
}
function legal(s,p,r=24){return (!s.view||(p.x-r>=s.view.xmin&&p.x+r<=s.view.xmax&&p.y-r>=s.view.ymin&&p.y+r<=s.view.ymax))
 &&(s.arenaVersion!==1?(p.x-r>=-912&&p.x+r<=978&&p.y-r>=-1140&&p.y+r<=1020):insideHex(p,r)&&clearPillars(p,r))}
function spot(s,origin,r=100,index=0,reserved=[]){
 for(let i=0;i<16;i++){const a=(i+index*3)*TAU/16,p={x:origin.x+Math.cos(a)*r,y:origin.y+Math.sin(a)*r}
  if(reserved.every(q=>dist(p,q)>65)&&legal(s,p)&& (s.arenaVersion!==1||pillarSight(origin,p)) && s.enemies.every(e=>e.hp<=0||dist(p,e)>e.radius+30))return p}
 return null
}
function zone(run,e,id,extra={}){
 const s=run.state,m=e.mechanic,k=MONSTER_SKILLS[id],z={id:`mechanic:${++state(run).sequence}`,ownerId:e.id,skillId:id,name:k.name,
  shape:'circle',x:e.x,y:e.y,radius:90,width:64,toX:e.x,toY:e.y,faceX:1,faceY:0,angle:Math.PI,innerRadius:0,safeZones:[],
  phase:'windup',startedAt:s.time,activatesAt:m.activatesAt,expiresAt:m.activatesAt+.2,damage:e.damage*1.8,
  hit:false,nextAt:m.activatesAt,interval:0,control:null,...extra};state(run).zones.push(z);return z
}
function cleanupActorEffects(s,actors){
 const ids=new Set(actors.map(e=>e.id));if(!ids.size)return
 s.zones=(s.zones||[]).filter(z=>!ids.has(z.ownerId)&&!actors.some(e=>typeof z.source==='string'&&z.source.startsWith(`${e.id}:a`)))
 s.projectiles=(s.projectiles||[]).filter(p=>!p.hostile||!actors.some(e=>typeof p.source==='string'&&p.source.startsWith(`${e.id}:a`)))
}
function removeZones(run,e){state(run).zones=state(run).zones.filter(z=>z.ownerId!==e.id)}
function reward(run,e,seconds=4,amount=.15){const m=e.mechanic;if(m.skillId==='M20')m.cooldowns.M06=run.state.time+seconds+8;if(m.skillId&&m.skillId!=='M23')m.cooldowns[m.skillId]=run.state.time+seconds+MONSTER_SKILLS[m.skillId].cooldown;m.vulnerableUntil=Math.max(m.vulnerableUntil,run.state.time+seconds);m.vulnerability=Math.max(m.vulnerability,amount);m.armor=0;m.armorUntil=0;m.phase='recovery';m.skillId='M23';m.until=m.vulnerableUntil;m.label='妖核暴露';removeZones(run,e)}
function recover(run,e){const m=e.mechanic;m.phase='recovery';m.until=run.state.time+MONSTER_SKILLS[m.skillId].recovery}
function summon(run,e,kind,position,life=15){
 const s=run.state,m=e.mechanic,id=`temporary:${e.id}:${++state(run).sequence}`,archetype=archetypes.has(`${e.family}_normal`)?`${e.family}_normal`:'boar_normal'
 const a=run._enemy({id,archetype,x:position.x,y:position.y});delete a.mechanic
 const ratios=TEMP_RATIOS
 if(ratios[kind]){a.maxHp=Math.max(1,e.maxHp*ratios[kind][0]);a.damage=e.damage*ratios[kind][1]}
 else {a.maxHp*=.8;a.damage*=.65}
 a.hp=a.maxHp;a.moveSpeed=kind==='clone'?e.moveSpeed:objectives.has(kind)?0:a.moveSpeed
 a.name=({clone:'镜魄',core:'汲灵核',crystal:'护甲结晶',pillar:'破阵机关柱',egg:'噬灵妖卵',lock:'狱锁柱',minion:'召唤随从',hatchling:'妖卵幼体'})[kind]
 a.temporary={ownerId:e.id,kind,batch:m.batch,spawnedAt:s.time,expiresAt:s.time+life,baseHp:a.maxHp,baseDamage:a.damage,baseSpeed:a.moveSpeed}
 a.ai.readyAt=s.time+.8+(state(run).sequence%4)*.3;a.ai.graceUntil=a.ai.readyAt;s.enemies.push(a);return a
}
function spawnMany(run,e,kind,n,life){const s=run.state;for(let i=0;i<n;i++){const p=spot(s,objectives.has(kind)?s.player:e,objectives.has(kind)?85:140,i);if(p)summon(run,e,kind,p,life)}}
function direction(e,p){const d=dist(e,p)||1;return {x:(p.x-e.x)/d,y:(p.y-e.y)/d}}
function gates(s){const points=[];for(let i=0;i<6;i++){const a=i*TAU/6,p={x:s.player.x+Math.cos(a)*100,y:s.player.y+Math.sin(a)*100,radius:55};if(legal(s,p,55)&&(s.arenaVersion!==1||pillarSight(s.player,p)))points.push(p)}return points.slice(0,2)}
function prepareSpawns(s,e,id){
 const recipe={M01:[['clone',2,15]],M03:[['core',1,6]],M04:[['crystal',2,8],['minion',4,12]],M05:[['minion',e.role==='elite'?3:4,20]],M18:[['lock',1,4]],M22:[['egg',2,8]]}[id]||[]
 const points=[]
 for(const [kind,n,life] of recipe)for(let i=0;i<n;i++){
  const objective=objectives.has(kind),p=spot(s,objective?s.player:e,objective?85:150,i,points)
  if(!p)return null
  points.push({...p,kind,life})
 }
 return points
}
function releaseSpawns(run,e){for(const p of e.mechanic.spawnPoints)if(legal(run.state,p)&&dist(p,run.state.player)>run.state.player.radius+24)summon(run,e,p.kind,p,p.life);e.mechanic.spawnPoints=[]}
function warningSafe(run,e,zones){
 const s=run.state,m=e.mechanic,p=s.player
 for(const z of zones){if(z.damage<=0||z.shape==='safe-gates')continue
  if(s.view){const v=s.view,r=z.radius
   if(z.x-r<v.xmin||z.x+r>v.xmax||z.y-r<v.ymin||z.y+r>v.ymax)return false
   if(z.shape==='capsule'&&(z.toX-r<v.xmin||z.toX+r>v.xmax||z.toY-r<v.ymin||z.toY+r>v.ymax))return false
  }
 }
 if(!zones.some(z=>z.damage>0&&inZone(z,p)))return true
 let escape=Infinity
 for(let r=45;r<=225;r+=30)for(let i=0;i<16;i++){
  const a=i*TAU/16,q={x:p.x+Math.cos(a)*r,y:p.y+Math.sin(a)*r,radius:p.radius}
  if(!legal(s,q,p.radius)||zones.some(z=>z.damage>0&&inZone(z,q)))continue
  if(s.arenaVersion===1&&clipPillars(p,Math.cos(a),Math.sin(a),r,p.radius)<r-EPS)continue
  escape=Math.min(escape,r)
 }
 if(!finite(escape))return false
 const required=s.time+escape/Math.max(60,Math.min(150,p.moveSpeed||150))+.8
 if(required>m.activatesAt){const delay=required-m.activatesAt;m.activatesAt=required;m.until+=delay
  for(const z of zones){z.activatesAt+=delay;z.nextAt+=delay;z.expiresAt+=delay}}
 return true
}
function start(run,e,id){
 const s=run.state,m=e.mechanic,k=MONSTER_SKILLS[id],d=direction(e,s.player)
 const spawnPoints=prepareSpawns(s,e,id);if(!spawnPoints)return false
 const pillarPoint=id==='M20'?spot(s,s.player,110):null;if(id==='M20'&&!pillarPoint)return false
 if(['M19','M24'].includes(id)&&gates(s).length<2)return false
 let range=Math.min(320,Math.max(140,dist(e,s.player)+70))
 if(['M06','M09','M20'].includes(id)){
  if(s.arenaVersion===1)range=clipPillars(e,d.x,d.y,clipHexRay(e,d.x,d.y,range,e.radius),e.radius)
  if(range<80||!legal(s,{x:e.x+d.x*range,y:e.y+d.y*range},e.radius))return false
 }
 const before=JSON.parse(JSON.stringify(m)),firstZone=state(run).zones.length
 m.phase='windup';m.skillId=id;m.label=k.name;m.startedAt=s.time;m.activatesAt=s.time+k.windup;m.until=m.activatesAt;m.uses[id]++;m.batch++;m.pulses=0;m.spawnPoints=spawnPoints
 e.ai.attack=null;e.ai.mode='approach';e.ai.eligibleSince=-1
 const base={faceX:d.x,faceY:d.y}
 if(id==='M20'){
  m.phase='active';m.setupUntil=s.time+2;m.until=m.setupUntil;m.chargeStarted=false;m.armor=.5;m.armorUntil=s.time+10;m.label='护甲减伤50% · 将冲锋引向机关柱'
  summon(run,e,'pillar',pillarPoint,10)
  zone(run,e,id,{shape:'capsule',radius:4,width:8,toX:pillarPoint.x,toY:pillarPoint.y,damage:0,activatesAt:s.time,nextAt:s.time,expiresAt:m.setupUntil})
  return true
 }
 for(const p of spawnPoints)zone(run,e,id,{x:p.x,y:p.y,radius:24,damage:0,spawnKind:p.kind})
 if(['M06','M09','M20'].includes(id)){
  m.chargeX=e.x+d.x*range;m.chargeY=e.y+d.y*range
  zone(run,e,id,{...base,shape:'capsule',radius:e.radius+8,width:(e.radius+8)*2,toX:m.chargeX,toY:m.chargeY,expiresAt:m.activatesAt+range/560+.05,control:id==='M09'?{rootSeconds:.5}:null})
  if(id==='M20'){m.armor=.5;m.armorUntil=s.time+8;m.label='护甲减伤50% · 引兽撞柱';const p=spot(s,s.player,110);if(p)summon(run,e,'pillar',p,8)}
 }else if(['M07','M08','M16','M15'].includes(id)){
  const shape=id==='M07'?'circle':id==='M15'?'ring':'sector'
  zone(run,e,id,{...base,shape,radius:id==='M15'?200:145,innerRadius:0,angle:id==='M15'?Math.PI*1.5:Math.PI*1.2,expiresAt:m.activatesAt+(id==='M16'?3:id==='M15'?1:.2),damage:e.damage*(id==='M16'?.55:1.8),interval:id==='M16'?1:0,sweepHeading:Math.atan2(d.y,d.x),sweepDirection:1})
 }else if(['M10','M11','M13','M14'].includes(id)){
  zone(run,e,id,{...base,x:s.player.x,y:s.player.y,radius:id==='M11'?65:55,damage:e.damage*(id==='M10'?.65:id==='M11'?.12:id==='M14'?.75:1.8),
   expiresAt:m.activatesAt+(id==='M11'?6:.2),interval:id==='M11'?1:0,control:id==='M10'?{rootSeconds:.7}:id==='M11'?{slowFraction:.25,slowSeconds:.5}:null})
 }else if(id==='M17'){
  for(const sign of [-1,1])zone(run,e,id,{...base,shape:'capsule',x:e.x-d.y*110*sign,y:e.y+d.x*110*sign,toX:e.x+d.x*260-d.y*110*sign,toY:e.y+d.y*260+d.x*110*sign,radius:32,width:64,damage:e.damage*1.5})
 }else if(id==='M18'){
  zone(run,e,id,{...base,shape:'ring',x:s.player.x,y:s.player.y,radius:110,innerRadius:82,angle:Math.PI*1.5,expiresAt:m.activatesAt+4,damage:e.damage*.3,interval:1})
 }else if(['M19','M24'].includes(id)){
  const safeZones=gates(s);m.activatesAt=s.time+Math.max(k.windup,100/Math.max(60,s.player.moveSpeed||150)+.8)
  zone(run,e,id,{shape:'safe-gates',x:s.player.x,y:s.player.y,radius:2400,safeZones,activatesAt:m.activatesAt,nextAt:m.activatesAt,expiresAt:m.activatesAt+.2,damage:e.damage*3})
 }else if(id==='M21'){
  const p=spot(s,s.player,65);if(p)zone(run,e,id,{...p,radius:55,damage:0,expiresAt:m.activatesAt+8})
 }else zone(run,e,id,{radius:Math.min(100,e.radius+40),damage:0,expiresAt:m.activatesAt+.2})
 if(!warningSafe(run,e,state(run).zones.slice(firstZone))){state(run).zones.splice(firstZone);Object.assign(m,before);return false}
 return true
}
function eligible(run,e,id){
 const s=run.state,m=e.mechanic,k=MONSTER_SKILLS[id],hp=e.hp/e.maxHp
 if((k.limit&&m.uses[id]>=k.limit)||m.cooldowns[id]>s.time+EPS||id==='M23')return false
 if(e.role==='elite'&&id==='M05'&&m.uses[id]>=1)return false
 if(id==='M02')return hp<=.2&&!m.enraged
 if(id==='M04')return hp<=.6&&hp>.2
 if(id==='M20')return hp<=.65&&hp>.2
 if(id==='M21')return hp<=.5
 if(id==='M24')return hp<=.1
 if(id==='M03'&&(hp>=.75||hp<=.2||m.enraged||m.healed>=e.maxHp*.12))return false
 if(s.floor===3&&id==='M11'&&hp>.5)return false
 if(s.floor===9&&e.role==='boss'){
  if(['M01','M19'].includes(id)&&(hp>.6||hp<=.2))return false
  if(id==='M06'&&hp<=.6&&hp>.2)return false
 }
 if(['M19','M24'].includes(id)&&s.enemies.some(a=>a.hp>0&&a.ai.mode!=='approach'))return false
 if(['M01','M05','M22'].includes(id)&&count(s,e.id)>0)return false
 if(id==='M11'&&state(run).zones.some(z=>z.ownerId===e.id))return false
 return true
}
function resolveStart(run,e){
 const s=run.state,m=e.mechanic,id=m.skillId;m.phase='active'
 if(id==='M02'){m.enraged=true;if(s.floor===9)s.enemies=s.enemies.filter(a=>a.temporary?.ownerId!==e.id||a.temporary.kind!=='clone');recover(run,e)}
 else if(id==='M01'){releaseSpawns(run,e);recover(run,e)}
 else if(id==='M05'){releaseSpawns(run,e);recover(run,e)}
 else if(id==='M22'){releaseSpawns(run,e);recover(run,e)}
 else if(id==='M03'){
  removeZones(run,e);releaseSpawns(run,e);m.until=s.time+6;m.healBudget=Math.min(e.maxHp*.06,e.maxHp*.12-m.healed);m.healRemaining=m.healBudget
 }else if(id==='M04'){
  releaseSpawns(run,e);m.armor=.8;m.armorUntil=s.time+8;m.label='岩甲减伤80% · 击碎结晶';m.until=m.armorUntil
 }else if(id==='M18'){releaseSpawns(run,e);m.until=s.time+4}
 else if(id==='M12'){m.nextPulseAt=s.time;m.until=s.time+3}
 else if(id==='M14'){m.pulses=1;m.nextPulseAt=s.time+1.2;m.until=s.time+2.5}
 else if(id==='M16')m.until=s.time+3
 else if(['M06','M20'].includes(id))m.until=s.time+dist(e,{x:m.chargeX,y:m.chargeY})/560
 else if(id==='M21')m.until=s.time+8
 else recover(run,e)
}
function inZone(z,p){
 if(z.shape==='safe-gates')return !z.safeZones.some(q=>dist(q,p)<=q.radius-p.radius)
 if(z.shape==='capsule'){
  const dx=z.toX-z.x,dy=z.toY-z.y,t=Math.max(0,Math.min(1,((p.x-z.x)*dx+(p.y-z.y)*dy)/(dx*dx+dy*dy||1)))
  return Math.hypot(p.x-z.x-t*dx,p.y-z.y-t*dy)<=z.radius+p.radius
 }
 const d=dist(z,p);if(d>z.radius+p.radius)return false
 if(z.shape==='circle')return true
 if(z.shape==='ring'&&d+p.radius<z.innerRadius)return false
 const delta=Math.atan2(p.y-z.y,p.x-z.x)-Math.atan2(z.faceY,z.faceX)
 return Math.abs(Math.atan2(Math.sin(delta),Math.cos(delta)))<=z.angle/2+Math.asin(Math.min(1,p.radius/Math.max(p.radius,d)))
}
function tickZones(run,incoming){
 const s=run.state
 for(const z of state(run).zones){
  if(z.expiresAt<=s.time+EPS)continue
  const owner=s.enemies.find(e=>e.id===z.ownerId&&e.hp>0);if(!owner){z.expiresAt=s.time;continue}
  if(s.time+EPS<z.activatesAt)continue;z.phase='active'
  if(z.skillId==='M15'){z.radius=35+165*Math.min(1,s.time-z.activatesAt);z.innerRadius=Math.max(0,z.radius-45)}
  if(z.skillId==='M16'){const angle=z.sweepHeading-.35*Math.PI+.7*Math.PI*Math.min(1,(s.time-z.activatesAt)/3);z.faceX=Math.cos(angle);z.faceY=Math.sin(angle);z.angle=.5*Math.PI}
  if(z.skillId==='M11'&&inZone(z,s.player)&&s.monsterControl){s.monsterControl.slowUntil=Math.max(s.monsterControl.slowUntil,s.time+.5);s.monsterControl.slowFraction=Math.max(s.monsterControl.slowFraction,.25)}
  if(z.skillId==='M21'){
   const m=owner.mechanic;if(dist(z,s.player)<z.radius-s.player.radius)m.pulses=Math.min(90,m.pulses+1)
   if(m.pulses>=90&&dist(z,owner)<z.radius+owner.radius){reward(run,owner,6,.2);break}continue
  }
  if(z.damage<=0||s.time+EPS<z.nextAt||z.hit&&!z.interval)continue
  // Charge damage follows the moving body, not the entire future warning path.
  const hit=['M06','M20'].includes(z.skillId)?dist(owner,s.player)<=owner.radius+s.player.radius:inZone(z,s.player)
  if(hit&&(s.arenaVersion!==1||pillarSight(z,s.player))){
   if(!(['M07','M19','M24'].includes(z.skillId)&&s.monsterControl?.rootUntil>s.time))incoming.push({id:z.id,damage:z.damage,...(z.control?{control:z.control}:{})})
   z.hit=true
  }
  if(z.interval)z.nextAt=s.time+z.interval
 }
 state(run).zones=state(run).zones.filter(z=>z.expiresAt>s.time+EPS)
}
export function tickMonsterMechanics(run,incoming){
 const s=run.state;if(!state(run))return
 // Expiry is disappearance, never a combat kill or an economy event.
 const expired=s.enemies.filter(e=>e.temporary&&e.temporary.expiresAt<=s.time+EPS)
 for(const a of expired)if(a.temporary.kind==='egg'&&a.hp>0){const owner=s.enemies.find(e=>e.id===a.temporary.ownerId&&e.hp>0);if(owner&&count(s,owner.id,'hatchling')<4)spawnMany(run,owner,'hatchling',2,15)}
 cleanupActorEffects(s,expired)
 s.enemies=s.enemies.filter(e=>!e.temporary||e.temporary.expiresAt>s.time+EPS)
 for(const e of s.enemies){
  if(e.hp<=0||!e.mechanic)continue;const m=e.mechanic
  if(m.armorUntil<=s.time)m.armor=0
  if(m.phase==='windup'&&!run._visible(e)){removeZones(run,e);m.spawnPoints=[];recover(run,e)}
  if(m.phase==='windup'&&s.time+EPS>=m.activatesAt)resolveStart(run,e)
  if(m.phase==='active'){
   if(m.skillId==='M03'){
    if(e.hp/e.maxHp<=.2||!count(s,e.id,'core')){recover(run,e)}
    else {const heal=Math.min(m.healBudget/6*STEP,e.maxHp-e.hp,e.maxHp*.12-m.healed,m.healRemaining);e.hp+=heal;m.healed+=heal;m.healRemaining-=heal}
   }
   if(m.skillId==='M20'&&!m.chargeStarted&&s.time+EPS>=m.setupUntil){
    const d=direction(e,s.player);let range=Math.min(360,dist(e,s.player)+100)
    if(s.arenaVersion===1)range=clipPillars(e,d.x,d.y,clipHexRay(e,d.x,d.y,range,e.radius),e.radius)
    const target={x:e.x+d.x*range,y:e.y+d.y*range}
    if(range<80||!legal(s,target,e.radius)){m.armor=0;recover(run,e)}
    else {removeZones(run,e);m.chargeStarted=true;m.phase='windup';m.startedAt=s.time;m.activatesAt=s.time+1.3;m.until=m.activatesAt;m.armorUntil=s.time+8;m.chargeX=target.x;m.chargeY=target.y
     zone(run,e,'M20',{shape:'capsule',faceX:d.x,faceY:d.y,radius:e.radius+8,width:(e.radius+8)*2,toX:target.x,toY:target.y,expiresAt:m.activatesAt+range/560+.05})}
   }
   if((m.skillId==='M06'||m.skillId==='M20'&&m.chargeStarted)&&m.phase==='active'){
    const target={x:m.chargeX,y:m.chargeY},d=dist(e,target),step=Math.min(d,560*STEP);if(d){e.x+=(target.x-e.x)/d*step;e.y+=(target.y-e.y)/d*step}
    if(m.skillId==='M20'){const pillar=s.enemies.find(a=>a.temporary?.ownerId===e.id&&a.temporary.kind==='pillar'&&dist(a,e)<a.radius+e.radius+10)
     if(pillar){s.enemies=s.enemies.filter(a=>a!==pillar);reward(run,e,6,.2)}}
   }
   if(m.skillId==='M12'&&m.pulses<3&&s.time+EPS>=m.nextPulseAt){
    // Each new pool keeps its own full warning; the previous pools never move.
    zone(run,e,'M12',{x:s.player.x,y:s.player.y,radius:48,activatesAt:s.time+1,nextAt:s.time+1,expiresAt:s.time+6,damage:e.damage*.08,interval:1});m.pulses++;m.nextPulseAt=s.time+1
   }
   if(m.skillId==='M14'&&m.pulses<3&&s.time+EPS>=m.nextPulseAt){zone(run,e,'M14',{x:s.player.x,y:s.player.y,radius:55,activatesAt:s.time+1.2,nextAt:s.time+1.2,expiresAt:s.time+1.4,damage:e.damage*.75});m.pulses++;m.nextPulseAt=s.time+1.2;m.until=s.time+1.4}
   if(m.phase==='active'&&s.time+EPS>=m.until)recover(run,e)
  }
  if(m.phase==='recovery'&&s.time+EPS>=m.until){m.cooldowns[m.skillId]=s.time+MONSTER_SKILLS[m.skillId].cooldown;if(m.skillId==='M20')m.cooldowns.M06=s.time+8;m.phase='idle';m.skillId='';m.label='';state(run).nextMajorAt=Math.max(state(run).nextMajorAt,s.time+.5)}
 }
 tickZones(run,incoming)
 if(s.time<state(run).nextMajorAt||s.monsterControl?.rootUntil+1.5>s.time)return
 if(s.enemies.some(e=>e.hp>0&&e.mechanic&&['windup','active','recovery'].includes(e.mechanic.phase)))return
 if(state(run).zones.length||(s.projectiles||[]).some(p=>p.hostile)||(s.zones||[]).some(z=>z.hostile&&!z.renderOnly))return
 for(const e of s.enemies){if(e.hp<=0||!e.mechanic||e.mechanic.phase!=='idle'||e.ai.mode!=='approach'||s.time<e.ai.entryUntil||!run._visible(e))continue
  const skills=[...e.mechanic.skills].sort((a,b)=>(a==='M02'?-1:b==='M02'?1:0))
  for(const id of skills)if(eligible(run,e,id)&&start(run,e,id))return
 }
}
export function monsterDamageMultiplier(run,e){const m=e.mechanic;if(!m)return 1;return (m.armorUntil>run.state.time?1-m.armor:1)*(m.vulnerableUntil>run.state.time?1+Math.min(.2,m.vulnerability):1)}
export function monsterMovementMultiplier(run,e){return e.mechanic?.enraged?1.25:1}
export function monsterAttackSpec(run,e,spec){if(!spec)return spec;if(e.mechanic?.skills.includes('M06')&&spec.kind==='charge'||e.mechanic?.skills.includes('M10')&&spec.kind==='web')return null;return e.mechanic?.enraged?{...spec,cooldown:(spec.cooldown||0)*.75}:spec}
export function monsterMechanicsBlocks(run,e){
 if(e.temporary&&objectives.has(e.temporary.kind))return true
 if(e.mechanic&&e.mechanic.phase!=='idle'&&!(e.mechanic.skillId==='M21'&&e.mechanic.phase==='active'))return true
 return !!state(run)?.zones.some(z=>['M19','M24'].includes(z.skillId))
}
export function targetPriority(run,e){return e.temporary&&objectives.has(e.temporary.kind)&&dist(e,run.state.player)<=150?0:1}
export function onMonsterDeaths(run,dead){
 if(!state(run))return;const s=run.state
 for(const e of dead){
  if(e.mechanic){removeZones(run,e);cleanupActorEffects(s,[e,...s.enemies.filter(a=>a.temporary?.ownerId===e.id)]);s.enemies=s.enemies.filter(a=>a.temporary?.ownerId!==e.id);continue}
  const t=e.temporary;if(!t)continue;cleanupActorEffects(s,[e]);const owner=s.enemies.find(a=>a.id===t.ownerId&&a.hp>0);if(!owner)continue
  const m=owner.mechanic
  if(t.kind==='lock'){removeZones(run,owner);recover(run,owner)}
  if(t.batch===m.rewardedBatch)continue
  if(t.kind==='core'||t.kind==='crystal'&&!count(s,owner.id,'crystal')||t.kind==='clone'&&!count(s,owner.id,'clone')){
   m.rewardedBatch=t.batch;reward(run,owner,t.kind==='crystal'?6:4,t.kind==='crystal'?.2:.15)
  }
 }
}
const onlyKeys=(o,keys)=>!!o&&typeof o==='object'&&!Array.isArray(o)&&Object.keys(o).every(k=>keys.includes(k))
const MECHANIC_KEYS='version skills phase skillId label enraged spawnedAt startedAt activatesAt until cooldowns uses vulnerableUntil vulnerability healed healBudget batch rewardedBatch armorUntil armor nextPulseAt pulses chargeX chargeY spawnPoints healRemaining setupUntil chargeStarted'.split(' ')
const ZONE_KEYS='id ownerId skillId name shape x y radius width toX toY faceX faceY angle innerRadius safeZones phase startedAt activatesAt expiresAt damage hit nextAt interval control spawnKind sweepHeading sweepDirection'.split(' ')
export function validateMonsterMechanics(s){
 const mm=s.monsterMechanics;if(!mm)return !s.enemies.some(e=>e.mechanic||e.temporary)
 if(!onlyKeys(mm,['version','zones','sequence','nextMajorAt'])||mm.version!==1||!Array.isArray(mm.zones)||!Number.isSafeInteger(mm.sequence)||mm.sequence<0||!positive(mm.nextMajorAt)||mm.zones.length>32)return false
 const ids=new Set(),owners=new Map(s.enemies.filter(e=>e.mechanic&&!e.temporary).map(e=>[e.id,e]))
 for(const e of s.enemies){
  if(!e.temporary&&['boss','elite'].includes(e.role)&&!e.mechanic)return false
  if(e.mechanic){const m=e.mechanic;if(!onlyKeys(m,MECHANIC_KEYS)||m.version!==1||!['boss','elite'].includes(e.role)||!Array.isArray(m.skills)||!m.skills.length||new Set(m.skills).size!==m.skills.length||m.skills.some(id=>!MONSTER_SKILLS[id])
   ||JSON.stringify(m.skills)!==JSON.stringify(e.role==='boss'?BOSS_MECHANIC_LOADOUTS[s.floor-1]:[ELITE_SKILLS[e.family]||'M07'])
   ||!['idle','windup','active','recovery'].includes(m.phase)||typeof m.enraged!=='boolean'||typeof m.chargeStarted!=='boolean'||typeof m.label!=='string'||(m.phase==='idle'?m.skillId!=='':!m.skills.includes(m.skillId)&&m.skillId!=='M23')
   ||!['spawnedAt','startedAt','activatesAt','until','vulnerableUntil','vulnerability','healed','healBudget','batch','rewardedBatch','armorUntil','armor','nextPulseAt','pulses','healRemaining','setupUntil'].every(k=>positive(m[k]))
   ||!Array.isArray(m.spawnPoints)||m.spawnPoints.some(p=>!finite(p.x)||!finite(p.y)||!positive(p.life)||!['clone','core','crystal','minion','lock','egg'].includes(p.kind))
   ||!finite(m.chargeX)||!finite(m.chargeY)||m.vulnerability>.2||m.armor>.8||m.healed>e.maxHp*.12+EPS||m.healBudget>e.maxHp*.06+EPS||m.rewardedBatch>m.batch
   ||!Number.isSafeInteger(m.batch)||!Number.isSafeInteger(m.rewardedBatch)||!m.cooldowns||!m.uses)return false
   for(const id of m.skills){if(!positive(m.cooldowns[id])||!Number.isSafeInteger(m.uses[id])||m.uses[id]<0||MONSTER_SKILLS[id].limit&&m.uses[id]>MONSTER_SKILLS[id].limit)return false}
  }
  if(e.temporary){const t=e.temporary,o=owners.get(t.ownerId);if(!o||e.mechanic||!['clone','minion','core','crystal','pillar','egg','hatchling','lock'].includes(t.kind)||!Number.isSafeInteger(t.batch)||t.batch<1||t.batch>o.mechanic.batch
   ||!positive(t.spawnedAt)||t.spawnedAt>s.time+EPS||!finite(t.expiresAt)||t.expiresAt<=s.time-EPS||t.expiresAt<t.spawnedAt||!archetypes.has(e.archetype)
   ||!onlyKeys(t,['ownerId','kind','batch','spawnedAt','expiresAt','baseHp','baseDamage','baseSpeed'])
   ||!positive(t.baseHp)||t.baseHp===0||!positive(t.baseDamage)||!positive(t.baseSpeed)||e.maxHp!==t.baseHp||e.damage!==t.baseDamage||e.moveSpeed!==t.baseSpeed
   ||!finite(e.hp)||e.hp<=0||e.hp>e.maxHp||!finite(e.x)||!finite(e.y)||!positive(e.radius)||e.radius>100||!e.ai||!['approach','windup','active','recovery'].includes(e.ai.mode)
   ||!['readyAt','graceUntil','until','entryUntil','sequence','offset'].every(k=>finite(e.ai[k]))||!['woundBudget','woundUntil','orbitNextAt'].every(k=>positive(e[k]))
   ||s.arenaVersion===1&&!insideHex(e,e.radius))return false
   const ratio=TEMP_RATIOS[t.kind],base=towerEnemyStats(archetypes.get(e.archetype),s.floor,s.wave)
   const hp=ratio?Math.max(1,o.maxHp*ratio[0]):base.hp*.8,damage=ratio?o.damage*ratio[1]:base.damage*.65
   const speed=t.kind==='clone'?o.moveSpeed:objectives.has(t.kind)?0:base.moveSpeed
   if(e.maxHp!==hp||e.damage!==damage||e.moveSpeed!==speed||e.family!==e.archetype.split('_')[0]||e.role!=='normal'||e.rank!==archetypes.get(e.archetype).rank)return false
   const life=t.expiresAt-t.spawnedAt,limits={clone:15,core:6,crystal:8,pillar:10,egg:8,lock:4,minion:20,hatchling:15}
   if(life>limits[t.kind]+EPS||life<=0)return false
  }
 }
 for(const z of mm.zones){if(!onlyKeys(z,ZONE_KEYS)||ids.has(z.id)||typeof z.id!=='string'||!owners.has(z.ownerId)||!MONSTER_SKILLS[z.skillId]||!['circle','sector','capsule','ring','safe-gates'].includes(z.shape)||!['windup','active'].includes(z.phase)
  ||!['x','y','toX','toY','faceX','faceY'].every(k=>finite(z[k]))||!['radius','width','angle','innerRadius','startedAt','activatesAt','expiresAt','damage','nextAt','interval'].every(k=>positive(z[k]))
  ||z.startedAt>s.time+EPS||z.activatesAt<z.startedAt||z.expiresAt<z.activatesAt||typeof z.hit!=='boolean'||!Array.isArray(z.safeZones)||z.safeZones.some(p=>!finite(p.x)||!finite(p.y)||!positive(p.radius))
  ||z.control!==null&&(!z.control||Object.entries(z.control).some(([k,v])=>!['rootSeconds','slowFraction','slowSeconds','knockbackX','knockbackY'].includes(k)||!finite(v))))return false;ids.add(z.id)}
 return true
}

// Checkpoint monotonicity is separate from structural validation: elapsed time may
// remove an actor, but cannot renew the same actor or refund a consumed mechanic.
export function validateMonsterMechanicsProgress(previous,next){
 const a=previous.monsterMechanics,b=next.monsterMechanics
 if(!a)return !b||validateMonsterMechanics(next)
 if(!b||b.version!==a.version||b.sequence<a.sequence||next.time<previous.time)return false
 const live=new Map(next.enemies.map(e=>[e.id,e]))
 for(const old of previous.enemies){const current=live.get(old.id);if(!current)continue
  if(old.mechanic){const p=old.mechanic,q=current.mechanic;if(!q||JSON.stringify(p.skills)!==JSON.stringify(q.skills)||p.spawnedAt!==q.spawnedAt
   ||q.healed+EPS<p.healed||q.batch<p.batch||q.rewardedBatch<p.rewardedBatch||p.enraged&&!q.enraged)return false
   for(const id of p.skills)if(q.uses[id]<p.uses[id])return false
  }
  if(old.temporary&&(JSON.stringify(old.temporary)!==JSON.stringify(current.temporary)||current.hp>old.hp+EPS))return false
 }
 return true
}
