import { initializeMonsterMechanics, tickMonsterMechanics, monsterDamageMultiplier, monsterMovementMultiplier, monsterAttackSpec, monsterMechanicsBlocks, onMonsterDeaths, validateMonsterMechanics, targetPriority } from './TowerMonsterMechanics.js'
import { isStarterEquipment, canUseEquipmentTier } from './TowerEquipmentTiers.js'
import {clearPillars,clipPillars,pillarSight,pushFromPillars,steerPillars} from './TowerObstacles.js'
import {demonEssenceXp} from './TowerEconomy.js'
import {towerKillXp} from './TowerCultivationRewards.js'
// Pure fixed-step combat. Everything which can affect the next tick is JSON in
// state; persistence/first-clear awards belong to TowerCampaign, never this file.
import { FLOORS, ARCHETYPES, SKILLS, EVOLUTIONS, FLOOR01, FLOOR01_BOSS } from './TowerContent.js'
import { cultivationAt, TOWER_XP_CAP } from './TowerProfile.js'
import { GROWTH_SKILLS, GROWTH_EVOLUTIONS, tutorialProgress } from './TowerGrowth.js'
import { buildCoreDropPlan, CORE_RANK_VALUES } from './TowerLoot.js'
import { insideHex, boundHexActor, clipHexRay } from './TowerArena.js'
import { enemyAttackSpec, enemyCombatStyle } from './TowerEnemyAttacks.js'
import { validateWeapon, weaponDamageModifiers, weaponFlatAttack } from './TowerWeapons.js'
import { validateEquipment, ringDamageModifiers, armorModifiers } from './TowerEquipment.js'
import { skillCooldown } from './TowerSkillTiming.js'
import { towerEnemyStats } from './TowerEnemyStats.js'
import { skillForm, skillHitShare, orbitSwordPose, convergenceRainMultiplier } from './TowerSkillForms.js'
import { swordQiReleaseOffset, swordQiHits, swordQiTravelLimit } from './TowerSwordQi.js'
import { newYujianState, turnYujian, yujianHeading, yujianHoverPose, stepYujianFlight,
  yujianVisualPose, validYujianState, validYujianShot, YUJIAN_TAIL } from './TowerYujian.js'

const STEP = 1 / 60
const EPS = 1e-9
const A = Object.fromEntries(ARCHETYPES.map(a => [a.id, a]))
const S = Object.fromEntries(SKILLS.map(s => [s.id, s]))
const EVO = Object.fromEntries(EVOLUTIONS.map(e => [e.id, e]))
const GS = Object.fromEntries(GROWTH_SKILLS.map(s => [s.id, s]))
const GROWTH_LIMITS = Object.fromEntries(['active', 'passive'].map(kind =>
  [kind, GROWTH_SKILLS.filter(skill => skill.kind === kind).length]))
const GEVO = Object.fromEntries(GROWTH_EVOLUTIONS.map(e => [e.id, e]))
const WEAPONS = ['eq_sword_suwen', 'eq_sword_qingxiao', 'eq_sword_zhenyue']
const DIRECT_CAST_SKILLS = ['sj_yujian', 'sj_arc', 'sj_cross', 'sj_line', 'sj_shadow']
const SWORD_QI_SOURCES = ['sj_arc', 'sj_cross']
const SWORD_QI_TAIL = .36
const SWORD_QI_MAX_TRAVEL = 4000
// Zone/render names are not skill IDs. Resolve them before asking the shared
// weapon module for S/F attribution; already-scaled wound/gate never enter it.
const WEAPON_SOURCES = {
  shadow: 'sj_shadow', formation: 'sj_formation', orbit: 'sj_wanjian',
  sword_rain: 'sj_yujian', rain: 'sj_yujian',
  evo_wanjian: 'sj_yujian', evo_tiandi: 'sj_line',
  evo_wuwo: 'sj_wanjian', evo_sixiang: 'sj_formation',
}
const weaponSkill = source => WEAPON_SOURCES[source] ?? source
const continuousSource = source => ['formation', 'sj_formation', 'evo_sixiang',
  'sword_rain', 'rain', 'evo_wanjian'].includes(source)
const BOUNDS = { xmin: -912, xmax: 978, ymin: -1140, ymax: 1020 }
const PORTALS = FLOOR01.arena.portals
const ELITE_CORE = [0, 3, 5, 8, 10, 12, 15, 18]
const BOSS_CORE = [0, 10, 15, 20, 25, 30, 35, 40]
const PHASES = ['playing', 'paused', 'won', 'lost', 'abandoned']
const copy = value => JSON.parse(JSON.stringify(value))
const object = v => v !== null && typeof v === 'object' && !Array.isArray(v)
const finite = v => typeof v === 'number' && Number.isFinite(v)
const uint = (n, max = Number.MAX_SAFE_INTEGER) => Number.isSafeInteger(n) && n >= 0 && n <= max
const validElement = item => !('element' in item) || ['poison', 'feather', 'sonic'].includes(item.element)
const clamp = (v, a, b) => Math.max(a, Math.min(b, v))
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y)
const facing = (dx, dy, fallbackX = 1, fallbackY = 0) => {
  const d = Math.hypot(dx, dy)
  return d > EPS ? { x: dx / d, y: dy / d } : { x: fallbackX, y: fallbackY }
}
const levelValue = (id, key, level, loadout) => {
  const v = (loadout?.growthVersion === 1 ? GS : S)[id][key]
  return Array.isArray(v) ? v[level - 1] : v
}
const familyOf = id => id.split('_')[0]
const radiusOf = id => FLOOR01.enemies[id]?.body_radius
  ?? (A[id].role === 'boss' ? 42 : A[id].role === 'elite' ? 34
    : { bear: 32, crocodile: 30, ape: 28, tiger: 28, bat: 18, falcon: 20 }[familyOf(id)] ?? 24)

function segmentDistance(p, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y
  const t = clamp(((p.x - a.x) * dx + (p.y - a.y) * dy) / (dx * dx + dy * dy || 1), 0, 1)
  return Math.hypot(p.x - a.x - t * dx, p.y - a.y - t * dy)
}

function inSector(p, origin, dir, radius, angle, bodyRadius) {
  const dx = p.x - origin.x, dy = p.y - origin.y, d = Math.hypot(dx, dy)
  if (d <= bodyRadius) return true
  const half = angle * Math.PI / 360
  if ((dx * dir.x + dy * dir.y) / d >= Math.cos(half) && d <= radius + bodyRadius) return true
  return [-half, half].some(turn => {
    const x = dir.x * Math.cos(turn) - dir.y * Math.sin(turn)
    const y = dir.x * Math.sin(turn) + dir.y * Math.cos(turn)
    return segmentDistance(p, origin, { x: origin.x + x * radius, y: origin.y + y * radius }) <= bodyRadius
  })
}

function inPolygon(p, vertices, radius = 0) {
  let sign = 0, inside = true
  for (let i = 0; i < vertices.length; i++) {
    const a = vertices[i], b = vertices[(i + 1) % vertices.length]
    if (segmentDistance(p, a, b) <= radius) return true
    const cross = (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x)
    if (Math.abs(cross) <= EPS) continue
    if (sign && Math.sign(cross) !== sign) inside = false
    sign = Math.sign(cross)
  }
  return inside
}

function formFor(id, level, loadout) {
  const evolution = { sj_yujian: 'evo_wanjian', sj_wanjian: 'evo_wuwo',
    sj_line: 'evo_tiandi', sj_formation: 'evo_sixiang' }[id]
  return evolution && id !== 'sj_yujian' && loadout.evolutions.includes(evolution)
    ? skillForm(evolution, loadout.evolutionLevels[evolution], level) : skillForm(id, level)
}

function formGeometry(form, pulseIndex, startedAt, extra = {}) {
  return { source: form.id, shape: form.shape, radius: form.radius, reach: form.reach,
    width: form.width, angle: form.angle, eyes: form.eyes, hits: form.hits,
    pulseIndex, pulseCount: form.hits, targetCap: form.targetCap, startedAt, ...extra }
}

function boundActor(actor, arenaVersion) {
  if (arenaVersion === 1) {
    boundHexActor(actor)
    pushFromPillars(actor)
    return
  }
  actor.x = clamp(actor.x, BOUNDS.xmin + actor.radius, BOUNDS.xmax - actor.radius)
  actor.y = clamp(actor.y, BOUNDS.ymin + actor.radius, BOUNDS.ymax - actor.radius)
}

function clippedRay(origin, dirX, dirY, range, radius, arenaVersion) {
  if (arenaVersion === 1) return clipPillars(origin, dirX, dirY, clipHexRay(origin, dirX, dirY, range, radius), radius)
  let length = range
  if (Math.abs(dirX) > EPS) length = Math.min(length,
    ((dirX > 0 ? BOUNDS.xmax - radius : BOUNDS.xmin + radius) - origin.x) / dirX)
  if (Math.abs(dirY) > EPS) length = Math.min(length,
    ((dirY > 0 ? BOUNDS.ymax - radius : BOUNDS.ymin + radius) - origin.y) / dirY)
  return Math.max(0, length)
}

function validLoadout(loadout, xp) {
  if (!uint(xp, TOWER_XP_CAP)) return false
  const level = cultivationAt(xp).level
  for (const slot of ['weapon', 'armor', 'ring']) {
    if (loadout?.[slot] && !canUseEquipmentTier(loadout[slot].tier, level)) return false
  }
  const growth = loadout?.growthVersion === 1
  if (!object(loadout) || !object(loadout.active) || !object(loadout.passive)
    || (loadout.growthVersion !== undefined && !growth)
    || !Array.isArray(loadout.evolutions) || loadout.evolutions.length > (growth ? 4 : 2)
    || new Set(loadout.evolutions).size !== loadout.evolutions.length
    || !uint(loadout.weaponQuality, 4) || !uint(loadout.weaponRefine, 4)) return false
  if (loadout.weapon !== undefined) {
    if (!growth || !validateWeapon(loadout.weapon)
      || (loadout.weaponEquipped !== undefined && typeof loadout.weaponEquipped !== 'boolean')
      || (loadout.weaponEquipped === false && !isStarterEquipment(loadout.weapon))
      || loadout.weaponId !== loadout.weapon.id || loadout.weaponQuality !== loadout.weapon.quality
      || loadout.weaponRefine !== loadout.weapon.refine || !uint(loadout.weaponFocusCount, 4)) return false
  } else if (!WEAPONS.includes(loadout.weaponId) || loadout.weaponQuality < 1
    || loadout.weaponFocusCount !== undefined) return false
  for (const category of ['armor', 'ring']) {
    if (loadout[category] === undefined) {
      if (loadout[`${category}Id`] !== undefined) return false
    } else if (!loadout.weapon || !validateEquipment(loadout[category], category)
      || loadout[`${category}Id`] !== loadout[category].id) return false
  }
  const equipmentIds = ['weapon', 'armor', 'ring'].filter(k => loadout[k]).map(k => loadout[k].id)
  if (new Set(equipmentIds).size !== equipmentIds.length) return false
  for (const kind of ['active', 'passive']) {
    const entries = Object.entries(loadout[kind])
    const table = growth ? GS : S
    if (entries.length > (growth ? GROWTH_LIMITS[kind] : 4) || (kind === 'active' && entries.length < 1 && !(growth && loadout.skillsInitialized))
      || entries.some(([id, lv]) => !table[id] || table[id].kind !== kind
        || !uint(lv, growth ? table[id].maxLevel : 5) || lv < 1)) return false
  }
  if (growth) {
    if ((loadout.skillsInitialized !== undefined && loadout.skillsInitialized !== true)
      || !uint(loadout.tutorialWaves, 3) || !object(loadout.evolutionLevels)
      || Object.keys(loadout.evolutionLevels).length !== loadout.evolutions.length) return false
    // Campaign checks books, points and realm; active entries are casting slots.
    // Run verifies the casting slot and the two playable ranks.
    return loadout.evolutions.every(id => GEVO[id] && uint(loadout.evolutionLevels[id], 2)
      && loadout.evolutionLevels[id] >= 1
      && loadout.active[GEVO[id].parent] >= 1)
  }
  // Paired passive level is a learning prerequisite checked by Campaign, not
  // an equipment requirement. Only the replaced level-five parent must be carried.
  return loadout.evolutions.every(id => EVO[id] && loadout.active[EVO[id].parent] === 5)
}

export function stats(xp, loadout, legacy = false) {
  const cultivation = cultivationAt(xp, legacy)
  const bone = loadout.passive.sj_bone || 0
  const flight = loadout.growthVersion === 1 ? loadout.passive.sj_flight || 0 : 0
  return {
    maxHp: cultivation.maxHp * (1 + (loadout.armor ? armorModifiers(loadout.armor).hpBonus || 0 : 0)),
    // Cultivation scales the character base only. Equipped weapons add their
    // own fixed base and rolled points; an empty slot adds nothing.
    attack: loadout.weapon
      ? 100 * cultivation.attackMultiplier
        + (loadout.weaponEquipped === false ? 0 : weaponFlatAttack(loadout.weapon))
      : 100 * cultivation.attackMultiplier
        * (1 + Math.min(.30, loadout.weaponQuality * .06 + loadout.weaponRefine * .015)),
    moveSpeed: 220 * (1 + (bone ? levelValue('sj_bone', 'speed_bonus', bone, loadout) : 0)
      + (flight ? levelValue('sj_flight', 'speed_bonus', flight, loadout) : 0)),
  }
}

// Read-only character sheet coefficients. Keep the two critical-damage bases
// separate: combat adds pre-bone damage * .5 and post-bone baseline * ring bonus.
export function characterCombatAttributes(loadout) {
  const passive = (id, key) => loadout.passive[id]
    ? levelValue(id, key, loadout.passive[id], loadout) : 0
  const ring = loadout.weapon && loadout.ring ? ringDamageModifiers(loadout.ring)
    : { critChance: 0, critBonus: 0, special: 0 }
  const armor = loadout.armor ? armorModifiers(loadout.armor)
    : { reduction: 0, healFraction: 0, healDelay: 0, healCooldown: 0, healFloorCap: 0 }
  return {
    critChance: clamp(passive('sj_heart', 'crit_chance') + ring.critChance, 0, 1),
    baseCritExtra: .5,
    ringCritExtra: ring.critBonus,
    focusEvery: ring.special > 0 ? 5 : 0,
    focusExtra: ring.special,
    cooldownReduction: 1 - skillCooldown(1, loadout),
    damageBonus: passive('sj_bone', 'damage_bonus'),
    reduction: 1 - (1 - Math.min(.15, passive('vajra', 'reduction')))
      * (1 - clamp(armor.reduction, 0, .06)),
    healFraction: armor.healFraction,
    healDelay: armor.healDelay,
    healCooldown: armor.healCooldown,
    healFloorCap: Math.min(.1, armor.healFloorCap),
    pickupBonus: passive('magnet', 'pickup_bonus'),
    woundShare: passive('sj_mark', 'wound_share'),
    killBurstShare: passive('sj_gate', 'share'),
  }
}

const sameWeapon = (a, b) => ['weaponId', 'weaponQuality', 'weaponRefine', 'weaponFocusCount', 'weaponEquipped'].every(k => a[k] === b[k])
  && ['weapon', 'armor', 'ring'].every(k => JSON.stringify(a[k]) === JSON.stringify(b[k])
    && a[`${k}Id`] === b[`${k}Id`])

function validWeaponState(s, legacy) {
  const w = s.weaponState
  const items = [...s.casts, ...s.projectiles, ...s.zones]
  if (!s.loadout.weapon) return w === undefined && items.every(item => item.weaponCastId === undefined)
  // Only declared skills emit friendly projectiles. A forged
  // source must not bypass cast accounting or borrow another skill's affixes.
  if (s.projectiles.some(p => !p.hostile && !['sj_yujian', ...SWORD_QI_SOURCES].includes(p.source))
    || s.zones.some(z => !z.hostile && !z.renderOnly
      && (!['shadow', 'formation', 'sword_rain'].includes(z.kind)
        || z.direct !== (z.kind !== 'formation')))) return false
  if (!object(w) || Object.keys(w).sort().join(',') !==
    'casts,effectiveCasts,entryMaxHp,focusCount,nextCastId,ringId'
    || w.ringId !== (s.loadout.ring?.id ?? null)
    || !uint(w.focusCount, 4) || !uint(w.effectiveCasts) || !uint(w.nextCastId) || w.nextCastId < 1
    || w.effectiveCasts >= w.nextCastId
    || w.focusCount !== ((s.training ? 0 : s.loadout.weaponFocusCount) + w.effectiveCasts) % 5
    || w.effectiveCasts > 0 && (!s.loadout.ring || ringDamageModifiers(s.loadout.ring).special <= 0)
    || w.entryMaxHp !== stats(s.base.xp, s.loadout, legacy).maxHp
    || !Array.isArray(w.casts) || w.casts.length > 20000) return false
  const receipts = new Map(), ordinals = new Set(), referenced = new Set()
  for (const c of w.casts) {
    if (!object(c) || Object.keys(c).sort().join(',') !== 'id,ordinal,skillId'
      || !uint(c.id, w.nextCastId - 1) || c.id < 1 || receipts.has(c.id)
      || !DIRECT_CAST_SKILLS.includes(c.skillId)
      || c.ordinal !== null && (!uint(c.ordinal, w.effectiveCasts) || c.ordinal < 1 || ordinals.has(c.ordinal))) return false
    receipts.set(c.id, c)
    if (c.ordinal !== null) ordinals.add(c.ordinal)
  }
  for (const item of items) {
    const source = item.skill ?? item.source ?? item.kind
    const skill = weaponSkill(source)
    const eligible = !item.hostile && !item.renderOnly && !continuousSource(source)
      && DIRECT_CAST_SKILLS.includes(skill)
    if (!eligible) {
      if (item.weaponCastId !== undefined) return false
      continue
    }
    const receipt = receipts.get(item.weaponCastId)
    if (!receipt || receipt.skillId !== skill
      || item.skill && !(item.pulseIndex > 0) && receipt.ordinal !== null) return false
    referenced.add(receipt.id)
  }
  return referenced.size === receipts.size
}

function validArmorState(s, legacy) {
  const a = s.armorState
  if (!s.loadout.armor) return a === undefined
  const m = armorModifiers(s.loadout.armor)
  if (!object(a) || Object.keys(a).sort().join(',') !==
    'armorId,cooldownUntil,entryMaxHp,healedTotal,lastTriggerAt,pending,triggerCount'
    || a.armorId !== s.loadout.armor.id
    || a.entryMaxHp !== stats(s.base.xp, s.loadout, legacy).maxHp
    || !finite(a.healedTotal) || a.healedTotal < 0
    || a.healedTotal > a.entryMaxHp * Math.min(.1, m.healFloorCap) + EPS
    || !uint(a.triggerCount) || !finite(a.cooldownUntil) || a.cooldownUntil < 0) return false
  if (a.triggerCount === 0) return a.lastTriggerAt === null && a.pending === null
    && a.cooldownUntil === 0 && a.healedTotal === 0
  if (m.healFraction <= 0 || m.healCooldown <= 0
    || !finite(a.lastTriggerAt) || a.lastTriggerAt < 0 || a.lastTriggerAt > s.time
    || a.cooldownUntil !== a.lastTriggerAt + m.healCooldown
    || a.triggerCount > Math.floor((a.lastTriggerAt + EPS) / m.healCooldown) + 1
    || a.healedTotal > a.triggerCount * a.entryMaxHp * m.healFraction + EPS) return false
  if (a.pending === null) return s.player.hp <= 0 || s.time + EPS >= a.lastTriggerAt + m.healDelay
  const p = a.pending
  return object(p) && Object.keys(p).sort().join(',') === 'amount,damage,dueAt,triggeredAt'
    && s.player.hp > 0 && p.triggeredAt === a.lastTriggerAt
    && p.dueAt === p.triggeredAt + m.healDelay && p.dueAt > s.time + EPS
    && finite(p.damage) && p.damage > 0 && p.damage <= s.player.maxHp
    && finite(p.amount) && p.amount > 0
    && p.amount === Math.min(p.damage, a.entryMaxHp * m.healFraction,
      a.entryMaxHp * Math.min(.1, m.healFloorCap) - a.healedTotal)
    && a.healedTotal <= (a.triggerCount - 1) * a.entryMaxHp * m.healFraction + EPS
}

// Capturing the loadout and XP also freezes passive damage shares and the attack
// scalar. Existing projectile damage, wound budgets and gate receipts stay numeric.
const castContext = s => ({ loadout: copy(s.loadout), xp: s.player.xp })
function validCastContext(context, s) {
  return object(context) && validLoadout(context.loadout, context.xp) && uint(context.xp, s.player.xp)
    && sameWeapon(context.loadout, s.loadout)
}

function validFormCast(c, time) {
  if (c.formId === undefined) return c.castContext?.loadout?.growthVersion !== 1
    && c.pulseCount === undefined && c.pulseIndex === undefined
  const loadout = c.castContext?.loadout
  if (loadout?.growthVersion !== 1) return false
  const form = formFor(c.skill, c.level, loadout)
  const windup = form.id === 'evo_tiandi' ? GEVO.evo_tiandi.windup : GS[c.skill].windup
  return c.formId === form.id && c.pulseCount === form.hits
    && uint(c.pulseIndex, form.hits - 1) && finite(c.startedAt)
    && Math.abs(Math.hypot(c.dirX, c.dirY) - 1) <= EPS
    && Math.abs(c.releaseAt - (c.startedAt + windup + c.pulseIndex * form.interval)) <= EPS
    && (form.id !== 'evo_tiandi' || finite(c.lockAt)
      && Math.abs(c.lockAt - (c.startedAt + windup - .15)) <= EPS
      && c.locked === (time + EPS >= c.lockAt)
      && typeof c.windupEffectId === 'string')
}

function validFormZone(z) {
  if (z.formId === undefined) return z.castContext?.loadout?.growthVersion !== 1
    && z.pulseCount === undefined && z.pulseIndex === undefined
  const parents = { shadow: 'sj_shadow', formation: 'sj_formation', sword_rain: 'sj_yujian' }
  const parent = parents[z.kind], loadout = z.castContext?.loadout
  if (!parent || loadout?.growthVersion !== 1 || z.parentLevel !== loadout.active[parent]) return false
  const special = z.kind === 'sword_rain'
  const form = special ? skillForm('evo_wanjian', loadout.evolutionLevels.evo_wanjian, z.parentLevel)
    : formFor(parent, z.parentLevel, loadout)
  if (special && !loadout.evolutions.includes('evo_wanjian')) return false
  const level = loadout.evolutionLevels[form.id] ?? z.parentLevel
  const base = stats(z.castContext.xp, loadout).attack * levelValue(parent, 'damage', z.parentLevel, loadout)
  const total = special ? base * convergenceRainMultiplier(level)
    : parent === 'sj_formation' ? base * GS.sj_formation.ticks
      * (form.id === 'evo_sixiang' ? GEVO.evo_sixiang.budgetMultipliers[level - 1] : 1) : base
  return z.formId === form.id && z.source === form.id && z.formLevel === level
    && z.shape === form.shape && z.hits === form.hits && z.pulseCount === form.hits
    && uint(z.pulseIndex, form.hits) && z.ticks + z.pulseIndex === form.hits
    && ['radius', 'reach', 'width', 'angle', 'eyes', 'targetCap', 'interval'].every(key => z[key] === form[key])
    && finite(z.startedAt) && finite(z.dirX) && finite(z.dirY)
    && Math.abs(Math.hypot(z.dirX, z.dirY) - 1) <= EPS
    && Math.abs(z.damage - total / form.hits) <= EPS
    && Math.abs(z.nextAt - (z.startedAt + form.initialDelay + z.pulseIndex * form.interval)) <= EPS
    && Math.abs(z.expiresAt - (z.startedAt + form.duration + .2)) <= EPS
    && z.phase === (z.pulseIndex ? 'active' : 'windup')
    && (!special || finite(z.originX) && finite(z.originY))
}

function validSwordQi(shot, s) {
  if (!SWORD_QI_SOURCES.includes(shot.source)) return shot.bladeKind === undefined
  if (shot.hostile || shot.castContext?.loadout?.growthVersion !== 1) return false
  const level = shot.castContext.loadout.active[shot.source]
  if (!level) return false
  const form = skillForm(shot.source, level)
  if (!['crescent-projectile', 'cross-projectile'].includes(form.shape)) return false
  if (shot.shape !== form.shape || shot.bladeKind !== form.bladeKind || shot.width !== form.width
    || shot.bladeWidth !== form.bladeWidth || shot.radius !== form.bladeWidth / 2
    || shot.targetCap !== form.targetCap || shot.speed !== form.speed
    || !uint(shot.pulseIndex, form.hits) || shot.pulseIndex < 1 || shot.pulseCount !== form.hits
    || !['dirX','dirY','originX','originY','travelled','range','startedAt'].every(k=>finite(shot[k]))
    || Math.abs(Math.hypot(shot.dirX,shot.dirY)-1)>EPS
    || Math.abs(shot.vx-shot.dirX*form.speed)>EPS || Math.abs(shot.vy-shot.dirY*form.speed)>EPS
    || shot.range <= EPS || shot.range > SWORD_QI_MAX_TRAVEL
    || shot.travelled < 0 || shot.travelled > shot.range + EPS
    || shot.startedAt < 0 || shot.startedAt > s.time
    || Math.abs(shot.x-shot.originX-shot.dirX*shot.travelled)>1e-6
    || Math.abs(shot.y-shot.originY-shot.dirY*shot.travelled)>1e-6
    || shot.hitIds.length > form.targetCap || new Set(shot.hitIds).size !== shot.hitIds.length
    || shot.hitIds.some(id=>typeof id!=='string' || !plan(s).some(p=>p.id===id))) return false
  const range = swordQiTravelLimit(form.bladeKind,form.width,form.bladeWidth,
    {x:shot.originX,y:shot.originY},shot.dirX,shot.dirY,SWORD_QI_MAX_TRAVEL,s.arenaVersion)
  if (Math.abs(range-shot.range)>1e-6) return false
  const expected = stats(shot.castContext.xp,shot.castContext.loadout).attack
    * levelValue(shot.source,'damage',level,shot.castContext.loadout)
    * skillHitShare(shot.source,level,shot.pulseIndex)
  if (Math.abs(shot.damage-expected)>EPS) return false
  if (shot.dissolveAt === null) return shot.travelled < shot.range
    && Math.abs(shot.expiresAt-(shot.startedAt+shot.range/form.speed+SWORD_QI_TAIL))<EPS
  return finite(shot.dissolveAt) && shot.dissolveAt >= shot.startedAt && shot.dissolveAt <= s.time
    && Math.abs(shot.travelled-shot.range)<EPS
    && Math.abs(shot.expiresAt-shot.dissolveAt-SWORD_QI_TAIL)<EPS
}

function validYujianRuntime(shot,s) {
  if(shot.yujianSlot===undefined)return true
  if(!validYujianShot(shot))return false
  const loadout=shot.castContext?.loadout,level=loadout?.active?.sj_yujian
  if(loadout?.growthVersion!==1 || !Number.isInteger(level) || level<1 || level>10
    || shot.yujianSlot>=level || !Number.isInteger(shot.pulseIndex)
    || shot.pulseIndex<1 || shot.pulseIndex>level || shot.radius!==7
    || shot.gatherAt>s.time || Math.abs(shot.startedAt-shot.gatherAt)>EPS
    || Math.abs(shot.flightAt-shot.gatherAt-.32-(shot.pulseIndex-1)*.042)>EPS
    || shot.hitIds.length>1 || shot.hitIds.some(id=>id!==shot.targetId)
    || shot.trail.some(p=>p.at<shot.gatherAt || p.at>s.time))return false
  const expected=stats(shot.castContext.xp,loadout).attack*levelValue('sj_yujian','damage',level,loadout)
    *(shot.pulseIndex===1?1:levelValue('sj_yujian','secondary_share',level,loadout))
  if(Math.abs(shot.damage-expected)>EPS)return false
  if(shot.dissolveAt!==null)return shot.dissolveAt>=shot.gatherAt && shot.dissolveAt<=s.time
    && Math.abs(shot.expiresAt-shot.dissolveAt-YUJIAN_TAIL)<EPS
  const spirit=loadout.passive.sj_spirit||0
  const reach=skillForm('sj_yujian',level).reach*(1+(spirit?levelValue('sj_spirit','reach_bonus',spirit,loadout):0))
  return shot.hitIds.length===0 && Math.abs(shot.expiresAt-shot.flightAt-reach/680-1)<EPS
}

function readyNewSkills(s) {
  for (const id of Object.keys(s.loadout.active)) {
    if (s.cooldowns[id] === undefined) s.cooldowns[id] = 0
  }
  if (s.loadout.evolutions.includes('evo_wanjian') && s.cooldowns.evo_wanjian === undefined) {
    s.cooldowns.evo_wanjian = 0
  }
}

// All required units are registered up front, including dormant boss support.
// These immutable plans contain no random choices and are reconstructed on load.
const PLANS = FLOORS.map(f => f.waves.map(w => {
  if (f.floor === 1) return FLOOR01.waves[w.wave - 1].batches.flatMap(b =>
    b.unit_ids.map((id, i) => ({ localId: id, archetype: b.archetype, portal: b.portal,
      at: b.at_s + i * b.emit_step_s, trigger: b.trigger === 'wave_start' ? 'start' : 'half',
      warning: b.warning_s })))
  const groups = [...w.enemy_groups].sort((a, b) =>
    Number(A[b.archetype].role === 'boss') - Number(A[a.archetype].role === 'boss'))
  let index = 0, normalIndex = 0
  return groups.flatMap(g => Array.from({ length: g.count }, () => {
    const i = index++, normal = A[g.archetype].role === 'normal'
    const trigger = w.kind === 'boss' && normal && normalIndex++ >= 4 ? 'half' : 'start'
    return { localId: `u${i + 1}`, archetype: g.archetype,
      portal: PORTALS[(w.wave + i * 3) % PORTALS.length].id, at: i * .22,
      trigger, warning: normal ? .9 : 1.2 }
  }))
}))

function plan(state, wave = state.wave) {
  return PLANS[state.floor - 1][wave - 1].map(p => ({
    ...p, id: `a${state.attemptId}:f${state.floor}:w${wave}:${p.localId}`,
  }))
}

function coreRankFor(state, kill, drops) {
  if (state.training) return 0
  const prefix = `a${state.attemptId}:f${state.floor}:w${kill.wave}:`
  return drops[`${kill.wave}:${kill.id.slice(prefix.length)}`] || 0
}

// Legacy graded receipts retained for validated replay compatibility. Economy v2
// converts these opaque units into spirit stones; these are NOT demon-core XP.
// Completion awards are accounted for separately.
export function coreLootSummary(snapshot) {
  if (!snapshot.loot) return null
  const byRank = Array(7).fill(0)
  for (const kill of snapshot.killLedger) {
    if (kill.coreRank > 0) byRank[kill.coreRank - 1]++
  }
  return {
    byRank, count: byRank.reduce((sum, count) => sum + count, 0),
    value: byRank.reduce((sum, count, i) => sum + count * CORE_RANK_VALUES[i + 1], 0),
  }
}

function jsonSafe(value, seen = new Set(), depth = 0) {
  if (depth > 30) return false
  if (value === null || typeof value === 'boolean' || typeof value === 'string') return true
  if (typeof value === 'number') return finite(value)
  if (typeof value !== 'object' || seen.has(value)) return false
  seen.add(value)
  const ok = Object.values(value).every(v => jsonSafe(v, seen, depth + 1))
  seen.delete(value)
  return ok
}

function positioned(v) {
  return object(v) && typeof v.id === 'string' && finite(v.x) && finite(v.y)
    && finite(v.radius) && v.radius >= 0
}

function validView(view) {
  return view === null || object(view) && ['xmin', 'xmax', 'ymin', 'ymax'].every(k => finite(view[k]))
    && view.xmin < view.xmax && view.ymin < view.ymax
    && (!('followPlayer' in view) || typeof view.followPlayer === 'boolean')
}

function validAI(ai, time) {
  if (!object(ai) || !['approach', 'windup', 'active', 'recovery'].includes(ai.mode)
    || !['readyAt', 'graceUntil', 'until', 'entryUntil', 'transitionUntil', 'eligibleSince',
      'faceX', 'faceY', 'offset'].every(k => finite(ai[k]))
    || !uint(ai.sequence) || ![1, 2].includes(ai.phase) || ![-1, 1].includes(ai.orbitSign)
    || typeof ai.transitionPending !== 'boolean' || !object(ai.cooldowns)
    || !Object.values(ai.cooldowns).every(t => finite(t) && t >= 0)) return false
  if (ai.mode === 'approach') return ai.attack === null
  const a = ai.attack
  return object(a) && typeof a.id === 'string' && ['bite', 'gore', 'charge', 'shot', 'stone', 'web', 'slam', 'sweep'].includes(a.kind)
    && ['circle', 'sector', 'capsule'].includes(a.shape) && validElement(a)
    && ['damage', 'windup', 'range', 'active', 'recovery', 'cooldown', 'lock', 'speed',
      'radius', 'width', 'angle', 'travelled', 'maxRange'].every(k => finite(a[k]) && a[k] >= 0)
    && ['x', 'y', 'targetX', 'targetY', 'dirX', 'dirY', 'startedAt'].every(k => finite(a[k]))
    && Math.abs(Math.hypot(a.dirX, a.dirY) - 1) <= EPS && a.startedAt <= time
    && ['locked', 'hit', 'fired', 'boundary', 'clipped'].every(k => typeof a[k] === 'boolean')
    && uint(a.segments, 2) && a.segments >= 1 && uint(a.segment, a.segments) && a.segment >= 1
    && [1, 2].includes(a.cost)
}

/**
 * Structural AND reward-ledger validation. This detects corrupt/non-finite state
 * and inconsistent earnings; it is not a signature against a malicious host.
 */
export function validateTowerSnapshot(s, legacy = false) {
  try {
    if (!object(s) || !jsonSafe(s) || s.schema !== 1 || !PHASES.includes(s.phase)
      || !uint(s.attemptId) || (!s.training && s.attemptId < 1)
      || typeof s.training !== 'boolean' || !uint(s.floor, 9) || s.floor < 1
      || !uint(s.wave, 20) || s.wave < 1 || !uint(s.ticks) || s.time !== s.ticks / 60
      || !finite(s.remainder) || s.remainder < 0 || s.remainder >= STEP + EPS
      || !uint(s.rng, 0xffffffff) || !s.rng || !uint(s.nextId)
      || !validLoadout(s.loadout, s.player?.xp) || !object(s.player) || !object(s.base)
      || !uint(s.base.xp, TOWER_XP_CAP) || !uint(s.base.normalCoreCounter, 19)
      || !finite(s.base.hp) || s.base.hp <= 0 || s.base.hp > stats(s.base.xp, s.loadout, legacy).maxHp
      || !uint(s.player.xp, TOWER_XP_CAP) || !finite(s.player.hp) || s.player.hp < 0
      || !finite(s.player.x) || !finite(s.player.y) || !finite(s.player.faceX) || !finite(s.player.faceY)
      || !object(s.input) || !finite(s.input.x) || !finite(s.input.y)
      || Math.hypot(s.input.x, s.input.y) > 1 + EPS
      || !uint(s.normalCoreCounter, 19) || !uint(s.waveKilled) || !uint(s.wavePlanned)
      || !object(s.cooldowns) || !Object.values(s.cooldowns).every(v => finite(v) && v >= 0)
      || !finite(s.waveStartedAt) || s.waveStartedAt > s.time
      || !finite(s.hurtUntil) || !finite(s.nextWindupAt) || !finite(s.supportAt)
      || typeof s.supportReleased !== 'boolean' || !finite(s.gateReadyAt)
      || !uint(s.rawKillXp) || !object(s.earned)) return false
    if (!validView(s.view) || !finite(s.trainingResetAt) || !validYujianState(s.yujian,s.time)
      || ('arenaVersion' in s && s.arenaVersion !== 1)
      || Object.keys(s.earned).sort().join(',') !== 'contribution,cores,xp'
      || !Object.values(s.earned).every(v => uint(v))) return false
    if (s.loot !== undefined && (!object(s.loot)
      || Object.keys(s.loot).sort().join(',') !== 'seed,version'
      || s.loot.version !== 1 || !uint(s.loot.seed, 0xffffffff))) return false
    const coreDrops = s.loot ? buildCoreDropPlan(s.floor, s.loot.seed) : null
    for (const key of ['enemies', 'projectiles', 'zones', 'drops', 'effects', 'pending',
      'reserved', 'casts', 'killLedger', 'clearedWaves', 'gateEntries']) {
      if (!Array.isArray(s[key]) || s[key].length > 20000) return false
    }
    if (!validWeaponState(s, legacy) || !validArmorState(s, legacy) || !validateMonsterMechanics(s)) return false
    if (s.monsterControl !== undefined && (!object(s.monsterControl)
      || Object.keys(s.monsterControl).sort().join(',') !== 'immuneUntil,rootUntil,slowFraction,slowUntil'
      || !Object.values(s.monsterControl).every(v => finite(v) && v >= 0)
      || s.monsterControl.slowFraction > .3)) return false
    const growth = s.loadout.growthVersion === 1
    if (growth && (!uint(s.base.tutorialWaves, 3)
      || s.loadout.tutorialWaves !== tutorialProgress(s.base.tutorialWaves, s.floor, s.training ? [] : s.clearedWaves))) return false
    const validContext = item => growth
      ? validCastContext(item.castContext, s) : item.castContext === undefined
    const expectedStats = stats(s.player.xp, s.loadout, legacy)
    if (Object.entries(expectedStats).some(([k, v]) => !finite(s.player[k]) || Math.abs(s.player[k] - v) > EPS)
      || s.player.hp > expectedStats.maxHp || s.player.radius !== 18
      || (s.phase === 'lost' ? s.player.hp !== 0 : s.player.hp <= 0)
      || (s.arenaVersion === 1 ? !insideHex(s.player, s.player.radius)
        : s.player.x < -894 || s.player.x > 960 || s.player.y < -1122 || s.player.y > 1002)) return false
    if (Object.keys(s.loadout.active).some(id => !finite(s.cooldowns[id]))) return false
    if (s.loadout.evolutions.includes('evo_wanjian') && !finite(s.cooldowns.evo_wanjian)) return false
    const currentPlan = plan(s), lookup = new Map(currentPlan.map(p => [p.id, p]))
    const allIds = new Set(), deadNow = []
    let xp = 0, normal = 0, cores = 0
    for (const kill of s.killLedger) {
      if (!object(kill) || !uint(kill.wave, s.wave) || kill.wave < 1 || allIds.has(kill.id)) return false
      const authored = plan(s, kill.wave).find(p => p.id === kill.id)
      if (!authored || authored.archetype !== kill.archetype) return false
      allIds.add(kill.id)
      const a = A[kill.archetype]
      xp += towerKillXp(s.floor, kill.wave, authored.localId)
      if (coreDrops) {
        const coreRank = coreRankFor(s, kill, coreDrops)
        if (kill.coreRank !== coreRank || coreRank && coreRank !== a.rank) return false
        cores += CORE_RANK_VALUES[coreRank]
      } else {
        if (kill.coreRank !== undefined) return false
        if (a.role === 'normal') normal++
        else cores += (a.role === 'elite' ? ELITE_CORE : BOSS_CORE)[a.rank]
      }
      if (kill.wave === s.wave) deadNow.push(kill.id)
    }
    for (const kind of ['pending', 'reserved', 'enemies']) {
      for (const item of s[kind]) {
        if (kind === 'enemies' && item.temporary) {
          if (allIds.has(item.id) || lookup.has(item.id) || !positioned(item)
            || !validAI(item.ai, s.time) || s.arenaVersion === 1 && !insideHex(item, item.radius)) return false
          allIds.add(item.id)
          continue
        }
        const p = lookup.get(item.id)
        if (!p || p.archetype !== item.archetype || allIds.has(item.id)) return false
        allIds.add(item.id)
        if (kind !== 'enemies') {
          if (item.portal !== p.portal || item.at !== p.at || item.trigger !== p.trigger
            || item.warning !== p.warning || !finite(item.retryAt) || !finite(item.waitingSince)) return false
          if (kind === 'reserved' && (!positioned(item) || !finite(item.readyAt)
            || s.arenaVersion === 1 && (item.radius !== radiusOf(item.archetype)
              || !insideHex(item, item.radius)))) return false
        } else {
          const authored = towerEnemyStats(A[item.archetype], s.floor, s.wave)
          if (!positioned(item) || item.family !== familyOf(item.archetype) || item.role !== A[item.archetype].role
            || item.maxHp !== authored.hp || !finite(item.hp) || item.hp <= 0 || item.hp > item.maxHp
            || item.rank !== A[item.archetype].rank || item.damage !== authored.damage
            || item.moveSpeed !== authored.moveSpeed || item.radius !== radiusOf(item.archetype)
            || s.arenaVersion === 1 && !insideHex(item, item.radius)
            || !validAI(item.ai, s.time) || !finite(item.woundBudget) || item.woundBudget < 0
            || !finite(item.woundUntil) || !finite(item.orbitNextAt)) return false
        }
      }
    }
    if (s.wavePlanned !== currentPlan.length || s.waveKilled !== deadNow.length
      || s.pending.length + s.reserved.length + s.enemies.filter(e => !e.temporary).length + deadNow.length !== currentPlan.length
      || s.enemies.filter(e => !e.temporary).length + s.reserved.length > FLOORS[s.floor - 1].concurrent_cap) return false
    const clearedCount = s.phase === 'won' ? 20 : s.wave - 1
    if (s.training) {
      if (s.phase === 'won' || s.clearedWaves.length || s.player.xp !== s.base.xp
        || s.normalCoreCounter !== s.base.normalCoreCounter
        || Object.values(s.earned).some(v => v !== 0)) return false
    } else {
      if (s.clearedWaves.length !== clearedCount
        || s.clearedWaves.some((w, i) => w !== i + 1)) return false
      for (const w of s.clearedWaves) {
        if (s.killLedger.filter(k => k.wave === w).length !== PLANS[s.floor - 1][w - 1].length) return false
      }
      if (!coreDrops) cores += Math.floor((s.base.normalCoreCounter + normal) / 20)
      let contribution = 0
      for (const w of s.clearedWaves) {
        const kind = FLOORS[s.floor - 1].waves[w - 1].kind
        contribution += 2 + (kind === 'elite' ? 5 : kind === 'boss' ? 45 + 5 * (s.floor - 1) : 0)
        if (kind === 'boss') cores += 5 * (s.floor - 1)
      }
      if (s.earned.cores !== cores || s.earned.contribution !== contribution
        || s.earned.xp !== Math.min(TOWER_XP_CAP - s.base.xp, xp)
        || s.player.xp !== s.base.xp + s.earned.xp
        || s.normalCoreCounter !== (coreDrops ? s.base.normalCoreCounter
          : (s.base.normalCoreCounter + normal) % 20)) return false
    }
    if (s.rawKillXp !== xp) return false
    if (!s.projectiles.every(p => positioned(p) && finite(p.vx) && finite(p.vy) && validElement(p)
      && finite(p.damage) && p.damage >= 0 && finite(p.expiresAt) && typeof p.hostile === 'boolean'
      && Array.isArray(p.hitIds) && validSwordQi(p, s) && validYujianRuntime(p,s)
      && (p.hostile ? p.castContext === undefined : validContext(p)))) return false
    const swordSlots=s.projectiles.filter(p=>p.yujianSlot!==undefined).map(p=>p.yujianSlot)
    if(new Set(swordSlots).size!==swordSlots.length)return false
    if (!s.zones.every(z => {
      if (!positioned(z) || !finite(z.expiresAt) || typeof z.hostile !== 'boolean'
        || typeof z.renderOnly !== 'boolean' || !['windup', 'active'].includes(z.phase)) return false
      if (z.renderOnly) return ['enemy_windup', 'enemy_attack'].includes(z.kind)
        && s.enemies.some(e => e.id === z.ownerId && e.ai.attack?.id === z.attackId)
        && ['toX', 'toY', 'width', 'angle', 'faceX', 'faceY'].every(k => finite(z[k]))
        && typeof z.locked === 'boolean' && ['circle', 'capsule', 'sector'].includes(z.shape)
      return ['shadow', 'formation', 'sword_rain', 'web', 'stone'].includes(z.kind)
        && finite(z.damage) && z.damage >= 0 && finite(z.nextAt) && finite(z.interval) && z.interval > 0
        && uint(z.ticks, z.pulseCount ?? 6) && uint(z.pulseCount ?? 6, 9) && validFormZone(z)
        && uint(z.targetCap, 8) && z.targetCap >= 1 && typeof z.direct === 'boolean'
        && (z.hostile ? z.castContext === undefined : validContext(z))
    })) return false
    if (!s.drops.every(d => {
      if (!positioned(d) || !finite(d.expiresAt) || !finite(d.amount)) return false
      if (d.kind !== 'core') return ['heal', 'resource'].includes(d.kind)
      return !!coreDrops && !s.training && uint(d.rank, 7) && d.rank > 0
        && d.amount === CORE_RANK_VALUES[d.rank]
        && s.killLedger.some(k => k.id === d.killId && k.coreRank === d.rank)
    })) return false
    const coreIds = s.drops.filter(d => d.kind === 'core').map(d => d.killId)
    if (new Set(coreIds).size !== coreIds.length) return false
    if (!s.effects.every(e => positioned(e) && finite(e.expiresAt))) return false
    if (!s.casts.every(c => validContext(c) && (growth ? GS : S)[c.skill]?.kind === 'active'
      && c.level === (growth ? c.castContext.loadout : s.loadout).active[c.skill]
      && ['releaseAt', 'x', 'y', 'dirX', 'dirY', 'targetX', 'targetY'].every(k => finite(c[k]))
      && validFormCast(c, s.time))) return false
    return s.gateEntries.every(e => object(e) && finite(e.amount) && e.amount >= 0 && finite(e.expiresAt))
  } catch { return false }
}

// Called only after a schema-1 campaign passes checksum AND legacy validation.
export function migrateTowerCultivation(snapshot) {
  if (!validateTowerSnapshot(snapshot, true)) throw new TypeError('Invalid legacy tower snapshot')
  const next = copy(snapshot)
  next.base.hp = Math.min(next.base.hp, stats(next.base.xp, next.loadout).maxHp)
  Object.assign(next.player, stats(next.player.xp, next.loadout))
  next.player.hp = Math.min(next.player.hp, next.player.maxHp)
  if (!validateTowerSnapshot(next)) throw new TypeError('Invalid migrated tower snapshot')
  return next
}

// Campaign must verify its checksum first. Schema-1 cultivation migration runs
// before this function; no invalid legacy ledger can be repaired by conversion.
// loadout.tutorialWaves is the post-migration awarded teaching stage.
// Infer the lowest valid entry stage from the authored floor milestones.
export function migrateTowerGrowth(snapshot, loadout) {
  if (!validateTowerSnapshot(snapshot) || snapshot.loadout.growthVersion !== undefined
    || !validLoadout(loadout, snapshot.player.xp) || loadout.growthVersion !== 1
    || !sameWeapon(snapshot.loadout, loadout)) throw new TypeError('Invalid legacy growth migration')
  const next = copy(snapshot), context = castContext(snapshot)
  for (const item of [...next.casts, ...next.projectiles.filter(p => !p.hostile),
    ...next.zones.filter(z => !z.hostile && !z.renderOnly)]) item.castContext = copy(context)
  next.loadout = copy(loadout)
  const earnedTutorial = tutorialProgress(0, next.floor, next.training ? [] : next.clearedWaves)
  if (loadout.tutorialWaves < earnedTutorial) throw new TypeError('Invalid migrated teaching stage')
  next.base.tutorialWaves = loadout.tutorialWaves === earnedTutorial ? 0 : loadout.tutorialWaves
  readyNewSkills(next)
  Object.assign(next.player, stats(next.player.xp, next.loadout))
  if (!validateTowerSnapshot(next)) throw new TypeError('Invalid migrated growth snapshot')
  return next
}

export class TowerRun {
  constructor({ attemptId, floor, seed = 1, hp, xp, normalCoreCounter = 0, loadout,
    training = false, lootVersion = 1, arenaVersion = 0 }) {
    if (!uint(attemptId) || (!training && attemptId < 1) || !uint(floor, 9) || floor < 1
      || !uint(seed, 0xffffffff) || !uint(xp, TOWER_XP_CAP) || !validLoadout(loadout, xp)
      || !finite(hp) || hp <= 0 || hp > stats(xp, loadout).maxHp
      || !uint(normalCoreCounter, 19) || typeof training !== 'boolean'
      || ![0, 1].includes(lootVersion) || ![0, 1].includes(arenaVersion)) throw new RangeError('Invalid tower attempt')
    const chosen = copy(loadout)
    this._playtestAssist = false
    this.state = {
      schema: 1, attemptId, floor, phase: 'playing', training, time: 0, ticks: 0, remainder: 0,
      wave: 1, waveStartedAt: 0, waveKilled: 0, wavePlanned: 0, nextId: 1,
      player: { x: 33, y: -60, hp, xp, ...stats(xp, chosen), radius: 18, faceX: 1, faceY: 0 },
      enemies: [], projectiles: [], zones: [], drops: [], effects: [], pending: [], reserved: [],
      earned: { xp: 0, cores: 0, contribution: 0 }, rawKillXp: 0,
      normalCoreCounter, loadout: chosen, rng: seed || 0x6d2b79f5,
      base: { xp, hp, normalCoreCounter }, input: { x: 0, y: 0 },
      cooldowns: Object.fromEntries(Object.keys(chosen.active).map(id => [id, 0])),
      casts: [], killLedger: [], clearedWaves: [], gateEntries: [], gateReadyAt: 0,
      hurtUntil: 0, nextWindupAt: 0, supportReleased: false, supportAt: -1,
      view: null, trainingResetAt: 0,
      monsterMechanics: { version: 1, zones: [], sequence: 0, nextMajorAt: 0 },
      monsterControl: { rootUntil: 0, immuneUntil: 0, slowUntil: 0, slowFraction: 0 },
    }
    // Shape is opt-in per attempt. Historical snapshots stay rectangular.
    if (arenaVersion === 1) this.state.arenaVersion = 1
    // A retry gets a fresh allocation; combat randomness and kill order cannot
    // move its drops. An old snapshot without this field continues its old rule.
    if (lootVersion === 1) this.state.loot = {
      version: 1, seed: (seed ^ Math.imul(attemptId >>> 0, 0x9e3779b1)) >>> 0,
    }
    if (chosen.growthVersion === 1) this.state.base.tutorialWaves = chosen.tutorialWaves
    if (chosen.growthVersion === 1) this.state.yujian = newYujianState(this.state.player,0)
    // The legacy field name weaponFocusCount now carries the equipped RING's
    // immutable initial count. Campaign persists focusCount by ringId on finish.
    // Receipt ordinals keep every target/projectile of the fifth cast empowered,
    // even when a later cast hits first or the game is restored between hits.
    if (chosen.weapon) this.state.weaponState = {
      ringId: chosen.ring?.id ?? null,
      focusCount: training ? 0 : chosen.weaponFocusCount,
      effectiveCasts: 0, nextCastId: 1, casts: [],
      entryMaxHp: this.state.player.maxHp,
    }
    if (chosen.armor) this.state.armorState = {
      armorId: chosen.armor.id, entryMaxHp: this.state.player.maxHp,
      healedTotal: 0, cooldownUntil: 0, lastTriggerAt: null, triggerCount: 0, pending: null,
    }
    if (chosen.evolutions.includes('evo_wanjian')) this.state.cooldowns.evo_wanjian = 0
    this._registerWave()
  }

  static restore(snapshot) {
    if (!validateTowerSnapshot(snapshot)) throw new TypeError('Invalid tower snapshot')
    const run = Object.create(TowerRun.prototype)
    run._playtestAssist = false
    run.state = copy(snapshot)
    return run
  }

  snapshot() { return copy(this.state) }
  // Only the isolated playtest host opts in. Never persisted or inherited by
  // restore; ordinary runs and balance simulations keep the normal combat path.
  // Rebase permanent development XP without changing earned combat rewards.
  setDeveloperCultivation(xp) {
    const s = this.state
    if (s.phase !== 'paused' || !uint(xp, TOWER_XP_CAP) || xp < s.player.xp) {
      throw new RangeError('Invalid developer cultivation')
    }
    const next = copy(s)
    next.base.xp += xp - next.player.xp
    next.player.xp = xp
    Object.assign(next.player, stats(xp, next.loadout))
    const entryMaxHp = stats(next.base.xp, next.loadout).maxHp
    if (next.weaponState) next.weaponState.entryMaxHp = entryMaxHp
    if (next.armorState) {
      const a = next.armorState, m = armorModifiers(next.loadout.armor)
      a.entryMaxHp = entryMaxHp
      if (a.pending) a.pending.amount = Math.min(a.pending.damage, entryMaxHp * m.healFraction,
        entryMaxHp * Math.min(.1, m.healFloorCap) - a.healedTotal)
    }
    if (!validateTowerSnapshot(next)) throw new TypeError('Invalid developer snapshot')
    this.state = next
  }
  setPlaytestAssist(enabled) {
    if (typeof enabled !== 'boolean') throw new TypeError('Invalid playtest assist flag')
    this._playtestAssist = enabled
  }
  // Campaign has already authorized learning and paid its point/book costs.
  // Updating a detached candidate makes a rejected change atomic; callers get
  // a detached snapshot suitable for the same persistence transaction.
  setGrowthLoadout(loadout) {
    const s = this.state
    if (s.phase !== 'paused' || s.loadout.growthVersion !== 1 || loadout?.growthVersion !== 1
      || !validLoadout(loadout, s.player.xp) || !sameWeapon(s.loadout, loadout)
      || loadout.tutorialWaves !== s.loadout.tutorialWaves || loadout.skillsInitialized !== s.loadout.skillsInitialized || !validateTowerSnapshot(s)) {
      throw new TypeError('Invalid paused growth update')
    }
    const next = this.snapshot()
    next.loadout = copy(loadout)
    if ((loadout.active.sj_yujian||0)<(s.loadout.active.sj_yujian||0)) {
      next.projectiles=next.projectiles.filter(p=>p.source!=='sj_yujian')
      next.casts=next.casts.filter(c=>c.skill!=='sj_yujian')
      if(next.weaponState) {
        const live=new Set([...next.casts,...next.projectiles,...next.zones].map(c=>c.weaponCastId))
        next.weaponState.casts=next.weaponState.casts.filter(c=>live.has(c.id))
      }
    }
    readyNewSkills(next)
    Object.assign(next.player, stats(next.player.xp, next.loadout))
    if (!validateTowerSnapshot(next)) throw new TypeError('Invalid updated growth snapshot')
    this.state = next
    return this.snapshot()
  }
  setInput(x, y) {
    if (this.state.phase !== 'playing') return
    if (!finite(x) || !finite(y)) throw new RangeError('Invalid movement')
    const length = Math.max(1, Math.hypot(x, y))
    this.state.input = { x: x / length, y: y / length }
  }
  // Optional host bridge. Null means geometry-only visibility, never a claim of
  // device-camera validation. followPlayer opts into per-tick camera movement;
  // absent/false retains a fixed rectangle. Setting it does not advance time.
  setViewport(view) {
    if (!validView(view)) throw new RangeError('Invalid viewport')
    this.state.view = copy(view)
  }
  pause() { if (this.state.phase === 'playing') this.state.phase = 'paused' }
  resume() { if (this.state.phase === 'paused') this.state.phase = 'playing' }
  abandon() { if (['playing', 'paused'].includes(this.state.phase)) this.state.phase = 'abandoned' }

  advance(dt, onCast) {
    if (!finite(dt) || dt < 0 || dt > 60) throw new RangeError('Invalid simulation interval')
    const s = this.state
    if (s.phase !== 'playing') return s
    s.remainder += dt
    while (s.remainder + EPS >= STEP && s.phase === 'playing') {
      s.remainder = Math.max(0, s.remainder - STEP)
      this._tick(onCast)
    }
    // A terminal result cannot bank unplayed wall time into a later simulation.
    if (s.phase !== 'playing') s.remainder = 0
    s.remainder = Math.round(s.remainder * 1e12) / 1e12
    return s
  }

  _random() {
    let x = this.state.rng
    x ^= x << 13; x ^= x >>> 17; x ^= x << 5
    this.state.rng = x >>> 0
    return this.state.rng / 4294967296
  }
  _id(prefix) { return `${prefix}${this.state.nextId++}` }
  _passive(id, key, loadout = this.state.loadout) {
    const lv = loadout.passive[id]
    return lv ? levelValue(id, key, lv, loadout) : 0
  }
  _evolved(id, loadout = this.state.loadout) { return loadout.evolutions.includes(id) }
  _evolutionBudget(id, loadout = this.state.loadout) {
    return loadout.growthVersion === 1 ? GEVO[id].budgetMultipliers[loadout.evolutionLevels[id] - 1] : 1.1
  }
  _effect(kind, x, y, radius, extra = {}) {
    const effect = { id: this._id('fx'), kind, x, y, radius,
      hostile: false, startedAt: this.state.time, expiresAt: this.state.time + .25, ...extra }
    this.state.effects.push(effect)
    return effect
  }
  _registerWave() {
    const s = this.state
    s.waveStartedAt = s.time
    s.waveKilled = 0
    s.supportReleased = false
    s.supportAt = -1
    s.pending = plan(s).map(p => ({ ...p, retryAt: s.time, waitingSince: s.time }))
    s.wavePlanned = s.pending.length
    s.reserved = []
  }
  _spawnSafe(point, radius, ignore = '') {
    const s = this.state
    return (s.arenaVersion !== 1 || clearPillars(point, radius))
      && distance(point, s.player) >= 280
      && (s.arenaVersion === 1 ? insideHex(point, radius)
        : point.x >= BOUNDS.xmin + radius && point.x <= BOUNDS.xmax - radius
          && point.y >= BOUNDS.ymin + radius && point.y <= BOUNDS.ymax - radius)
      && [...s.enemies, ...s.reserved].every(e => e.id === ignore
        || distance(point, e) >= Math.max(92, radius + e.radius + 16))
  }
  _spawn() {
    const s = this.state, cap = FLOORS[s.floor - 1].concurrent_cap
    for (const r of [...s.reserved]) {
      if (r.readyAt > s.time + EPS) continue
      s.reserved = s.reserved.filter(x => x.id !== r.id)
      if (!this._spawnSafe(r, r.radius, r.id)) {
        const { x, y, radius, readyAt, ...pending } = r
        s.pending.push({ ...pending, retryAt: s.time + .25 })
      } else s.enemies.push(this._enemy(r))
    }
    for (const p of [...s.pending]) {
      if (s.enemies.length + s.reserved.length >= cap) break
      if (p.retryAt > s.time || (p.trigger === 'half' && !s.supportReleased)) continue
      if (A[p.archetype].role === 'elite'
        && (s.enemies.some(e => !e.temporary && e.role === 'elite')
          || s.reserved.some(e => A[e.archetype].role === 'elite'))) continue
      const due = (p.trigger === 'half' ? s.supportAt : s.waveStartedAt) + p.at
      if (s.time + EPS < due) continue
      const preferred = PORTALS.find(portal => portal.id === p.portal)
      const portals = s.time - p.waitingSince >= 15 ? [preferred, ...PORTALS.filter(x => x !== preferred)] : [preferred]
      const radius = radiusOf(p.archetype)
      const point = portals.flatMap(x => x.candidates).find(candidate => this._spawnSafe(candidate, radius))
      if (!point) { p.retryAt = s.time + .25; continue }
      s.pending = s.pending.filter(x => x.id !== p.id)
      s.reserved.push({ ...p, x: point.x, y: point.y, radius, readyAt: s.time + p.warning })
    }
  }
  _enemy(unit) {
    const s = this.state, a = A[unit.archetype]
    const authored = towerEnemyStats(a, s.floor, s.wave)
    const enemy = { id: unit.id, archetype: unit.archetype, name: a.name,
      family: familyOf(a.id), role: a.role, rank: a.rank, x: unit.x, y: unit.y,
      hp: authored.hp, maxHp: authored.hp, radius: radiusOf(a.id), damage: authored.damage, moveSpeed: authored.moveSpeed,
      woundBudget: 0, woundUntil: 0, orbitNextAt: 0,
      ai: { mode: 'approach', attack: null, readyAt: s.time + .8, graceUntil: s.time + .8,
        until: 0, eligibleSince: -1, sequence: 0, cooldowns: {}, faceX: 0, faceY: -1,
        orbitSign: this._random() < .5 ? -1 : 1, offset: this._random() * Math.PI * 2,
        phase: 1, transitionUntil: 0, transitionPending: false,
        entryUntil: s.time + (s.floor === 1 && a.role === 'boss' ? 1.2 : .8) } }
    initializeMonsterMechanics(this, enemy)
    return enemy
  }

  _targets(origin, reach, cap = Infinity) {
    return this.state.enemies.filter(e => e.hp > 0 && distance(e, origin) <= reach + e.radius
      && (this.state.arenaVersion !== 1 || pillarSight(origin,e)))
      .sort((a, b) => targetPriority(this, a) - targetPriority(this, b)
        || distance(a, origin) - distance(b, origin) || a.id.localeCompare(b.id)).slice(0, cap)
  }

  _tick(onCast) {
    const s = this.state
    s.ticks++
    s.time = s.ticks / 60
    this._pruneWeaponState()
    const p = s.player, oldPlayer = { x: p.x, y: p.y }
    const slow = s.zones.some(z => z.kind === 'web' && z.phase === 'active'
      && distance(z, p) <= z.radius + 18
      && (s.arenaVersion !== 1 || pillarSight(z,p))) ? .75 : 1
    const control = s.monsterControl
    const mechanicSlow = control && s.time < control.rootUntil ? 0
      : control && s.time < control.slowUntil ? 1 - control.slowFraction : 1
    p.x += s.input.x * p.moveSpeed * STEP * Math.min(slow, mechanicSlow)
    p.y += s.input.y * p.moveSpeed * STEP * Math.min(slow, mechanicSlow)
    boundActor(p, s.arenaVersion)
    if (s.view?.followPlayer === true) {
      // Translate before visibility checks, using actual slowed/clipped motion.
      const dx = p.x - oldPlayer.x, dy = p.y - oldPlayer.y
      s.view.xmin += dx; s.view.xmax += dx
      s.view.ymin += dy; s.view.ymax += dy
    }
    if (Math.hypot(s.input.x, s.input.y) > EPS) {
      const dir = facing(s.input.x, s.input.y)
      p.faceX = dir.x; p.faceY = dir.y
    }
    s.effects = s.effects.filter(e => e.expiresAt > s.time)
    s.gateEntries = s.gateEntries.filter(e => e.expiresAt > s.time)
    const incoming = [], outgoing = []
    this._enemyActions(incoming, oldPlayer)
    tickMonsterMechanics(this, incoming)
    this._skills(outgoing, onCast, oldPlayer)
    if(s.loadout.growthVersion===1) {
      s.yujian ||= newYujianState(p,s.time)
      turnYujian(s.yujian,p.faceX,s.time)
      s.yujian.x += (p.x-s.yujian.x)*.3
      s.yujian.y += (p.y-s.yujian.y)*.3
    }
    this._projectiles(incoming, outgoing, oldPlayer)
    this._zones(incoming, outgoing, onCast)
    for (const e of s.enemies) {
      if (e.woundBudget > 0) {
        const amount = Math.min(e.woundBudget, e.woundBudget * STEP / Math.max(STEP, e.woundUntil - s.time + STEP))
        e.woundBudget -= amount
        outgoing.push({ target: e.id, damage: amount, direct: false, scaled: true, source: 'wound' })
      }
    }
    // Collect both sides before resolving deaths. A projectile already in flight
    // from an actor alive at tick start is not erased by its same-tick death.
    for (const hit of outgoing) this._damageEnemy(hit)
    if (!this._playtestAssist && p.hp > 0 && s.time + EPS >= s.hurtUntil && incoming.length) {
      incoming.sort((a, b) => b.damage - a.damage || a.id.localeCompare(b.id))
      const damage = incoming[0].damage * (1 - Math.min(.15, this._passive('vajra', 'reduction')))
        * (1 - (s.loadout.armor ? clamp(armorModifiers(s.loadout.armor).reduction, 0, .06) : 0))
      const beforeHp = p.hp
      p.hp = Math.max(0, beforeHp - damage)
      this._scheduleArmorHeal(beforeHp - p.hp)
      if (p.hp > 0) this._applyMonsterControl(incoming[0].control)
      s.hurtUntil = s.time + .6
      s.nextWindupAt = Math.max(s.nextWindupAt, s.hurtUntil)
      this._effect('player_hit', p.x, p.y, 24, { damage })
    }
    // Resolve after incoming damage: a due heal cannot rescue a lethal hit in
    // this tick. Later hits neither stack nor postpone the original pending heal.
    this._resolveArmorHeal()
    this._deaths()
    const boss = s.enemies.find(e => e.role === 'boss')
    if (s.wave === 20 && !s.supportReleased
      && (boss && boss.hp <= boss.maxHp / 2 || s.killLedger.some(k => k.wave === 20 && A[k.archetype].role === 'boss'))) {
      s.supportReleased = true
      s.supportAt = s.time
    }
    if (p.hp <= 0) { s.phase = 'lost'; this._pruneWeaponState(); return }
    this._drops()
    this._spawn()
    this._requestAttacks()
    if (!s.pending.length && !s.reserved.length && !s.enemies.length && s.waveKilled === s.wavePlanned) {
      if (s.training) {
        // Reset only the private training ledger; training cannot become "won".
        s.killLedger = []; s.rawKillXp = 0
        this._registerWave()
      } else {
        const kind = FLOORS[s.floor - 1].waves[s.wave - 1].kind
        s.clearedWaves.push(s.wave)
        s.earned.contribution += 2 + (kind === 'elite' ? 5 : kind === 'boss' ? 45 + 5 * (s.floor - 1) : 0)
        if (kind === 'boss') s.earned.cores += 5 * (s.floor - 1)
        if (s.wave === 20) s.phase = 'won'
        else {
          s.wave++
          s.projectiles = []; s.zones = []; s.casts = []
          this._registerWave()
        }
      }
    }
    this._pruneWeaponState()
  }

  _applyMonsterControl(control) {
    const s = this.state, current = s.monsterControl
    if (!current || !control) return
    if (control.slowFraction > 0 && control.slowSeconds > 0) {
      current.slowFraction = Math.min(.3, Math.max(
        s.time < current.slowUntil ? current.slowFraction : 0, control.slowFraction))
      current.slowUntil = Math.max(current.slowUntil, s.time + Math.min(3, control.slowSeconds))
    }
    if (s.time < current.immuneUntil) return
    const duration = Math.min(.8, Math.max(0, control.rootSeconds || 0))
    if (duration > 0) {
      current.rootUntil = s.time + duration
      current.immuneUntil = current.rootUntil + 3
      // A control hit must not be followed by a new unavoidable attack.
      s.nextWindupAt = Math.max(s.nextWindupAt, current.rootUntil + 1.5)
    }
    const dx = control.knockbackX || 0, dy = control.knockbackY || 0
    const length = Math.hypot(dx, dy)
    // Ground mechanics have their own damage shapes; do not knock the player
    // into one. Walls/pillars use the same swept body clearance as movement.
    if (length > 0 && !s.monsterMechanics?.zones.some(z => z.phase === 'active')) {
      const travel = clippedRay(s.player, dx / length, dy / length, Math.min(64, length), 18, s.arenaVersion)
      s.player.x += dx / length * travel
      s.player.y += dy / length * travel
      boundActor(s.player, s.arenaVersion)
    }
  }

  _pruneWeaponState() {
    const s = this.state, w = s.weaponState
    if (!w) return
    const live = new Set([...s.casts, ...s.projectiles, ...s.zones].map(item => item.weaponCastId))
    w.casts = w.casts.filter(c => live.has(c.id))
  }

  _weaponCast(skillId) {
    const w = this.state.weaponState
    if (!w || !DIRECT_CAST_SKILLS.includes(skillId)) return {}
    const id = w.nextCastId++
    w.casts.push({ id, skillId, ordinal: null })
    return { weaponCastId: id }
  }

  _notifySkill(onCast, skill, releaseAt, dir, pulseIndex = 1, pulseCount = 1, startedAt = this.state.time) {
    if (typeof onCast !== 'function') return
    try {
      onCast(Object.freeze({ skill, startedAt, releaseAt,
        dirX: dir.x, dirY: dir.y, pulseIndex, pulseCount }))
    } catch { /* Observers cannot interrupt deterministic combat. */ }
  }

  _growthOrbit(level, outgoing, oldPlayer) {
    const s = this.state, p = s.player, loadout = s.loadout
    const form = formFor('sj_wanjian', level, loadout)
    const evolved = form.id === 'evo_wuwo'
    const bladeRadius = form.bladeWidth / 2
    const sweeps = []
    for (let i = 0; i < form.swords; i++) {
      const before = orbitSwordPose(form, Math.max(0, s.time - STEP), i)
      const after = orbitSwordPose(form, s.time, i)
      const a = before.collision ?? before, b = after.collision ?? after
      sweeps.push([
        { x: oldPlayer.x + a.baseX, y: oldPlayer.y + a.baseY },
        { x: oldPlayer.x + a.tipX, y: oldPlayer.y + a.tipY },
        { x: p.x + b.tipX, y: p.y + b.tipY },
        { x: p.x + b.baseX, y: p.y + b.baseY },
      ])
    }
    const radius = form.radius + form.bladeLength / 2 + bladeRadius + distance(p, oldPlayer)
    const hits = this._targets(p, radius).filter(e => e.orbitNextAt <= s.time + EPS
      && (evolved && distance(e, p) <= form.innerRadius + e.radius
        || sweeps.some(points => inPolygon(e, points, e.radius + bladeRadius))))
      .slice(0, form.targetCap)
    if (!hits.length) return
    const context = { castContext: castContext(s) }
    for (const e of hits) {
      const outer = distance(e, p) + e.radius >= form.radius - form.bladeLength / 2 - bladeRadius
      const factor = evolved ? (outer ? this._evolutionBudget('evo_wuwo') : GEVO.evo_wuwo.innerMultiplier[loadout.evolutionLevels.evo_wuwo - 1]) : 1
      outgoing.push({ target: e.id, damage: p.attack * levelValue('sj_wanjian', 'damage', level, loadout) * factor,
        direct: true, source: form.id, ...context })
      e.orbitNextAt = s.time + form.interval
    }
    this._effect(evolved ? 'wuwo' : 'orbit', p.x, p.y, form.radius,
      { ...formGeometry(form, 1, s.time), innerRadius: form.innerRadius,
        swords: form.swords, targetIds: hits.map(e => e.id) })
  }

  _growthSkills(outgoing, onCast, oldPlayer) {
    const s = this.state, p = s.player, loadout = s.loadout
    const convergenceDue = this._evolved('evo_wanjian') && s.cooldowns.evo_wanjian <= s.time + EPS
    const convergenceTarget = convergenceDue ? this._targets(p, 440)[0] : null
    // The special owns the ordinary sword's slot until the last impact. Waiting
    // for existing projectiles also prevents a half-finished ordinary volley
    // from becoming an unadvertised opening hit of the convergence.
    if (convergenceTarget
      && !s.casts.some(c => c.skill === 'sj_yujian')
      && !s.projectiles.some(shot => !shot.hostile && shot.source === 'sj_yujian'
        && (shot.yujianSlot===undefined || shot.dissolveAt===null))
      && !s.zones.some(z => z.kind === 'sword_rain' && z.ticks > 0)) {
      const form = skillForm('evo_wanjian', loadout.evolutionLevels.evo_wanjian, loadout.active.sj_yujian)
      const target = convergenceTarget
      if (target) {
        const total = p.attack * levelValue('sj_yujian', 'damage', loadout.active.sj_yujian, loadout)
          * convergenceRainMultiplier(loadout.evolutionLevels.evo_wanjian)
        const dir = facing(target.x - p.x, target.y - p.y, p.faceX, p.faceY)
        this._zone('sword_rain', target.x, target.y, form.radius, total / form.hits,
          form.initialDelay, form.hits, form.targetCap, form.interval, false, true,
          { ...formGeometry(form, 0, s.time), formId: form.id, formLevel: loadout.evolutionLevels.evo_wanjian,
            parentLevel: loadout.active.sj_yujian, originX: p.x, originY: p.y, dirX: dir.x, dirY: dir.y,
            faceX: dir.x, faceY: dir.y, castContext: castContext(s) })
        s.cooldowns.evo_wanjian = s.time + skillCooldown(GEVO.evo_wanjian.rainCooldown, loadout)
        s.cooldowns.sj_yujian = s.time + form.duration + skillCooldown(GS.sj_yujian.cooldown, loadout)
        this._notifySkill(onCast, form.id, s.time + form.initialDelay, dir, 1, form.hits)
      }
    }
    for (const [id, level] of Object.entries(loadout.active)) {
      if (id === 'sj_wanjian') { this._growthOrbit(level, outgoing, oldPlayer); continue }
      if (id === 'sj_yujian' && (convergenceTarget
        || s.zones.some(z => z.kind === 'sword_rain' && z.ticks > 0))) continue
      if (s.cooldowns[id] > s.time + EPS || s.casts.some(c => c.skill === id)) continue
      const form = formFor(id, level, loadout)
      const searchReach = form.shape === 'cross' ? Math.hypot(form.width,form.width/2)+form.bladeWidth/2
        : form.shape === 'sector' ? form.radius : form.reach
      const spiritReach=id==='sj_yujian' ? 1+this._passive('sj_spirit','reach_bonus') : 1
      const target = this._targets(p, searchReach*spiritReach)[0]
      if (!target) continue
      const dir = facing(target.x - p.x, target.y - p.y, p.faceX, p.faceY)
      p.faceX = dir.x; p.faceY = dir.y
      const tiandi = form.id === 'evo_tiandi'
      const windup = tiandi ? GEVO.evo_tiandi.windup : GS[id].windup
      const c = { skill: id, level, x: p.x, y: p.y, targetX: target.x, targetY: target.y,
        dirX: dir.x, dirY: dir.y, releaseAt: s.time + windup, startedAt: s.time,
        formId: form.id, pulseIndex: 0, pulseCount: form.hits,
        castContext: castContext(s), ...this._weaponCast(id) }
      s.casts.push(c)
      s.cooldowns[id] = s.time + skillCooldown(tiandi ? GEVO.evo_tiandi.cooldown : GS[id].cooldown, loadout)
      this._notifySkill(onCast, form.id, c.releaseAt + form.initialDelay, dir, 1, form.hits)
      if (tiandi) {
        c.lockAt = c.releaseAt - .15
        c.locked = false
        c.windupEffectId = this._effect('tiandi_windup', p.x, p.y, form.width / 2,
          { ...formGeometry(form, 0, s.time), dirX: dir.x, dirY: dir.y, faceX: dir.x, faceY: dir.y,
            toX: p.x + dir.x * form.reach, toY: p.y + dir.y * form.reach,
            expiresAt: c.releaseAt, phase: 'windup' }).id
      }
    }
    for (const c of [...s.casts]) {
      if (c.formId === 'evo_tiandi') {
        if (!c.locked) {
          c.x = p.x; c.y = p.y
          const form = formFor(c.skill, c.level, c.castContext.loadout)
          const target = this._targets(p, form.reach)[0]
          if (target) {
            const dir = facing(target.x - p.x, target.y - p.y, c.dirX, c.dirY)
            c.dirX = dir.x; c.dirY = dir.y
          }
          if (s.time + EPS >= c.lockAt) {
            c.locked = true
            this._notifySkill(onCast, c.formId, c.releaseAt, { x: c.dirX, y: c.dirY }, 1, 1, c.startedAt)
          }
        }
        const effect = s.effects.find(e => e.id === c.windupEffectId)
        if (effect) Object.assign(effect, { x: c.x, y: c.y, dirX: c.dirX, dirY: c.dirY,
          faceX: c.dirX, faceY: c.dirY, toX: c.x + c.dirX * effect.reach, toY: c.y + c.dirY * effect.reach,
          locked: c.locked })
      }
      if (c.releaseAt > s.time + EPS) continue
      if (c.pulseIndex > 0) this._notifySkill(onCast, c.formId, s.time,
        { x: c.dirX, y: c.dirY }, c.pulseIndex + 1, c.pulseCount)
      this._releaseSkill(c, outgoing)
      if (c.formId && ['sj_arc', 'sj_line'].includes(c.skill) && c.pulseIndex < c.pulseCount) {
        c.releaseAt += formFor(c.skill, c.level, c.castContext.loadout).interval
      } else s.casts = s.casts.filter(item => item !== c)
    }
  }

  _releaseGrowthSkill(c, outgoing) {
    const s = this.state, p = s.player, loadout = c.castContext.loadout, id = c.skill
    const form = formFor(id, c.level, loadout)
    const attack = stats(c.castContext.xp, loadout).attack
    const base = attack * levelValue(id, 'damage', c.level, loadout)
    const context = { castContext: c.castContext,
      ...(c.weaponCastId === undefined ? {} : { weaponCastId: c.weaponCastId }) }
    const dir = { x: c.dirX, y: c.dirY }
    c.pulseIndex++
    if (id === 'sj_yujian') {
      s.yujian ||= newYujianState(p,s.time)
      const busy=s.projectiles.filter(shot=>shot.yujianSlot!==undefined)
      const slots=Array.from({length:form.swords},(_,i)=>i).filter(i=>!busy.some(shot=>shot.yujianSlot===i))
      const reach=form.reach*(1+this._passive('sj_spirit','reach_bonus',loadout))
      const targets = this._targets(p, reach, form.targetCap)
        .filter(target=>!busy.some(shot=>shot.targetId===target.id && shot.dissolveAt===null))
      const face=c.dirX<0?-1:1
      for (let i = 0; i < Math.min(slots.length, targets.length); i++) {
        const target = targets[i], slot=slots[i], hover=yujianHoverPose(slot,s.time,s.yujian)
        const offset=clippedRay(p,face,0,32,7,s.arenaVersion)
        // A blocked muzzle cannot place a projectile on the far side of a wall.
        if(offset<8)continue
        const flightAt=s.time+.32+i*.042
        this._projectile(p.x+face*offset, p.y, face*680, 0, 7, base * (i === 0 ? 1 : levelValue('sj_yujian','secondary_share',c.level,loadout)), false,
          { ...formGeometry(form, i + 1, s.time), radius: 7, targetId: target.id,
            expiresAt: flightAt+reach/680+1, ...context,
            yujianSlot:slot, launchFace:face, gatherAt:s.time, flightAt,
            hoverX:hover.x,hoverY:hover.y,hoverAngle:yujianHeading(s.yujian,s.time),
            dissolveAt:null,trail:[] })
      }
    } else if (SWORD_QI_SOURCES.includes(id) && form.shape.endsWith('-projectile')) {
      // The release is only a projectile. It does not also settle the retired
      // instantaneous sector, and later waves get the current caster position.
      const offset = swordQiReleaseOffset(form)
      const x=p.x+dir.x*offset, y=p.y+dir.y*offset
      const range=swordQiTravelLimit(form.bladeKind,form.width,form.bladeWidth,
        {x,y},dir.x,dir.y,SWORD_QI_MAX_TRAVEL,s.arenaVersion)
      // A blade with no room at its release position is blocked by terrain.
      // Do not render an already out-of-bounds body or settle an invisible hit.
      if (range <= EPS) return
      this._projectile(x,y,dir.x*form.speed,dir.y*form.speed,form.bladeWidth/2,
        base*skillHitShare(id,c.level,c.pulseIndex),false,{
          ...formGeometry(form,c.pulseIndex,s.time), radius:form.bladeWidth/2,
          bladeKind:form.bladeKind,bladeWidth:form.bladeWidth,speed:form.speed,
          dirX:dir.x,dirY:dir.y,originX:x,originY:y,range,travelled:0,
          dissolveAt:null,
          expiresAt:s.time+range/form.speed+SWORD_QI_TAIL,...context,
        })
    } else if (id === 'sj_cross') {
      const depth=swordQiReleaseOffset(form)
      const front={x:p.x+dir.x*depth,y:p.y+dir.y*depth}
      const targets=this._targets(p,Math.hypot(form.width,form.width/2)+form.bladeWidth/2)
        .filter(e=>swordQiHits('cross',form.width,form.bladeWidth,front,front,dir.x,dir.y,e))
        .slice(0,form.targetCap)
      for(const e of targets)outgoing.push({target:e.id,damage:base,direct:true,source:id,...context})
      this._effect('cross',front.x,front.y,form.radius,{
        ...formGeometry(form,1,s.time),bladeKind:'cross',bladeWidth:form.bladeWidth,
        dirX:dir.x,dirY:dir.y,faceX:dir.x,faceY:dir.y,targetIds:targets.map(e=>e.id),...context,
      })
    } else if (id === 'sj_arc') {
      const targets = this._targets(p, form.radius).filter(e => inSector(e, p, dir, form.radius, form.angle, e.radius))
        .slice(0, form.targetCap)
      for (const e of targets) outgoing.push({ target: e.id, damage: base * skillHitShare(id, c.level, c.pulseIndex), direct: true, source: id, ...context })
      this._effect('arc', p.x, p.y, form.radius, { ...formGeometry(form, c.pulseIndex, s.time),
        faceX: dir.x, faceY: dir.y, dirX: dir.x, dirY: dir.y, targetIds: targets.map(e => e.id) })
    } else if (id === 'sj_line') {
      if (c.pulseIndex === 1 && form.id !== 'evo_tiandi') { c.x = p.x; c.y = p.y }
      const reach = clippedRay(c, dir.x, dir.y, form.reach, form.width / 2, s.arenaVersion)
      const end = { x: c.x + dir.x * reach, y: c.y + dir.y * reach }
      const targets = this._targets(c, reach + form.width / 2)
        .filter(e => segmentDistance(e, c, end) <= form.width / 2 + e.radius).slice(0, form.targetCap)
      const total = form.id === 'evo_tiandi' ? base * GEVO.evo_tiandi.cooldown / GS.sj_line.cooldown
        * this._evolutionBudget('evo_tiandi', loadout) : base
      for (const e of targets) outgoing.push({ target: e.id, damage: total / form.hits, direct: true, source: form.id, ...context })
      this._effect(form.id === 'evo_tiandi' ? 'tiandi' : 'line', c.x, c.y, form.width / 2,
        { ...formGeometry(form, c.pulseIndex, s.time), radius: form.width / 2, reach,
          dirX: dir.x, dirY: dir.y, faceX: dir.x, faceY: dir.y, toX: end.x, toY: end.y,
          targetIds: targets.map(e => e.id) })
    } else if (id === 'sj_shadow' || id === 'sj_formation') {
      const formation = id === 'sj_formation'
      const total = formation ? base * GS.sj_formation.ticks
        * (form.id === 'evo_sixiang' ? this._evolutionBudget('evo_sixiang', loadout) : 1) : base
      this._zone(formation ? 'formation' : 'shadow', c.targetX, c.targetY, form.radius,
        total / form.hits, form.initialDelay, form.hits, form.targetCap, form.interval || 1,
        false, !formation, { ...formGeometry(form, 0, s.time), formId: form.id,
          formLevel: loadout.evolutionLevels[form.id] ?? c.level, parentLevel: c.level,
          dirX: dir.x, dirY: dir.y, faceX: dir.x, faceY: dir.y, ...context })
    }
  }

  _skills(outgoing, onCast, oldPlayer = this.state.player) {
    const s = this.state, p = s.player, loadout = s.loadout
    const growth = loadout.growthVersion === 1
    if (growth) return this._growthSkills(outgoing, onCast, oldPlayer)
    const table = growth ? GS : S
    const value = (id, key, lv) => levelValue(id, key, lv, loadout)
    const context = growth ? { castContext: castContext(s) } : {}
    for (const [id, lv] of Object.entries(s.loadout.active)) {
      if (id === 'sj_wanjian') {
        const outer = value(id, 'radius', lv)
        for (const e of this._targets(p, outer, table[id].target_cap ?? 6)) {
          if (e.orbitNextAt > s.time + EPS) continue
          let factor = value(id, 'damage', lv)
          if (this._evolved('evo_wuwo')) factor *= distance(e, p) + e.radius >= outer / 2
            ? this._evolutionBudget('evo_wuwo') : (growth ? GEVO.evo_wuwo.innerMultiplier[loadout.evolutionLevels.evo_wuwo - 1] : .5)
          outgoing.push({ target: e.id, damage: p.attack * factor, direct: true, source: id, ...context })
          e.orbitNextAt = s.time + (table[id].hit_interval ?? .6)
          this._effect(this._evolved('evo_wuwo') ? 'wuwo' : 'orbit', p.x, p.y, outer)
        }
        continue
      }
      if (s.cooldowns[id] > s.time + EPS || s.casts.some(c => c.skill === id)) continue
      const reach = id === 'sj_arc' ? value(id, 'radius', lv) : value(id, 'reach', lv) ?? 360
      const target = this._targets(p, reach)[0]
      if (!target) continue
      const dir = facing(target.x - p.x, target.y - p.y, p.faceX, p.faceY)
      p.faceX = dir.x; p.faceY = dir.y
      const evolvedLine = id === 'sj_line' && this._evolved('evo_tiandi')
      const windup = evolvedLine ? (growth ? GEVO.evo_tiandi.windup : .9)
        : (table[id].windup ?? (id === 'sj_arc' ? .18 : .12))
      s.casts.push({ skill: id, level: lv, x: p.x, y: p.y, targetX: target.x, targetY: target.y,
        dirX: dir.x, dirY: dir.y, releaseAt: s.time + windup, ...context, ...this._weaponCast(id) })
      s.cooldowns[id] = s.time + skillCooldown(evolvedLine ? (growth ? GEVO.evo_tiandi.cooldown : 6) : table[id].cooldown, loadout)
      // Optional presentation notification: primitives only, no saved event queue
      // and no dependency on cooldown formulas or surviving projectiles.
      if (typeof onCast === 'function') {
        try {
          onCast(Object.freeze({ skill: id, startedAt: s.time, releaseAt: s.time + windup,
            dirX: dir.x, dirY: dir.y }))
        } catch { /* Rendering observers must never interrupt combat settlement. */ }
      }
      if (evolvedLine) this._effect('tiandi_windup', p.x, p.y, 14,
        { toX: p.x + dir.x * reach, toY: p.y + dir.y * reach, expiresAt: s.time + windup, phase: 'windup' })
    }
    if (this._evolved('evo_wanjian') && s.cooldowns.evo_wanjian <= s.time + EPS) {
      const target = this._targets(p, 440)[0]
      if (target) {
        const evolution = GEVO.evo_wanjian
        const cooldown = growth ? evolution.rainCooldown : 8
        const ticks = growth ? evolution.rainTicks : 6
        const interval = growth ? evolution.rainTickInterval : .2
        const damage = growth ? value('sj_yujian', 'damage', loadout.active.sj_yujian)
          / table.sj_yujian.cooldown * (this._evolutionBudget('evo_wanjian') - evolution.regularMultiplier)
          * cooldown / ticks : .352
        s.cooldowns.evo_wanjian = s.time + skillCooldown(cooldown, loadout)
        this._zone('sword_rain', target.x, target.y, growth ? evolution.rainRadius : 160,
          damage * p.attack, interval, ticks, growth ? evolution.rainTargetCap : 6, interval, false, true, context)
      }
    }
    for (const cast of s.casts.filter(c => c.releaseAt <= s.time + EPS)) {
      this._releaseSkill(cast, outgoing)
      s.casts = s.casts.filter(c => c !== cast)
    }
  }
  _releaseSkill(c, outgoing) {
    const s = this.state, p = s.player, id = c.skill, lv = c.level
    const loadout = c.castContext?.loadout ?? s.loadout
    const growth = loadout.growthVersion === 1, table = growth ? GS : S
    if (growth && c.formId) return this._releaseGrowthSkill(c, outgoing)
    const value = key => levelValue(id, key, lv, loadout)
    const evolved = evo => this._evolved(evo, loadout)
    const attack = c.castContext ? stats(c.castContext.xp, loadout).attack : p.attack
    const context = c.castContext ? { castContext: c.castContext } : {}
    if (c.weaponCastId !== undefined) context.weaponCastId = c.weaponCastId
    const dir = { x: c.dirX, y: c.dirY }
    const base = attack * value('damage')
    if (id === 'sj_yujian') {
      const count = value('swords'), reach = value('reach')
      const targets = this._targets(p, reach, value('target_cap'))
      const damage = (evolved('evo_wanjian')
        ? (growth ? base * GEVO.evo_wanjian.regularMultiplier : attack * 1.188) : base) / count
      for (let i = 0; i < (growth ? Math.min(count, targets.length) : count) && targets.length; i++) {
        const target = targets[growth ? i : i % targets.length]
        const heading = facing(target.x - p.x, target.y - p.y)
        this._projectile(p.x, p.y, heading.x * 680, heading.y * 680, 7,
          growth ? damage * count * (i === 0 ? 1 : levelValue('sj_yujian','secondary_share',lv,loadout)) : damage, false,
          { targetId: target.id, source: id, expiresAt: s.time + reach / 680 + .2, ...context })
      }
    } else if (id === 'sj_arc') {
      const radius = value('radius'), angle = table[id].angle ?? 90
      const targets = this._targets(c, radius).filter(e => inSector(e, c, dir, radius, angle, e.radius))
        .slice(0, table[id].target_cap ?? 6)
      targets.forEach(e => outgoing.push({ target: e.id, damage: base, direct: true, source: id, ...context }))
      this._effect('arc', c.x, c.y, radius, { shape: 'sector', angle, faceX: dir.x, faceY: dir.y })
    } else if (id === 'sj_line') {
      const reach = value('reach'), width = table[id].width ?? 28
      const end = { x: c.x + dir.x * reach, y: c.y + dir.y * reach }
      const damage = evolved('evo_tiandi') ? (growth
        ? base * GEVO.evo_tiandi.cooldown / table[id].cooldown * this._evolutionBudget('evo_tiandi', loadout)
        : 2.7225 * attack) : base
      this._targets(c, reach).filter(e => segmentDistance(e, c, end) <= width / 2 + e.radius)
        .slice(0, value('target_cap'))
        .forEach(e => outgoing.push({ target: e.id, damage, direct: true, source: id, ...context }))
      this._effect(evolved('evo_tiandi') ? 'tiandi' : 'line', c.x, c.y, width / 2,
        { toX: end.x, toY: end.y, width })
    } else if (id === 'sj_shadow') {
      this._zone('shadow', c.targetX, c.targetY, value('radius'), base, table[id].delay ?? .65,
        1, table[id].target_cap ?? 6, 1, false, true, context)
    } else if (id === 'sj_formation') {
      const evolution = evolved('evo_sixiang')
      const damage = evolution ? (growth ? base * this._evolutionBudget('evo_sixiang', loadout) : .22 * attack) : base
      const interval = table[id].hit_interval ?? .5
      const z = this._zone('formation', c.targetX, c.targetY, value('radius'),
        damage, interval, table[id].ticks ?? 6, table[id].target_cap ?? 8, interval, false, false, context)
      z.eyes = evolution ? (growth ? GEVO.evo_sixiang.eyes : 4) : 2 // One shared six-tick ledger.
    }
  }

  _projectile(x, y, vx, vy, radius, damage, hostile, extra = {}) {
    this.state.projectiles.push({ id: this._id('p'), x, y, vx, vy, radius, damage,
      hostile, hitIds: [], expiresAt: this.state.time + 4, source: 'enemy', ...extra })
  }
  _zone(kind, x, y, radius, damage, delay, ticks, targetCap, interval, hostile, direct, extra = {}) {
    const z = { id: this._id('z'), kind, x, y, radius, damage, hostile, direct,
      phase: 'windup', nextAt: this.state.time + delay, ticks, interval, targetCap,
      expiresAt: this.state.time + delay + (ticks - 1) * interval + .2, renderOnly: false, ...extra }
    this.state.zones.push(z)
    return z
  }
  _projectiles(incoming, outgoing, oldPlayer) {
    const s = this.state
    for (const shot of s.projectiles) {
      if(shot.yujianSlot!==undefined && shot.dissolveAt===null && shot.expiresAt<=s.time) {
        shot.dissolveAt=s.time;shot.expiresAt=s.time+YUJIAN_TAIL
      }
      if (shot.expiresAt <= s.time) continue
      if(shot.yujianSlot!==undefined) {
        if(shot.dissolveAt!==null)continue
        const pose=yujianVisualPose(shot,s.time)
        shot.trail.push({...pose,at:s.time})
        shot.trail=shot.trail.filter(a=>s.time-a.at<=YUJIAN_TAIL).slice(-24)
        if(s.time<shot.flightAt)continue
        const target=s.enemies.find(e=>e.id===shot.targetId&&e.hp>0)
        if(!target) {
          shot.dissolveAt=s.time;shot.expiresAt=s.time+YUJIAN_TAIL;continue
        }
        stepYujianFlight(shot,target,s.time,STEP)
      }
      if (shot.bladeKind) {
        if (shot.dissolveAt !== null) continue
        const old={x:shot.x,y:shot.y}
        shot.travelled=Math.min(shot.range,shot.travelled+shot.speed*STEP)
        shot.x=shot.originX+shot.dirX*shot.travelled
        shot.y=shot.originY+shot.dirY*shot.travelled
        const hits=s.enemies.filter(e=>e.hp>0 && !shot.hitIds.includes(e.id)
          && swordQiHits(shot.bladeKind,shot.width,shot.bladeWidth,old,shot,shot.dirX,shot.dirY,e))
          .sort((a,b)=>distance(a,old)-distance(b,old)||a.id.localeCompare(b.id))
          .slice(0,Math.max(0,shot.targetCap-shot.hitIds.length))
        for(const e of hits) {
          shot.hitIds.push(e.id)
          outgoing.push({target:e.id,damage:shot.damage,direct:true,source:shot.source,
            castContext:shot.castContext,weaponCastId:shot.weaponCastId})
        }
        if(shot.travelled>=shot.range-EPS) {
          shot.dissolveAt=s.time;shot.expiresAt=s.time+SWORD_QI_TAIL
        }
        continue
      }
      if (!shot.hostile && shot.targetId && shot.yujianSlot===undefined) {
        const target = s.enemies.find(e => e.id === shot.targetId && e.hp > 0)
        if (target) {
          const speed = Math.hypot(shot.vx, shot.vy), dir = facing(target.x - shot.x, target.y - shot.y)
          shot.vx = dir.x * speed; shot.vy = dir.y * speed
        }
      }
      const old = { x: shot.x, y: shot.y }
      const speed=Math.hypot(shot.vx,shot.vy)
      const wall = shot.yujianSlot!==undefined && speed>0
        ? Math.min(STEP,clippedRay(old,shot.vx/speed,shot.vy/speed,speed*STEP,shot.radius,s.arenaVersion)/speed)
        : s.arenaVersion === 1 ? clipPillars(old,shot.vx,shot.vy,STEP,shot.radius) : STEP
      shot.x += shot.vx * wall; shot.y += shot.vy * wall
      if(wall < STEP - EPS) {
        shot.expiresAt=0
        if(shot.yujianSlot!==undefined) {
          shot.dissolveAt=s.time;shot.expiresAt=s.time+YUJIAN_TAIL
        }
      }
      if (shot.hostile) {
        const relativeOld = { x: old.x - oldPlayer.x + s.player.x, y: old.y - oldPlayer.y + s.player.y }
        if (segmentDistance(s.player, relativeOld, shot) <= 18 + shot.radius) {
          incoming.push({ id: shot.id, damage: shot.damage })
          shot.expiresAt = 0
        }
      } else {
        const hits = s.enemies.filter(e => e.hp > 0 && !shot.hitIds.includes(e.id)
          && !(shot.castContext?.loadout.growthVersion === 1 && shot.source === 'sj_yujian'
            && shot.targetId && shot.targetId !== e.id)
          && segmentDistance(e, old, shot) <= e.radius + shot.radius)
          .sort((a, b) => distance(a, old) - distance(b, old))
        if (hits.length) {
          outgoing.push({ target: hits[0].id, damage: shot.damage, direct: true, source: shot.source,
            castContext: shot.castContext, weaponCastId: shot.weaponCastId })
          shot.hitIds.push(hits[0].id)
          shot.expiresAt = 0
          if(shot.yujianSlot!==undefined) {
            shot.dissolveAt=s.time;shot.expiresAt=s.time+YUJIAN_TAIL
          }
        }
      }
    }
    s.projectiles = s.projectiles.filter(p => p.expiresAt > s.time)
  }
  _growthZonePulse(z, outgoing, onCast) {
    const s = this.state, form = skillForm(z.formId, z.formLevel, z.parentLevel)
    const pulse = ++z.pulseIndex
    let origin = z, end = null, width = form.width, kind = z.kind, shape = form.shape
    let targets, terminal = false
    if (z.kind === 'shadow') {
      const offsets = [0, Math.PI / 2, Math.PI / 4, -Math.PI / 4]
      const angle = Math.atan2(z.dirY, z.dirX) + offsets[pulse - 1]
      const dx = Math.cos(angle), dy = Math.sin(angle)
      origin = { x: z.x - dx * form.radius, y: z.y - dy * form.radius }
      end = { x: z.x + dx * form.radius, y: z.y + dy * form.radius }
    } else if (z.kind === 'sword_rain') {
      kind = 'convergence'; shape = 'line'; terminal = pulse === form.hits
      if (terminal) {
        origin = { x: z.originX, y: z.originY }
        const length = distance(origin, z) + form.radius
        end = { x: origin.x + z.dirX * length, y: origin.y + z.dirY * length }
        width = form.width * 2
        this._notifySkill(onCast, form.id, s.time, { x: z.dirX, y: z.dirY }, pulse, form.hits)
        s.cooldowns.sj_yujian = Math.max(s.cooldowns.sj_yujian,
          s.time + skillCooldown(GS.sj_yujian.cooldown, z.castContext.loadout))
      } else {
        const angle = Math.atan2(z.dirY, z.dirX) + (pulse - 1) * Math.PI * 2 / form.swords
        origin = { x: z.x + Math.cos(angle) * form.radius, y: z.y + Math.sin(angle) * form.radius }
        end = { x: z.x, y: z.y }
      }
    }
    let extra = {}
    if (end) {
      const dir = facing(end.x - origin.x, end.y - origin.y)
      const reach = clippedRay(origin, dir.x, dir.y, distance(origin, end), width / 2, s.arenaVersion)
      end = { x: origin.x + dir.x * reach, y: origin.y + dir.y * reach }
      targets = this._targets(origin, reach + width / 2)
        .filter(e => segmentDistance(e, origin, end) <= width / 2 + e.radius).slice(0, form.targetCap)
      extra = { width, reach, dirX: dir.x, dirY: dir.y, faceX: dir.x, faceY: dir.y,
        toX: end.x, toY: end.y, terminal }
    } else if (form.shape === 'diamond') {
      const vertices = [{ x: z.x, y: z.y - form.radius }, { x: z.x + form.radius, y: z.y },
        { x: z.x, y: z.y + form.radius }, { x: z.x - form.radius, y: z.y }]
      targets = this._targets(z, form.radius)
        .filter(e => inPolygon(e, vertices, e.radius)).slice(0, form.targetCap)
    } else targets = this._targets(z, form.radius, form.targetCap)
    for (const e of targets) outgoing.push({ target: e.id, damage: z.damage, direct: z.direct, source: z.kind,
      castContext: z.castContext, weaponCastId: z.weaponCastId })
    this._effect(kind, origin.x, origin.y, form.radius,
      { ...formGeometry(form, pulse, s.time), shape, ...extra, targetIds: targets.map(e => e.id) })
  }

  _zones(incoming, outgoing, onCast) {
    const s = this.state
    for (const z of s.zones) {
      if (z.renderOnly || z.ticks <= 0 || z.nextAt > s.time + EPS) continue
      z.phase = 'active'
      if (z.hostile) {
        if (!this._playtestAssist && distance(z, s.player) <= z.radius + 18
          && (s.arenaVersion !== 1 || pillarSight(z,s.player))) {
          incoming.push({ id: `${z.id}:${z.ticks}`, damage: z.damage })
        }
      } else if (z.formId) {
        this._growthZonePulse(z, outgoing, onCast)
      } else {
        this._targets(z, z.radius, z.targetCap).forEach(e =>
          outgoing.push({ target: e.id, damage: z.damage, direct: z.direct, source: z.kind,
            castContext: z.castContext, weaponCastId: z.weaponCastId }))
      }
      z.ticks--
      z.nextAt += z.interval
    }
    s.zones = s.zones.filter(z => z.expiresAt > s.time)
  }
  _damageEnemy(hit) {
    const s = this.state, e = s.enemies.find(e => e.id === hit.target && e.hp > 0)
    if (!e) return
    const loadout = hit.castContext?.loadout ?? s.loadout
    let damage = hit.damage
    let focus = false, critical = false
    if (!hit.scaled) {
      damage *= 1 + this._passive('sj_bone', 'damage_bonus', loadout)
      if (loadout.weapon) {
        const skillId = weaponSkill(hit.source)
        const damageType = GS[skillId]?.damageType ?? 'none'
        const modifiers = weaponDamageModifiers(loadout.weapon, skillId, damageType)
        const ring = loadout.ring ? ringDamageModifiers(loadout.ring)
          : { critChance: 0, critBonus: 0, special: 0 }
        const direct = hit.direct && !continuousSource(hit.source) && damageType !== 'none'
        const w = s.weaponState
        const cast = direct && ring.special > 0 && damage > 0
          && w?.casts.find(c => c.id === hit.weaponCastId && c.skillId === skillId)
        if (cast) {
          if (cast.ordinal === null) {
            cast.ordinal = ++w.effectiveCasts
            w.focusCount = (w.focusCount + 1) % 5
          }
          focus = ring.special > 0
            && ((s.training ? 0 : s.loadout.weaponFocusCount) + cast.ordinal) % 5 === 0
        }
        // All added weapon shares use the same noncritical baseline N. Keep
        // the original crit extra (pre-bone damage * .5) independent of A/S/F.
        const baseline = damage
        damage = baseline * (1 + modifiers.flat + (focus ? ring.special : 0))
        if (direct && this._random() < clamp(this._passive('sj_heart', 'crit_chance', loadout)
          + ring.critChance, 0, 1)) {
          critical = true
          damage += hit.damage * .5 + baseline * ring.critBonus
        }
      } else if (hit.direct && this._random() < this._passive('sj_heart', 'crit_chance', loadout)) {
        critical = true
        damage += hit.damage * .5
      }
    }
    damage *= monsterDamageMultiplier(this, e)
    const effective = Math.min(e.hp, damage)
    e.hp = Math.max(0, e.hp - effective)
    if (hit.direct && !hit.scaled) {
      e.woundBudget += effective * this._passive('sj_mark', 'wound_share', loadout)
      e.woundUntil = s.time + 2
      const gate = effective * this._passive('sj_gate', 'share', loadout)
      if (gate) s.gateEntries.push({ amount: gate, expiresAt: s.time + 10 })
    }
    if (e.hp <= 0) e.killedBy = hit.source
    this._effect('hit', e.x, e.y, 12, { damage: effective, source: hit.source,
      ...(['formation', 'evo_wuwo'].includes(hit.source) ? { targetId: e.id, targetRadius: e.radius } : {}),
      ...(critical ? { critical: true } : {}),
      ...(loadout.weapon && focus ? { weaponFocus: true } : {}) })
  }
  _scheduleArmorHeal(damage) {
    const s = this.state, a = s.armorState
    if (!a || damage <= 0 || s.player.hp <= 0 || a.pending || s.time + EPS < a.cooldownUntil) return
    const m = armorModifiers(s.loadout.armor)
    const amount = Math.min(damage, a.entryMaxHp * m.healFraction,
      a.entryMaxHp * Math.min(.1, m.healFloorCap) - a.healedTotal)
    if (amount <= 0) return
    a.lastTriggerAt = s.time
    a.cooldownUntil = s.time + m.healCooldown
    a.triggerCount++
    a.pending = { triggeredAt: s.time, dueAt: s.time + m.healDelay, damage, amount }
  }

  _resolveArmorHeal() {
    const s = this.state, p = s.player, a = s.armorState
    if (!a?.pending) return
    if (p.hp <= 0) { a.pending = null; return }
    if (s.time + EPS < a.pending.dueAt) return
    const m = armorModifiers(s.loadout.armor)
    const amount = Math.max(0, Math.min(a.pending.amount, p.maxHp - p.hp,
      a.entryMaxHp * Math.min(.1, m.healFloorCap) - a.healedTotal))
    a.pending = null
    if (amount <= 0) return
    p.hp += amount
    a.healedTotal += amount
    this._effect('armor_heal', p.x, p.y, 18, { amount })
  }
  _gainXp(amount) {
    const s = this.state, p = s.player
    let previous = cultivationAt(p.xp)
    const gained = Math.min(TOWER_XP_CAP - p.xp, amount)
    p.xp += gained
    s.earned.xp += gained
    Object.assign(p, stats(p.xp, s.loadout))
    // Incoming damage resolves before kill rewards. Leveling cannot revive a
    // player killed in this tick, and loading a snapshot never enters this path.
    if (p.hp <= 0) return
    const finalLevel = cultivationAt(p.xp).level
    for (let level = previous.level + 1; level <= finalLevel; level++) {
      const lowerLevel = level - 1
      const levelXp = 30 * lowerLevel + 15 * lowerLevel * lowerLevel
      const next = cultivationAt(levelXp)
      const maxHp = stats(levelXp, s.loadout).maxHp
      p.hp = next.realm !== previous.realm
        ? maxHp
        : Math.min(maxHp, p.hp + maxHp * .3)
      previous = next
    }
  }
  _deaths() {
    const s = this.state
    const coreDrops = s.loot ? buildCoreDropPlan(s.floor, s.loot.seed) : null
    // Gate-triggered deaths may award kills, but never trigger another gate.
    for (let pass = 0; pass < 2; pass++) {
      const dead = s.enemies.filter(e => e.hp <= 0)
      onMonsterDeaths(this, dead)
      s.enemies = s.enemies.filter(e => e.hp > 0)
      for (const e of dead) {
        if (!e.temporary) {
          s.waveKilled++
          const kill = { id: e.id, archetype: e.archetype, wave: s.wave }
          if (coreDrops) kill.coreRank = coreRankFor(s, kill, coreDrops)
          s.killLedger.push(kill)
          const xp = towerKillXp(s.floor, s.wave, e.id.split(':').pop()) ?? demonEssenceXp(e.rank, e.role)
          s.rawKillXp += xp
          if (!s.training) {
            this._gainXp(xp)
            if (coreDrops) {
              s.earned.cores += CORE_RANK_VALUES[kill.coreRank]
              if (kill.coreRank) s.drops.push({
                id: this._id('c'), kind: 'core', rank: kill.coreRank, killId: e.id,
                x: e.x, y: e.y, radius: 10 + kill.coreRank, amount: CORE_RANK_VALUES[kill.coreRank],
                expiresAt: s.time + 2,
              })
            } else if (e.role === 'normal') {
              s.normalCoreCounter++
              if (s.normalCoreCounter === 20) { s.earned.cores++; s.normalCoreCounter = 0 }
            } else s.earned.cores += (e.role === 'elite' ? ELITE_CORE : BOSS_CORE)[e.rank]
          }
          s.zones = s.zones.filter(z => z.ownerId !== e.id)
          s.drops.push({ id: this._id('d'), kind: 'resource', x: e.x, y: e.y, radius: 5,
            amount: xp, expiresAt: s.time + .5 })
          // Initial playtest parameter, not a new currency or inventory item.
          // Chance is independent of pickup-radius passives and entirely seeded.
          if (this._random() < .08) s.drops.push({ id: this._id('h'), kind: 'heal',
            x: e.x, y: e.y, radius: 9, amount: s.player.maxHp * .1, expiresAt: s.time + 45 })
        }
        if (pass === 0 && e.killedBy !== 'gate' && s.time >= s.gateReadyAt && s.gateEntries.length) {
          const targets = this._targets(e, this._passive('sj_gate', 'radius'), 4)
          if (targets.length) {
            let budget = Math.min(s.gateEntries.reduce((sum, b) => sum + b.amount, 0),
              this._passive('sj_gate', 'proc_damage') * s.player.attack)
            const damage = budget / targets.length
            for (const entry of s.gateEntries) {
              const consumed = Math.min(entry.amount, budget)
              entry.amount -= consumed; budget -= consumed
            }
            s.gateEntries = s.gateEntries.filter(b => b.amount > EPS)
            s.gateReadyAt = s.time + 3
            targets.forEach(target => this._damageEnemy({ target: target.id, damage,
              direct: false, scaled: true, source: 'gate' }))
            this._effect('gate', e.x, e.y, this._passive('sj_gate', 'radius'))
          }
        }
      }
    }
  }
  _drops() {
    const s = this.state
    if (s.player.hp <= 0) return
    const pickup = 36 * (1 + this._passive('magnet', 'pickup_bonus'))
    s.drops = s.drops.filter(d => {
      if (d.expiresAt <= s.time) return false
      if (d.kind === 'heal' && distance(d, s.player) <= pickup + d.radius) {
        s.player.hp = Math.min(s.player.maxHp, s.player.hp + d.amount)
        return false
      }
      return true
    })
  }

  _visible(e) {
    const view = this.state.view
    return !view || [e, this.state.player].every(a => a.x - a.radius >= view.xmin
      && a.x + a.radius <= view.xmax && a.y - a.radius >= view.ymin && a.y + a.radius <= view.ymax)
  }
  _attackSpec(e) {
    return monsterAttackSpec(this, e, this._baseAttackSpec(e))
  }
  _baseAttackSpec(e) {
    const s = this.state, d = distance(e, s.player), ai = e.ai
    if(s.arenaVersion === 1 && !pillarSight(e,s.player))return null
    if (s.floor === 1 && e.role === 'boss') {
      const authored = FLOOR01_BOSS.attacks.find(a => d >= a.select_distance_min && d <= a.select_distance_max
        && (ai.cooldowns[a.id] ?? 0) <= s.time)
      if (!authored) return null
      return { kind: authored.id, shape: authored.shape, windup: authored.windup_s,
        active: authored.active_s, recovery: authored.recovery_s, cooldown: authored.cooldown_s,
        range: authored.range, radius: authored.radius ?? authored.width / 2,
        width: authored.width ?? 0, angle: authored.angle_deg ?? 0, damage: authored.damage,
        lock: authored.target_lock_s, speed: authored.dash_speed ?? 0, cost: 2,
        segments: authored.id === 'charge' && ai.phase === 2 ? 2 : 1 }
    }
    if (s.floor === 1 && e.family === 'spider') {
      if (d > e.radius + 54 + 18 || (ai.cooldowns.bite ?? 0) > s.time) return null
      const elite = e.role !== 'normal'
      return { kind: 'bite', shape: 'sector', windup: .65, active: .12, recovery: .6,
        cooldown: elite ? 1.8 : 1.2, range: e.radius + 54, radius: e.radius + 54,
        width: 0, angle: 100, damage: e.damage, lock: .15, speed: 0,
        cost: elite ? 2 : 1, segments: 1 }
    }
    const spec = enemyAttackSpec(e, d, s.time, ai.cooldowns)
    const heavy = spec && (spec.kind === 'charge'
      || (spec.kind === 'slam' && ['bear', 'ape', 'yak'].includes(e.family))
      || (spec.kind === 'sweep' && ['tiger', 'crocodile', 'rhino'].includes(e.family)))
    if (e.role === 'boss' && heavy) {
      spec.damage = FLOORS[s.floor - 1].floor_stat_scale.boss_heavy_damage
    }
    return spec
  }
  _newAttack(e, spec, segment = 1) {
    const s = this.state, ai = e.ai, dir = facing(s.player.x - e.x, s.player.y - e.y, ai.faceX, ai.faceY)
    ai.sequence++
    ai.attack = { ...spec, id: `${e.id}:a${ai.sequence}:s${segment}`, segment,
      dirX: dir.x, dirY: dir.y, x: e.x, y: e.y, targetX: s.player.x, targetY: s.player.y,
      startedAt: s.time, locked: false, hit: false, fired: false, travelled: 0, boundary: false,
      maxRange: spec.maxRange ?? spec.range, clipped: false }
    ai.mode = 'windup'
    ai.until = s.time + spec.windup
    ai.eligibleSince = -1
    this._clipAttack(e)
    this._telegraph(e)
  }
  _clipAttack(e) {
    const a = e.ai.attack
    if (a.kind !== 'charge') return
    a.range = clippedRay(a, a.dirX, a.dirY, a.maxRange, e.radius, this.state.arenaVersion)
    a.clipped = a.range + EPS < a.maxRange
  }
  _telegraph(e) {
    const s = this.state, a = e.ai.attack
    let z = s.zones.find(z => z.ownerId === e.id && z.renderOnly)
    if (!z) {
      z = { id: this._id('warning'), ownerId: e.id, hostile: true, renderOnly: true }
      s.zones.push(z)
    }
    const circleTarget = a.kind === 'stone' || a.kind === 'web'
    Object.assign(z, { kind: e.ai.mode === 'windup' ? 'enemy_windup' : 'enemy_attack',
      phase: e.ai.mode, shape: a.shape, attackId: a.id, x: circleTarget ? a.targetX : a.x,
      y: circleTarget ? a.targetY : a.y, radius: a.radius, width: a.width,
      toX: a.x + a.dirX * a.range, toY: a.y + a.dirY * a.range,
      angle: a.angle, faceX: a.dirX, faceY: a.dirY, locked: a.locked,
      expiresAt: s.time + 1 })
  }
  _recover(e, recovery) {
    e.ai.mode = 'recovery'
    e.ai.until = this.state.time + recovery
    this.state.zones = this.state.zones.filter(z => !(z.ownerId === e.id && z.renderOnly))
  }
  _enemyActions(incoming, oldPlayer) {
    const s = this.state
    for (const e of s.enemies) {
      const ai = e.ai
      if (e.hp <= 0 || monsterMechanicsBlocks(this, e)) continue
      const moveSpeed = e.moveSpeed * monsterMovementMultiplier(this, e)
      if (ai.mode === 'approach') {
        if (s.time < ai.entryUntil || s.time < ai.transitionUntil || ai.transitionPending) continue
        const d = distance(e, s.player)
        const dir = facing(s.player.x - e.x, s.player.y - e.y, ai.faceX, ai.faceY)
        ai.faceX = dir.x; ai.faceY = dir.y
        const spec = this._attackSpec(e)
        const visible = this._visible(e), style = enemyCombatStyle(e)
        if (style.ranged && !(s.floor === 1 && e.family === 'spider') && visible
          && (s.arenaVersion !== 1 || pillarSight(e,s.player))) {
          // Spacing remains active while a shot is cooling. Cap the step at the
          // band edge so fast actors do not oscillate across it.
          const gap = d < style.preferredMin ? d - style.preferredMin : Math.max(0, d - style.preferredMax)
          const travel = Math.min(Math.abs(gap), moveSpeed * STEP), sign = Math.sign(gap)
          const old = { x: e.x, y: e.y }
          e.x += dir.x * travel * sign; e.y += dir.y * travel * sign
          boundActor(e, s.arenaVersion)
          if (gap < 0 && distance(old, e) < travel * .25) {
            // A wall can block retreat. Try both tangents in a stable order,
            // keeping only a legal step that increases distance from the player.
            for (const side of [ai.orbitSign, -ai.orbitSign]) {
              const candidate = { x: old.x - dir.y * travel * side,
                y: old.y + dir.x * travel * side, radius: e.radius }
              boundActor(candidate, s.arenaVersion)
              if (distance(candidate, s.player) > distance(e, s.player) + EPS) {
                e.x = candidate.x; e.y = candidate.y
              }
            }
          }
        } else if (!spec || !visible) {
          let dx = dir.x, dy = dir.y
          if (['wolf', 'bat', 'centipede'].includes(e.family) && d > 160) {
            const side = (e.family === 'centipede' ? Math.sin(s.time * 3 + ai.offset) : ai.orbitSign) * .35
            const steer = facing(dx - dy * side, dy + dx * side)
            dx = steer.x; dy = steer.y
          }
          if(s.arenaVersion === 1){const route=steerPillars(e,s.player,e.radius);dx=route.x;dy=route.y}
          e.x += dx * moveSpeed * STEP
          e.y += dy * moveSpeed * STEP
          boundActor(e, s.arenaVersion)
        }
        continue
      }
      const a = ai.attack
      if (!this._visible(e) && ai.mode !== 'recovery') {
        a.segments = a.segment
        this._recover(e, .6)
        continue
      }
      if (ai.mode === 'windup') {
        if (!a.locked) {
          const dir = facing(s.player.x - e.x, s.player.y - e.y, a.dirX, a.dirY)
          a.dirX = dir.x; a.dirY = dir.y
          a.targetX = s.player.x; a.targetY = s.player.y
          this._clipAttack(e)
          if (s.time + EPS >= a.startedAt + a.lock) {
            a.locked = true
            if (s.floor === 1 && e.role === 'boss' && a.kind === 'charge'
              && (a.range < 120 || a.segment > 1 && distance(e, s.player) < 60)) {
              a.segments = a.segment
              this._recover(e, .6)
              continue
            }
          }
        }
        this._telegraph(e)
        if (s.time + EPS < ai.until) continue
        ai.mode = 'active'; ai.until = s.time + a.active
      }
      if (ai.mode === 'active') {
        if (a.kind === 'charge') {
          const old = { x: e.x, y: e.y }
          const travel = Math.min(a.speed * STEP, a.range - a.travelled)
          e.x += a.dirX * travel; e.y += a.dirY * travel
          const unclipped = { x: e.x, y: e.y }
          boundActor(e, s.arenaVersion)
          a.travelled += distance(old, e)
          a.boundary = distance(unclipped, e) > EPS || a.clipped && a.travelled >= a.range - EPS
          const relativeOld = { x: old.x - oldPlayer.x + s.player.x, y: old.y - oldPlayer.y + s.player.y }
          if (!a.hit && segmentDistance(s.player, relativeOld, e) <= e.radius + 18) {
            incoming.push({ id: a.id, damage: a.damage }); a.hit = true
          }
          if (a.boundary || a.travelled >= a.range - EPS) ai.until = s.time
        } else if (['shot', 'stone', 'web'].includes(a.kind)) {
          if (!a.fired) {
            a.fired = true
            if (a.kind === 'shot') {
              const spread = e.role === 'boss' ? [-.25, 0, .25] : [0]
              for (const angle of spread) {
                const x = a.dirX * Math.cos(angle) - a.dirY * Math.sin(angle)
                const y = a.dirX * Math.sin(angle) + a.dirY * Math.cos(angle)
                this._projectile(e.x, e.y, x * a.speed, y * a.speed, 12, a.damage, true,
                  { source: a.id, ownerId: e.id, ...(a.element === undefined ? {} : { element: a.element }) })
              }
            } else if(s.arenaVersion !== 1 || pillarSight(e,{x:a.targetX,y:a.targetY})) this._zone(a.kind, a.targetX, a.targetY, a.radius, a.damage,
              .35, a.kind === 'web' ? 4 : 1, 1, 1, true, false, { ownerId: e.id, source: a.id })
          }
        } else if (!a.hit && (s.arenaVersion !== 1 || pillarSight(a,s.player)) && (a.shape === 'circle' ? distance(s.player, a) <= a.radius + 18
          : inSector(s.player, a, { x: a.dirX, y: a.dirY }, a.range, a.angle, 18))) {
          incoming.push({ id: a.id, damage: a.damage }); a.hit = true
        }
        this._telegraph(e)
        if (s.time + EPS >= ai.until) {
          const recovery = a.boundary ? 1.2 : a.segment === a.segments && a.segments > 1 ? 1.2 : a.recovery
          if (a.boundary) a.segments = a.segment
          this._recover(e, recovery)
        }
      } else if (ai.mode === 'recovery' && s.time + EPS >= ai.until) {
        if (a.segment < a.segments && distance(e, s.player) >= 60 && this._visible(e)) {
          this._newAttack(e, a, a.segment + 1)
        } else {
          ai.cooldowns[a.kind] = s.time + a.cooldown
          ai.readyAt = s.time
          ai.mode = 'approach'; ai.attack = null
        }
      }
    }
  }
  _requestAttacks() {
    const s = this.state
    // Existing windups finish normally; new native attacks wait until the
    // mechanic and its recovery window have ended, preventing CC followups.
    if (s.monsterMechanics && s.enemies.some(e => e.hp > 0
      && e.mechanic && e.mechanic.phase !== 'idle')) return
    const boss = !s.monsterMechanics && s.floor === 1 ? s.enemies.find(e => e.role === 'boss') : null
    if (boss && boss.ai.phase === 1 && boss.hp <= boss.maxHp / 2) boss.ai.transitionPending = true
    if (boss && s.time < boss.ai.entryUntil) return
    if (boss && boss.ai.transitionPending) {
      if (boss.ai.mode === 'windup') {
        boss.ai.attack.segments = boss.ai.attack.segment
        this._recover(boss, .6)
      }
      if (!s.enemies.some(e => e.ai.mode !== 'approach') && !boss.ai.transitionUntil) {
        boss.ai.transitionUntil = s.time + 1.2
      }
      if (boss.ai.transitionUntil && s.time >= boss.ai.transitionUntil) {
        boss.ai.transitionPending = false; boss.ai.phase = 2
      } else return
    }
    if (boss && s.time < boss.ai.entryUntil || s.time < s.nextWindupAt) return
    const budget = s.floor === 1 ? 2 : 3 + Math.floor(s.floor / 3)
    const spent = s.enemies.reduce((sum, e) => sum + (e.ai.mode !== 'approach' ? e.ai.attack.cost : 0), 0)
    const eligible = []
    for (const e of s.enemies) {
      if (monsterMechanicsBlocks(this, e)) continue
      const ai = e.ai, spec = this._attackSpec(e)
      if (ai.mode !== 'approach' || s.time < ai.readyAt || s.time < ai.graceUntil
        || s.time < ai.entryUntil || !spec || !this._visible(e)) { ai.eligibleSince = -1; continue }
      if (ai.eligibleSince < 0) ai.eligibleSince = s.time
      eligible.push({ e, spec })
    }
    eligible.sort((a, b) => a.e.ai.eligibleSince - b.e.ai.eligibleSince || a.e.id.localeCompare(b.e.id))
    if (eligible.length && eligible[0].spec.cost + spent <= budget) {
      this._newAttack(eligible[0].e, eligible[0].spec)
      s.nextWindupAt = s.time + .25
    }
  }
}
