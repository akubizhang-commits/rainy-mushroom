import { OPEN_EQUIPMENT_TIERS, canUseEquipmentTier, isStarterEquipment } from './TowerEquipmentTiers.js'
import { validateMonsterMechanicsProgress } from './TowerMonsterMechanics.js'
import {STONE_CAP, STONE_STARTER, STONE_DRAW_COST, STONE_VALUES, FIRST_CLEAR_REWARDS, legacyRewardToStones, spiritStoneLootSummary} from './TowerEconomy.js'
// The sole permanent-state authority for the tower alpha. The host supplies
// storage and UTC milliseconds; combat owns and validates its complete snapshot.
import { checksum } from '../survivor/SurvivorSave.js'
import { cultivationAt, CAMP_PILLS, TOWER_XP_CAP, TOWER_RESOURCE_CAP } from './TowerProfile.js'
import { ECONOMY } from './TowerContent.js'
import { TowerRun, validateTowerSnapshot, stats as combatStats } from './TowerRun.js'
import { CRAFTING_COSTS, EQUIPMENT_CAPACITY, craftingQuality, forgeCost } from './TowerCrafting.js'
import { createBasicEquipment, rollEquipment, validateEquipment, equipmentName } from './TowerEquipment.js'
import { WEAPONS, createIronWeapon, rollWeapon, validateWeapon, weaponName } from './TowerWeapons.js'
import {
  GROWTH_STAGES, GROWTH_SKILLS, GROWTH_EVOLUTIONS, giftSkills, tutorialProgress, growthSummary, rankCap, skillRequirement, decreaseSkillQuote,
} from './TowerGrowth.js'

export const TOWER_CAMPAIGN_KEY = 'xianxia.sect-tower.campaign.v1'
export const PLAYTEST_STONE_CAP = Number.MAX_SAFE_INTEGER
export const PLAYTEST_RESOURCE_AMOUNT = 99_999
export const PLAYTEST_STONE_AMOUNT = 999
const FORMAT = 'xianxia-sect-tower-campaign'
const SCHEMA = 17
const UINT32_MAX = 0xffffffff
const copy = value => JSON.parse(JSON.stringify(value))
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value)
const integer = (value, max = Number.MAX_SAFE_INTEGER) =>
  Number.isSafeInteger(value) && value >= 0 && value <= max
const own = (value, key) => typeof key === 'string' && Object.prototype.hasOwnProperty.call(value, key)
const fail = reason => ({ ok: false, reason })
const terminal = phase => ['won', 'lost', 'abandoned'].includes(phase)
const growthById = Object.fromEntries(GROWTH_SKILLS.map(skill => [skill.id, skill]))
const growthEvolutionById = Object.fromEntries(GROWTH_EVOLUTIONS.map(evolution => [evolution.id, evolution]))
const bookIds = new Set([
  ...GROWTH_SKILLS.filter(skill => skill.special).map(skill => skill.id),
  ...GROWTH_EVOLUTIONS.map(evolution => evolution.id),
])

function freeze(value) {
  if (object(value) || Array.isArray(value)) {
    Object.values(value).forEach(freeze)
    Object.freeze(value)
  }
  return value
}

export { WEAPONS }

export function weaponBonus(quality, refine) {
  if (!integer(quality, 4) || quality < 1 || !integer(refine, 4)) {
    throw new RangeError('Invalid tower weapon')
  }
  return Math.min(0.3, (quality * 6 + refine * 1.5) / 100)
}

export function combatLoadout(state) {
  // Empty equipment slots retain the existing neutral combat baseline. The
  // persistent IDs stay empty, so the UI and dismantling rules see no item worn.
  const weaponId = state.loadouts[state.selectedLoadout].weaponId || 'iron'
  const weapon = state.weapons[weaponId]
  const armorId = state.loadouts[state.selectedLoadout].armorId || 'basic-armor'
  const ringId = state.loadouts[state.selectedLoadout].ringId || 'basic-ring'
  const active = Object.fromEntries(GROWTH_SKILLS.filter(skill => skill.kind === 'active' && state.skills[skill.id])
    .map(skill => [skill.id, state.skills[skill.id]]))
  // Advanced skills own their casting rank; the base-skill investment is unrelated.
  for (const evolution of GROWTH_EVOLUTIONS) {
    const rank = state.evolutionRanks[evolution.id]
    if (rank) active[evolution.parent] = evolution.castRanks[rank - 1]
  }
  return {
    active,
    passive: Object.fromEntries(GROWTH_SKILLS.filter(skill => skill.kind === 'passive' && state.skills[skill.id])
      .map(skill => [skill.id, state.skills[skill.id]])),
    evolutions: GROWTH_EVOLUTIONS.filter(evolution => state.evolutionRanks[evolution.id] > 0).map(evolution => evolution.id),
    ...(state.skillsInitialized ? { skillsInitialized: true } : {}),
    growthVersion: 1, evolutionLevels: { ...state.evolutionRanks }, tutorialWaves: state.tutorialWaves,
    weaponId, weaponQuality: weapon.quality, weaponRefine: weapon.refine,
    weapon: copy(weapon), weaponFocusCount: state.equipmentCounters[ringId],
    weaponEquipped: Boolean(state.loadouts[state.selectedLoadout].weaponId),
    armorId, ringId, armor: copy(state.equipment[armorId]), ring: copy(state.equipment[ringId]),
  }
}

export function campaignMaxHp(state) {
  return combatStats(state.xp, combatLoadout(state)).maxHp
}

function fresh(nowMs) {
  return {
    xp: 0, hp: 100, spiritStones: STONE_STARTER, contribution: 300,
    pills: { huichun: 3, peiyuan: 0 },
    skills: { sj_arc: 1 }, evolutions: [],
    books: [], evolutionRanks: {}, researchPurchases: 0, tutorialWaves: 0,
    weapons: { iron: createIronWeapon() }, weaponSequence: 0, weaponCounters: { iron: 0 },
    equipment: { 'basic-armor': createBasicEquipment('armor'), 'basic-ring': createBasicEquipment('ring') },
    equipmentSequence: 0, equipmentCounters: { 'basic-ring': 0 },
    inventoryMeta: {},
    equipmentPity: { armor: 0, ring: 0 }, equipmentDraws: { armor: 0, ring: 0 },
    equipmentRng: { armor: ((nowMs >>> 0) ^ 0x71ed43a1) >>> 0 || 1, ring: ((nowMs >>> 0) ^ 0xa73198bd) >>> 0 || 1 },
    loadouts: ['配装一', '配装二', '配装三'].map(name => ({
      name, weaponId: 'iron', armorId: 'basic-armor', ringId: 'basic-ring', active: ['sj_arc'], passive: [], evolutions: [],
    })),
    selectedLoadout: 0, clearedFloor: 0, normalCoreCounter: 0, weaponPity: 0,
    rng: ((nowMs >>> 0) ^ 0x6d2b79f5) >>> 0 || 1,
    restAt: nowMs, attemptSequence: 0, activeRun: null, tutorialDone: false, lastResult: null,
  }
}

function keys(value, names) {
  return object(value) && Object.keys(value).length === names.length && names.every(name => own(value, name))
}

function uniqueList(value, limit, predicate) {
  return Array.isArray(value) && value.length <= limit && new Set(value).size === value.length
    && value.every(id => typeof id === 'string' && predicate(id))
}

function validEarned(value, money = 'cores') {
  return keys(value, ['xp', money, 'contribution'])
    && ['xp', money, 'contribution'].every(key => integer(value[key]))
}

function validStoneLoot(loot, earned) {
  return keys(loot, ['byGrade', 'count', 'value'])
    && Array.isArray(loot.byGrade) && loot.byGrade.length === 4
    && loot.byGrade.every(n => integer(n))
    && integer(loot.count) && integer(loot.value, earned.spiritStones)
    && loot.count === loot.byGrade.reduce((a, b) => a + b, 0)
    && loot.value === loot.byGrade.reduce((a, b, i) => a + b * STONE_VALUES[i], 0)
}

function validSnapshot(snapshot, legacy = false) {
  try {
    return object(snapshot) && snapshot.training !== true
      && validateTowerSnapshot(snapshot, legacy) && validEarned(snapshot.earned)
      && integer(snapshot.player.xp, TOWER_XP_CAP)
      && Number.isFinite(snapshot.player.hp) && snapshot.player.hp >= 0
      && snapshot.player.hp <= combatStats(snapshot.player.xp, snapshot.loadout, legacy).maxHp
      && integer(snapshot.normalCoreCounter, 19)
      && (snapshot.phase === 'lost' ? snapshot.player.hp === 0 : snapshot.player.hp > 0)
  } catch {
    return false
  }
}

function sameLoadout(a, b) {
  if (!object(a) || !object(a.active) || !object(a.passive) || !Array.isArray(a.evolutions)) return false
  return a.weaponId === b.weaponId && a.weaponQuality === b.weaponQuality && a.weaponRefine === b.weaponRefine
    && a.weaponEquipped === b.weaponEquipped
    && a.armorId === b.armorId && a.ringId === b.ringId
    && JSON.stringify(a.armor) === JSON.stringify(b.armor) && JSON.stringify(a.ring) === JSON.stringify(b.ring)
    && JSON.stringify(a.weapon) === JSON.stringify(b.weapon) && a.weaponFocusCount === b.weaponFocusCount
    && ['active', 'passive'].every(kind =>
      Object.keys(a[kind]).length === Object.keys(b[kind]).length
      && Object.entries(b[kind]).every(([id, level]) => a[kind][id] === level))
    && a.evolutions.length === b.evolutions.length && b.evolutions.every(id => a.evolutions.includes(id))
    && a.growthVersion === b.growthVersion
    && (b.growthVersion !== 1 || a.tutorialWaves === b.tutorialWaves
      && a.skillsInitialized === b.skillsInitialized
      && object(a.evolutionLevels) && Object.keys(a.evolutionLevels).length === Object.keys(b.evolutionLevels).length
      && Object.entries(b.evolutionLevels).every(([id, level]) => a.evolutionLevels[id] === level))
}

function cappedAdd(base, earned) {
  return Math.min(TOWER_RESOURCE_CAP, base + earned)
}

const stoneCapFor = allowed => allowed ? PLAYTEST_STONE_CAP : STONE_CAP
// Avoid an unsafe intermediate sum near the playtest-only safe-integer cap.
const cappedStones = (base, earned, cap) => base + Math.min(earned, cap - base)

// Skill arrays are retained only as old-menu/save shape compatibility. They do
// not select combat skills, consume slots or constrain learned ownership.
function validLoadout(state, loadout) {
  if (!object(loadout) || typeof loadout.name !== 'string' || !loadout.name.trim()
    || loadout.name.length > 40 || (loadout.weaponId !== '' && !own(state.weapons, loadout.weaponId))
    || (loadout.weaponId && !canUseEquipmentTier(state.weapons[loadout.weaponId]?.tier, cultivationAt(state.xp).level))
    || (loadout.armorId !== '' && (!own(state.equipment, loadout.armorId) || state.equipment[loadout.armorId].category !== 'armor'))
    || (loadout.ringId !== '' && (!own(state.equipment, loadout.ringId) || state.equipment[loadout.ringId].category !== 'ring'))
    || [loadout.armorId, loadout.ringId].some(id => id && !canUseEquipmentTier(state.equipment[id]?.tier, cultivationAt(state.xp).level))
    || Object.keys(loadout).some(key => !['name', 'weaponId', 'armorId', 'ringId', 'active', 'passive', 'evolutions'].includes(key))) return false
  return ['active', 'passive', 'evolutions'].every(kind => loadout[kind] === undefined
    || uniqueList(loadout[kind], kind === 'evolutions' ? 4 : GROWTH_SKILLS.filter(skill => skill.kind === kind).length,
      id => kind === 'evolutions' ? own(growthEvolutionById, id)
        : own(growthById, id) && growthById[id].kind === kind))
}

function tutorialAt(run, snapshot) {
  return tutorialProgress(run.base.tutorialWaves, snapshot.floor, snapshot.clearedWaves)
}


function valid(state, allowPlaytestTools = false) {
  const money = 'spiritStones'
  const cap = stoneCapFor(allowPlaytestTools)
  const reward = legacyRewardToStones
  const lootKey = 'stoneLoot'
  try {
    if (!keys(state, [
      'xp', 'hp', money, 'contribution', 'pills', 'skills', 'evolutions', 'weapons', 'loadouts',
      'weaponSequence', 'weaponCounters',
      'equipment', 'equipmentSequence', 'equipmentCounters', 'equipmentPity', 'equipmentDraws', 'equipmentRng',
      'selectedLoadout', 'clearedFloor', 'normalCoreCounter', 'weaponPity', 'rng', 'restAt',
      'attemptSequence', 'activeRun', 'tutorialDone', 'lastResult',
      'books', 'evolutionRanks', 'researchPurchases', 'tutorialWaves',
      ...(own(state, 'skillsInitialized') ? ['skillsInitialized'] : []),
      ...(own(state, 'inventoryMeta') ? ['inventoryMeta'] : []),
      ...(allowPlaytestTools && own(state, 'playtestSkillPoints') ? ['playtestSkillPoints'] : []),
    ]) || !integer(state.xp, TOWER_XP_CAP)
      || !integer(state[money], cap) || !integer(state.contribution, TOWER_RESOURCE_CAP)
      || !Number.isFinite(state.hp) || state.hp < 0 || state.hp > campaignMaxHp(state)
      || !integer(state.clearedFloor, 9) || !integer(state.selectedLoadout, 2)
      || !integer(state.normalCoreCounter, 19) || !integer(state.weaponPity)
      || !integer(state.rng, UINT32_MAX) || state.rng === 0
      || !integer(state.restAt) || !integer(state.attemptSequence)
      || (own(state, 'skillsInitialized') && state.skillsInitialized !== true)
      || typeof state.tutorialDone !== 'boolean' || !integer(state.tutorialWaves, 3)
      || !integer(state.researchPurchases, 3) || state.researchPurchases > Math.floor(state.clearedFloor / 3)
      || !keys(state.pills, ['huichun', 'peiyuan'])
      || !Object.values(state.pills).every(count => integer(count, TOWER_RESOURCE_CAP))
      || !uniqueList(state.books, bookIds.size, id => bookIds.has(id))
      || !object(state.skills) || !object(state.evolutionRanks)
      || !Object.entries(giftSkills(state.tutorialWaves, state.skillsInitialized)).every(([id, level]) => state.skills[id] >= level)
      || !Object.entries(state.skills).every(([id, level]) => {
        const skill = growthById[id]
        return own(growthById, id) && integer(level, skill.maxLevel) && level > 0
          && level <= rankCap(id, state.xp, state.clearedFloor)
          && (!skill.special || state.books.includes(id))
      })
      || !uniqueList(state.evolutions, 4, id => own(state.evolutionRanks, id))
      || state.evolutions.length !== Object.keys(state.evolutionRanks).length
      || !Object.entries(state.evolutionRanks).every(([id, level]) => {
        if (!own(growthEvolutionById, id) || !integer(level, 3) || level < 1 || !state.books.includes(id)) return false
        const before = { ...state, evolutionRanks: { ...state.evolutionRanks, [id]: level - 1 } }
        // A new learning schedule must not invalidate previously legal ranks.
        // Keep realm and point-budget checks.
        return skillRequirement(before, id, { ignoreStage: true }).ok
      })
      || growthSummary(state).available < 0
      || !object(state.weapons) || !own(state.weapons, 'iron') || Object.keys(state.weapons).length > EQUIPMENT_CAPACITY
      || !integer(state.weaponSequence) || state.weaponPity > state.weaponSequence || !object(state.weaponCounters)
      || Object.keys(state.weaponCounters).length !== Object.keys(state.weapons).length
      || !Object.entries(state.weapons).every(([id, weapon]) => id === weapon.id && validateWeapon(weapon)
        && (id === 'iron' ? isStarterEquipment(weapon) : /^weapon-[1-9]\d*$/.test(id)
          && Number(id.slice(7)) <= state.weaponSequence && !isStarterEquipment(weapon))
        && own(state.weaponCounters, id) && integer(state.weaponCounters[id], 4))
      || !object(state.equipment) || !own(state.equipment, 'basic-armor') || !own(state.equipment, 'basic-ring')
      || Object.keys(state.weapons).length + Object.keys(state.equipment).length > EQUIPMENT_CAPACITY
      || !integer(state.equipmentSequence) || !object(state.equipmentCounters)
      || !keys(state.equipmentPity, ['armor', 'ring']) || !Object.values(state.equipmentPity).every(n => integer(n))
      || !keys(state.equipmentDraws, ['armor', 'ring']) || !Object.values(state.equipmentDraws).every(n => integer(n))
      || ['armor', 'ring'].some(category => state.equipmentPity[category] > state.equipmentDraws[category])
      || !keys(state.equipmentRng, ['armor', 'ring']) || !Object.values(state.equipmentRng).every(n => integer(n, UINT32_MAX) && n > 0)
      || !Object.entries(state.equipment).every(([id, item]) => id === item.id && validateEquipment(item)
        && (id === 'basic-armor' || id === 'basic-ring' ? isStarterEquipment(item) && id === `basic-${item.category}`
          : /^gear-[1-9]\d*$/.test(id) && Number(id.slice(5)) <= state.equipmentSequence && !isStarterEquipment(item)))
      || Object.keys(state.equipmentCounters).length !== Object.values(state.equipment).filter(item => item.category === 'ring').length
      || !Object.values(state.equipment).filter(item => item.category === 'ring').every(item => own(state.equipmentCounters, item.id)
        && integer(state.equipmentCounters[item.id], 4))
      || !Array.isArray(state.loadouts) || state.loadouts.length !== 3
      || !state.loadouts.every(loadout => validLoadout(state, loadout))) return false
    if (state.lastResult !== null) {
      const result = state.lastResult
      if (!keys(result, ['outcome', 'floor', 'earned', 'firstClear',
        ...(own(result, lootKey) ? [lootKey] : [])])
        || !terminal(result.outcome) || !integer(result.floor, 9) || result.floor < 1
        || !validEarned(result.earned, money) || result.earned.xp > TOWER_XP_CAP
        || own(result, lootKey) && !validStoneLoot(result.stoneLoot, result.earned)
        || typeof result.firstClear !== 'boolean'
        || result.firstClear && result.outcome !== 'won'
        || result.outcome === 'won' && result.floor > state.clearedFloor) return false
    }
    if (own(state, 'inventoryMeta') && (!object(state.inventoryMeta)
      || Object.entries(state.inventoryMeta).some(([id, meta]) =>
        (!own(state.weapons, id) && !own(state.equipment, id))
        || !keys(meta, ['order', 'seen']) || !integer(meta.order, state.weaponSequence + state.equipmentSequence)
        || typeof meta.seen !== 'boolean'))) return false
    if (state.activeRun === null) return state.hp > 0
    const run = state.activeRun
    if (!keys(run, ['id', 'floor', 'base', 'snapshot',
      ...(own(run, 'spentSpiritStones') ? ['spentSpiritStones', 'discardedSpiritStones'] : [])])
      || !integer(run.spentSpiritStones ?? 0) || !integer(run.discardedSpiritStones ?? 0) || run.id !== state.attemptSequence
      || !integer(run.id) || run.id < 1 || !integer(run.floor, Math.min(9, state.clearedFloor + 1)) || run.floor < 1
      || !keys(run.base, ['xp', money, 'contribution', 'normalCoreCounter', 'tutorialWaves'])
      || !integer(run.base.xp, TOWER_XP_CAP) || !integer(run.base.normalCoreCounter, 19)
      || !integer(run.base[money], cap) || !integer(run.base.contribution, TOWER_RESOURCE_CAP)
      || !integer(run.base.tutorialWaves, 3) || !validSnapshot(run.snapshot)) return false
    const snapshot = run.snapshot, loadout = snapshot.loadout
    const weaponId = state.loadouts[state.selectedLoadout].weaponId || 'iron', weapon = state.weapons[weaponId]
    return snapshot.attemptId === run.id && snapshot.floor === run.floor
      && snapshot.base.xp === run.base.xp && snapshot.base.normalCoreCounter === run.base.normalCoreCounter
      && loadout.weaponId === weaponId && loadout.weaponQuality === weapon.quality && loadout.weaponRefine === weapon.refine
      && loadout.growthVersion === 1 && snapshot.base.tutorialWaves === run.base.tutorialWaves
      && sameLoadout(loadout, combatLoadout(state))
      && state.xp === snapshot.player.xp && state.hp === snapshot.player.hp
      && state.xp === Math.min(TOWER_XP_CAP, run.base.xp + snapshot.earned.xp)
      && state[money] === Math.min(cap, run.base[money] + reward(snapshot.earned.cores) - (run.spentSpiritStones || 0) - (run.discardedSpiritStones || 0))
      && state.contribution === cappedAdd(run.base.contribution, snapshot.earned.contribution)
      && state.normalCoreCounter === snapshot.normalCoreCounter
      && state.tutorialWaves === tutorialAt(run, snapshot)
  } catch {
    return false
  }
}

function rest(state, nowMs) {
  if (state.activeRun === null) {
    const maxHp = campaignMaxHp(state)
    state.hp = Math.min(maxHp, state.hp + maxHp * 0.01 * Math.max(0, nowMs - state.restAt) / 60000)
  }
  // Time in battle and at full health is consumed, never banked for camp.
  state.restAt = Math.max(state.restAt, nowMs)
}

function random(state, key = 'rng') {
  let value = state[key]
  value ^= value << 13
  value ^= value >>> 17
  value ^= value << 5
  state[key] = value >>> 0
  return state[key] / 4294967296
}

function encode(state) {
  const data = JSON.stringify(state)
  return JSON.stringify({ format: FORMAT, schema: SCHEMA, data, checksum: checksum(data) })
}

export class TowerCampaignStore {
  constructor(storage, nowMs) {
    if (!integer(nowMs)) throw new RangeError('Invalid timestamp')
    this.storage = storage
    // Capture permission once; changing an adapter later cannot elevate an
    // already-open normal store. Permission is never read from saved state.
    Object.defineProperty(this, 'allowPlaytestTools', { value: storage.allowPlaytestTools === true })
    this._state = freeze(fresh(nowMs))
    this.error = ''
    this.readOnly = false
    this.migrationReport = null
    this._busy = false
    this._record = null
    try {
      this._record = storage.getItem(TOWER_CAMPAIGN_KEY) ?? null
    } catch {
      this.error = 'unreadable'
      this.readOnly = true
      return
    }
    if (this._record === null) return
    try {
      const record = JSON.parse(this._record)
      if (!object(record) || record.format !== FORMAT || !integer(record.schema) || record.schema < 1) throw Error()
      if (record.schema > SCHEMA) {
        this.error = 'newer'
        this.readOnly = true
        return
      }
      // User-approved development policy: obsolete schemas are discarded,
      // never migrated or compensated. Only this mode's storage key is replaced.
      if (record.schema < SCHEMA) {
        const next = fresh(nowMs), encoded = encode(next)
        try {
          if ((storage.getItem(TOWER_CAMPAIGN_KEY) ?? null) !== this._record) {
            this.error = 'stale-save'; this.readOnly = true; return
          }
          storage.setItem(TOWER_CAMPAIGN_KEY, encoded)
        } catch {
          this.error = 'save-failed'; this.readOnly = true; return
        }
        this._record = encoded
        this._state = freeze(next)
        this.migrationReport = freeze({ reset: true, fromSchema: record.schema })
        return
      }
      if (typeof record.data !== 'string' || checksum(record.data) !== record.checksum) throw Error()
      const state = JSON.parse(record.data)
      if (!valid(state, this.allowPlaytestTools)) throw Error()
      this._state = freeze(state)
    } catch {
      this.error = 'corrupt'
      this.readOnly = true
    }
  }

  get state() { return this._state }

  act(action, nowMs) {
    if (this.readOnly) return fail(this.error)
    if (this._busy) return fail('busy')
    if (!object(action) || typeof action.type !== 'string' || !integer(nowMs)) return fail('invalid-action')
    this._busy = true
    try {
      const next = copy(this._state)
      rest(next, nowMs)
      const result = this._apply(next, action, nowMs)
      if (!result.ok) return result
      if (!valid(next, this.allowPlaytestTools)) return fail('invalid-state')
      const record = encode(next)
      try {
        // A second host/store must reload, not overwrite an already committed
        // purchase or settlement with its stale in-memory balance.
        if ((this.storage.getItem(TOWER_CAMPAIGN_KEY) ?? null) !== this._record) {
          this.error = 'stale-save'
          return fail('stale-save')
        }
        this.storage.setItem(TOWER_CAMPAIGN_KEY, record)
      } catch {
        this.error = 'save-failed'
        return fail('save-failed')
      }
      this._record = record
      this._state = freeze(next)
      this.error = ''
      return result
    } finally {
      this._busy = false
    }
  }

  _apply(state, action, nowMs) {
    if (action.type === 'playtestResources' || action.type === 'playtestNextStage') {
      if (!this.allowPlaytestTools) return fail('playtest-only')
      const active = state.activeRun
      if (active && active.snapshot.phase !== 'paused') return fail('pause-required')
      if (action.type === 'playtestResources') {
        const stones = PLAYTEST_STONE_AMOUNT * STONE_VALUES[3], contribution = 999
        if (state.spiritStones > PLAYTEST_STONE_CAP - stones
          || state.contribution > TOWER_RESOURCE_CAP - contribution) return fail('capacity')
        state.spiritStones += stones
        state.contribution += contribution
        if (active) {
          active.base.spiritStones += stones
          active.base.contribution += contribution
        }
        return { ok: true, stones, contribution }
      }
      const current = cultivationAt(state.xp)
      const next = GROWTH_STAGES.find(stage => stage.minLevel > current.level)
      if (!next) return fail('cultivation-capped')
      const previousLevel = next.minLevel - 1
      const xp = 30 * previousLevel + 15 * previousLevel * previousLevel
      const gained = xp - state.xp
      if (active) {
        const run = TowerRun.restore(active.snapshot)
        run.setDeveloperCultivation(xp)
        active.snapshot = run.snapshot()
        active.base.xp = active.snapshot.base.xp
      }
      state.xp = xp
      return { ok: true, gained, cultivation: cultivationAt(xp), growth: growthSummary(state) }
    }
    if (['playtestSpiritStones', 'playtestContribution', 'playtestMaxLevel'].includes(action.type)) {
      if (!this.allowPlaytestTools) return fail('playtest-only')
      if (action.type === 'playtestMaxLevel') {
        // Camp XP grants follow the same HP semantics as cultivation pills.
        // Never rewrite a live run's XP receipts or manufacture clear rewards.
        if (state.activeRun) return fail('in-tower')
        const gained = TOWER_XP_CAP - state.xp
        state.xp = TOWER_XP_CAP
        return { ok: true, gained, cultivation: cultivationAt(state.xp), growth: growthSummary(state) }
      }
      if (state.activeRun && state.activeRun.snapshot.phase !== 'paused') return fail('pause-required')
      const stones = action.type === 'playtestSpiritStones'
      if (stones && !integer(action.grade, STONE_VALUES.length - 1)) return fail('invalid-grade')
      const resource = stones ? 'spiritStones' : 'contribution'
      const added = stones ? PLAYTEST_STONE_AMOUNT * STONE_VALUES[action.grade] : PLAYTEST_RESOURCE_AMOUNT
      const cap = stones ? PLAYTEST_STONE_CAP : TOWER_RESOURCE_CAP
      if (state[resource] > cap - added) return fail('capacity')
      state[resource] += added
      // A paused grant is permanent capital, not battle loot. Update the
      // settlement base while preserving the entire combat snapshot.
      if (state.activeRun) state.activeRun.base[resource] += added
      return { ok: true, resource, added, balance: state[resource] }
    }
    if (action.type === 'playtestReset' || action.type === 'playtestSkillPoints') {
      if (!this.allowPlaytestTools) return fail('playtest-only')
      if (action.type === 'playtestReset') {
        // Replace every profile field, including optional bonuses and the
        // active attempt, inside the same CAS transaction as ordinary actions.
        for (const key of Object.keys(state)) delete state[key]
        Object.assign(state, fresh(nowMs))
      } else {
        if (state.activeRun && state.activeRun.snapshot.phase !== 'paused') return fail('pause-required')
        const summary = growthSummary(state)
        const natural = summary.total - (state.playtestSkillPoints ?? 0)
        state.playtestSkillPoints = 999 + summary.spent - natural
      }
      return { ok: true, growth: growthSummary(state) }
    }
    if (action.type === 'refineEquipment' || action.type === 'refineWeapon') return fail('refinement-disabled')
    if (action.type === 'sync') return { ok: true, hp: state.hp }
    if (action.type === 'checkpoint' || action.type === 'finishFloor') return this._checkpoint(state, action)
    if (action.type === 'learnSkill' || action.type === 'buyBook') return this._learn(state, action.id)
    if (state.activeRun !== null) return fail('in-tower')
    switch (action.type) {
      case 'viewInventoryItem':
        if (!own(state.weapons, action.id) && !own(state.equipment, action.id)) return fail('unowned-equipment')
        if (state.inventoryMeta?.[action.id]) state.inventoryMeta[action.id].seen = true
        return { ok: true, id: action.id }
      case 'buyPill':
      case 'usePill': return this._pill(state, action)
      case 'decreaseSkill': {
        const quote = decreaseSkillQuote(state, action.id)
        if (!quote.ok) return fail(quote.reason)
        state.skills = quote.skills
        state.evolutionRanks = quote.evolutionRanks
        state.evolutions = state.evolutions.filter(id => own(state.evolutionRanks, id))
        return { ok: true, id: action.id, returned: quote.returned, changes: quote.changes,
          growth: growthSummary(state) }
      }
      case 'respecSkills': {
        const available = growthSummary(state).available
        state.skillsInitialized = true
        state.skills = {}
        state.evolutionRanks = {}
        state.evolutions = []
        state.loadouts = state.loadouts.map(loadout => ({
          name: loadout.name, weaponId: loadout.weaponId, armorId: loadout.armorId, ringId: loadout.ringId, active: [], passive: [], evolutions: [],
        }))
        return { ok: true, returned: growthSummary(state).available - available, growth: growthSummary(state) }
      }
      case 'researchPoint': {
        const count = state.researchPurchases
        if (count >= 3) return fail('max-research')
        if (state.clearedFloor < (count + 1) * 3) return fail('floor-locked')
        const cost = (count + 1) * 800
        if (state.spiritStones < cost) return fail('insufficient')
        state.spiritStones -= cost
        state.researchPurchases++
        return { ok: true, cost, growth: growthSummary(state) }
      }
      case 'drawForge': return this._drawForge(state, action)
      case 'drawEquipment': return this._drawEquipment(state, action)
      case 'equipEquipment':
      case 'refineEquipment':
      case 'dismantleEquipment': return this._equipmentAction(state, action)
      case 'drawWeapon': return this._draw(state, action)
      case 'dismantleWeapon': {
        if (!own(state.weapons, action.id)) return fail('unowned-weapon')
        const weapon = state.weapons[action.id]
        if (isStarterEquipment(weapon)) return fail('starter-weapon')
        if (state.loadouts.some(loadout => loadout.weaponId === action.id)) return fail('equipped-weapon')
        const refund = ECONOMY.duplicate_contribution[weapon.quality - 1]
        if (state.contribution > TOWER_RESOURCE_CAP - refund) return fail('capacity')
        state.contribution += refund
        delete state.weapons[action.id]
        delete state.weaponCounters[action.id]
        if (state.inventoryMeta) delete state.inventoryMeta[action.id]
        return { ok: true, id: action.id, refund }
      }
      case 'refineWeapon': return fail('refinement-disabled')
      case 'setLoadout':
        if (!integer(action.index, 2)) return fail('invalid-index')
        if (!validLoadout(state, action.loadout)) return fail('invalid-loadout')
        state.loadouts[action.index] = copy(action.loadout)
        state.hp = Math.min(state.hp, campaignMaxHp(state))
        return { ok: true, index: action.index }
      case 'selectLoadout':
        if (!integer(action.index, 2)) return fail('invalid-index')
        state.selectedLoadout = action.index
        state.hp = Math.min(state.hp, campaignMaxHp(state))
        return { ok: true, index: action.index }
      case 'tutorialDone':
        state.tutorialDone = true
        return { ok: true }
      case 'startFloor': return this._start(state, action)
      default: return fail('unknown-action')
    }
  }

  _pill(state, action) {
    if (!own(CAMP_PILLS, action.id)) return fail('unknown-pill')
    const pill = CAMP_PILLS[action.id]
    if (action.type === 'buyPill') {
      if (!integer(action.count, TOWER_RESOURCE_CAP) || action.count < 1) return fail('invalid-count')
      const cost = pill.price * action.count
      if (state.pills[action.id] + action.count > TOWER_RESOURCE_CAP) return fail('capacity')
      if (state.contribution < cost) return fail('insufficient')
      state.contribution -= cost
      state.pills[action.id] += action.count
      return { ok: true, id: action.id, count: action.count, cost }
    }
    if (state.pills[action.id] === 0) return fail('no-pill')
    if (pill.healShare) {
      const maxHp = campaignMaxHp(state)
      if (state.hp >= maxHp) return fail('full-health')
      const healed = Math.min(maxHp - state.hp, maxHp * pill.healShare)
      state.hp = Math.min(maxHp, state.hp + healed)
      state.pills[action.id]--
      return { ok: true, id: action.id, healed }
    }
    if (state.xp === TOWER_XP_CAP) return fail('cultivation-capped')
    const gained = Math.min(pill.xp, TOWER_XP_CAP - state.xp)
    state.xp += gained
    state.pills[action.id]--
    return { ok: true, id: action.id, gained, cultivation: cultivationAt(state.xp) }
  }

  _learn(state, id) {
    const active = state.activeRun
    if (active) {
      if (active.snapshot.phase !== 'paused') return fail('pause-required')
    }
    const quote = skillRequirement(state, id, { inTower: !!active })
    if (!quote.ok) return fail(quote.reason)
    if (state.spiritStones < quote.bookCost) return fail('insufficient')
    if (active && quote.bookCost) {
      const gross = active.base.spiritStones + legacyRewardToStones(active.snapshot.earned.cores)
        - (active.spentSpiritStones || 0) - (active.discardedSpiritStones || 0)
      active.discardedSpiritStones = (active.discardedSpiritStones || 0)
        + Math.max(0, gross - stoneCapFor(this.allowPlaytestTools))
      active.spentSpiritStones = (active.spentSpiritStones || 0) + quote.bookCost
    }
    state.spiritStones -= quote.bookCost
    if (quote.bookCost) state.books.push(id)
    if (own(growthEvolutionById, id)) {
      state.evolutionRanks[id] = quote.nextLevel
      state.evolutions = GROWTH_EVOLUTIONS.filter(evolution => state.evolutionRanks[evolution.id]).map(evolution => evolution.id)
    } else state.skills[id] = quote.nextLevel
    const result = { ok: true, id, level: quote.nextLevel, cost: quote.cost, bookCost: quote.bookCost }
    if (active) {
      const run = TowerRun.restore(active.snapshot)
      run.setGrowthLoadout(combatLoadout(state))
      active.snapshot = run.snapshot()
      result.snapshot = copy(active.snapshot)
    }
    return result
  }

  _drawForge(state, action) {
    const { category, tier, count } = action
    if (!['weapon', 'armor'].includes(category)) return fail('invalid-category')
    if (![1, 10].includes(count)) return fail('invalid-count')
    if (!OPEN_EQUIPMENT_TIERS.includes(tier)) return fail('invalid-tier')
    if (!canUseEquipmentTier(tier, cultivationAt(state.xp).level)) return fail('realm-locked')
    if (Object.keys(state.weapons).length + Object.keys(state.equipment).length + count > EQUIPMENT_CAPACITY) return fail('capacity')
    const cost = forgeCost(count)
    if (state.spiritStones < cost.spiritStones || state.contribution < cost.contribution) return fail('insufficient')
    const draws = []
    // All rolls mutate the transaction draft; any failure discards the whole batch.
    for (let i = 0; i < count; i++) {
      const selected = category === 'weapon' ? 'weapon'
        : random(state.equipmentRng, 'armor') < 2 / 3 ? 'armor' : 'ring'
      const result = selected === 'weapon' ? this._draw(state, { tier }, true)
        : this._drawEquipment(state, { category: selected, tier }, true)
      if (!result.ok) return result
      draws.push(result.draw)
    }
    state.spiritStones -= cost.spiritStones
    state.contribution -= cost.contribution
    return { ok: true, draw: draws[0], draws }
  }

  _draw(state, action = {}, prepaid = false) {
    const tier = action.tier === undefined ? 'fan' : action.tier
    if (!OPEN_EQUIPMENT_TIERS.includes(tier)) return fail('invalid-tier')
    if (!canUseEquipmentTier(tier, cultivationAt(state.xp).level)) return fail('realm-locked')
    if (Object.keys(state.weapons).length + Object.keys(state.equipment).length >= EQUIPMENT_CAPACITY || state.weaponSequence >= Number.MAX_SAFE_INTEGER || state.weaponPity >= Number.MAX_SAFE_INTEGER) return fail('capacity')
    const cost = CRAFTING_COSTS.weapon.contribution
    if (!prepaid && (state.contribution < cost || state.spiritStones < STONE_DRAW_COST)) return fail('insufficient')
    const quality = craftingQuality(state.weaponPity, random(state))
    const weapon = rollWeapon(tier, quality, () => random(state), `weapon-${++state.weaponSequence}`)
    state.weapons[weapon.id] = weapon
    state.inventoryMeta ??= {}
    state.inventoryMeta[weapon.id] = { order: state.weaponSequence + state.equipmentSequence, seen: false }
    state.weaponCounters[weapon.id] = 0
    if (!prepaid) { state.spiritStones -= STONE_DRAW_COST; state.contribution -= cost }
    state.weaponPity = quality === 4 ? 0 : state.weaponPity + 1
    return { ok: true, draw: {
      id: weapon.id, name: weaponName(weapon), tier, quality, duplicate: false, refund: 0,
      weapon: copy(weapon), pity: state.weaponPity,
    } }
  }

  _drawEquipment(state, action, prepaid = false) {
    const category = action.category, tier = action.tier === undefined ? 'fan' : action.tier
    if (!['armor', 'ring'].includes(category)) return fail('invalid-category')
    if (!OPEN_EQUIPMENT_TIERS.includes(tier)) return fail('invalid-tier')
    if (!canUseEquipmentTier(tier, cultivationAt(state.xp).level)) return fail('realm-locked')
    if (Object.keys(state.weapons).length + Object.keys(state.equipment).length >= EQUIPMENT_CAPACITY
      || state.equipmentSequence >= Number.MAX_SAFE_INTEGER || state.equipmentDraws[category] >= Number.MAX_SAFE_INTEGER
      || state.equipmentPity[category] >= Number.MAX_SAFE_INTEGER) return fail('capacity')
    const cost = CRAFTING_COSTS[category]
    if (!prepaid && (state.spiritStones < cost.spiritStones || state.contribution < cost.contribution)) return fail('insufficient')
    const rng = () => random(state.equipmentRng, category)
    const quality = craftingQuality(state.equipmentPity[category], rng())
    const item = rollEquipment(category, tier, quality, rng, `gear-${++state.equipmentSequence}`)
    state.equipment[item.id] = item
    state.inventoryMeta ??= {}
    state.inventoryMeta[item.id] = { order: state.weaponSequence + state.equipmentSequence, seen: false }
    if (category === 'ring') state.equipmentCounters[item.id] = 0
    if (!prepaid) { state.spiritStones -= cost.spiritStones; state.contribution -= cost.contribution }
    state.equipmentDraws[category]++
    state.equipmentPity[category] = quality === 4 ? 0 : state.equipmentPity[category] + 1
    return { ok: true, draw: { id: item.id, name: equipmentName(item), category, tier, quality,
      item: copy(item), pity: state.equipmentPity[category], duplicate: false, refund: 0 } }
  }

  _equipmentAction(state, action) {
    if (!own(state.equipment, action.id)) return fail('unowned-equipment')
    const item = state.equipment[action.id]
    if (action.type === 'equipEquipment') {
      if (action.category !== item.category) return fail('invalid-category')
      if (!canUseEquipmentTier(item.tier, cultivationAt(state.xp).level)) return fail('realm-locked')
      state.loadouts[state.selectedLoadout][`${item.category}Id`] = item.id
      state.hp = Math.min(state.hp, campaignMaxHp(state))
      return { ok: true, id: item.id, category: item.category }
    }
    if (isStarterEquipment(item)) return fail('starter-equipment')
    if (state.loadouts.some(row => row[`${item.category}Id`] === item.id)) return fail('equipped-equipment')
    const refund = ECONOMY.duplicate_contribution[item.quality - 1]
    if (state.contribution > TOWER_RESOURCE_CAP - refund) return fail('capacity')
    state.contribution += refund
    delete state.equipment[item.id]
    if (state.inventoryMeta) delete state.inventoryMeta[item.id]
    if (item.category === 'ring') delete state.equipmentCounters[item.id]
    return { ok: true, id: item.id, refund }
  }

  _start(state, action) {
    if (!integer(action.floor, 9) || action.floor < 1) return fail('invalid-floor')
    if (action.floor > state.clearedFloor + 1) return fail('floor-locked')
    if (action.seed !== undefined && !integer(action.seed, UINT32_MAX)) return fail('invalid-seed')
    if (state.attemptSequence === Number.MAX_SAFE_INTEGER) return fail('capacity')
    const id = state.attemptSequence + 1
    const run = new TowerRun({
      attemptId: id, floor: action.floor, seed: action.seed === undefined ? state.rng : action.seed,
      hp: state.hp, xp: state.xp, normalCoreCounter: state.normalCoreCounter, loadout: combatLoadout(state),
      arenaVersion: 1,
    })
    const snapshot = run.snapshot()
    state.attemptSequence = id
    state.activeRun = {
      id, floor: action.floor,
      base: {
        xp: state.xp, spiritStones: state.spiritStones, contribution: state.contribution,
        normalCoreCounter: state.normalCoreCounter, tutorialWaves: state.tutorialWaves,
      },
      snapshot,
    }
    return { ok: true, snapshot: copy(snapshot) }
  }

  _checkpoint(state, action) {
    const run = state.activeRun
    if (run === null) return fail('wrong-attempt')
    const snapshot = action.snapshot
    if (!object(snapshot)) return fail('invalid-snapshot')
    if (snapshot.attemptId !== undefined && snapshot.attemptId !== run.id
      || snapshot.floor !== undefined && snapshot.floor !== run.floor) return fail('wrong-attempt')
    if (!validSnapshot(snapshot)
      || snapshot.player.xp !== Math.min(TOWER_XP_CAP, run.base.xp + snapshot.earned.xp)) return fail('invalid-snapshot')
    if (action.type === 'finishFloor' && !terminal(snapshot.phase)) return fail('invalid-result')
    const previous = run.snapshot
    if (snapshot.arenaVersion !== previous.arenaVersion) return fail('invalid-snapshot')
    if (own(snapshot, 'loot') !== own(previous, 'loot')
      || snapshot.loot?.version !== previous.loot?.version
      || snapshot.loot?.seed !== previous.loot?.seed) return fail('invalid-snapshot')
    // These are append-only battle histories. A structurally valid older
    // equipment state must never refund healing allowance or precharge focus.
    const elapsedTicks = snapshot.ticks - previous.ticks
    const maxCastDelta = elapsedTicks * Math.max(Object.keys(previous.loadout.active).length, Object.keys(snapshot.loadout.active).length)
    const armor = snapshot.armorState, oldArmor = previous.armorState
    const weapon = snapshot.weaponState, oldWeapon = previous.weaponState
    if (elapsedTicks < 0
      || armor && oldArmor && (armor.healedTotal < oldArmor.healedTotal
        || armor.triggerCount < oldArmor.triggerCount || armor.cooldownUntil < oldArmor.cooldownUntil
        || (armor.lastTriggerAt ?? -1) < (oldArmor.lastTriggerAt ?? -1)
        || armor.triggerCount - oldArmor.triggerCount > elapsedTicks)
      || weapon && oldWeapon && (weapon.effectiveCasts < oldWeapon.effectiveCasts
        || weapon.nextCastId < oldWeapon.nextCastId
        || weapon.effectiveCasts - oldWeapon.effectiveCasts > maxCastDelta
        || weapon.nextCastId - oldWeapon.nextCastId > maxCastDelta)
      || elapsedTicks === 0 && (JSON.stringify(armor) !== JSON.stringify(oldArmor)
        || JSON.stringify(weapon) !== JSON.stringify(oldWeapon))) return fail('stale-snapshot')
    if (snapshot.time < previous.time || snapshot.player.xp < previous.player.xp
      || snapshot.nextId < previous.nextId || snapshot.clearedWaves.length < previous.clearedWaves.length
      || previous.killLedger.some((kill, index) => {
        const current = snapshot.killLedger[index]
        return !current || kill.id !== current.id || kill.wave !== current.wave
          || kill.archetype !== current.archetype || kill.coreRank !== current.coreRank
      })
      || ['xp', 'cores', 'contribution'].some(key => snapshot.earned[key] < previous.earned[key])
      || (terminal(previous.phase) && (snapshot.phase !== previous.phase || snapshot.time !== previous.time))
      || (snapshot.time === previous.time && (
        ['xp', 'cores', 'contribution'].some(key => snapshot.earned[key] !== previous.earned[key])
        || snapshot.player.hp !== previous.player.hp || snapshot.normalCoreCounter !== previous.normalCoreCounter
        || snapshot.rng !== previous.rng || snapshot.nextId !== previous.nextId
      ))) return fail('stale-snapshot')
    if (!validateMonsterMechanicsProgress(previous, snapshot)
      || Boolean(snapshot.monsterControl) !== Boolean(previous.monsterControl)) return fail('invalid-snapshot')
    if (snapshot.loadout.growthVersion !== 1
      || snapshot.base.xp !== previous.base.xp
      || snapshot.base.hp !== previous.base.hp
      || snapshot.base.normalCoreCounter !== previous.base.normalCoreCounter) return fail('invalid-snapshot')
    const waves = tutorialAt(run, snapshot)
    if (waves < state.tutorialWaves) return fail('stale-snapshot')
    if (snapshot.base.tutorialWaves !== run.base.tutorialWaves
      || snapshot.loadout.tutorialWaves !== waves) return fail('invalid-snapshot')
    state.xp = snapshot.player.xp
    state.tutorialWaves = waves
    if (!sameLoadout(snapshot.loadout, combatLoadout(state))) return fail('invalid-snapshot')
    state.hp = snapshot.player.hp
    state.spiritStones = Math.min(stoneCapFor(this.allowPlaytestTools), run.base.spiritStones
      + legacyRewardToStones(snapshot.earned.cores) - (run.spentSpiritStones || 0) - (run.discardedSpiritStones || 0))
    state.contribution = cappedAdd(run.base.contribution, snapshot.earned.contribution)
    state.normalCoreCounter = snapshot.normalCoreCounter
    run.snapshot = copy(snapshot)
    if (action.type === 'checkpoint') return { ok: true }
    state.equipmentCounters[snapshot.loadout.ringId] = snapshot.weaponState.focusCount
    const firstClear = snapshot.phase === 'won' && run.floor > state.clearedFloor
    if (firstClear) {
      state.clearedFloor = run.floor
      const reward = FIRST_CLEAR_REWARDS[run.floor - 1]
      if (reward.kind === 'spiritStones') {
        state.spiritStones = cappedStones(state.spiritStones, reward.amount, stoneCapFor(this.allowPlaytestTools))
      } else if (reward.kind === 'contribution') {
        state.contribution = cappedAdd(state.contribution, reward.amount)
      }
    }
    if (snapshot.phase === 'lost') state.hp = 1
    state.lastResult = {
      outcome: snapshot.phase, floor: run.floor, firstClear,
      earned: {
        xp: state.xp - run.base.xp,
        spiritStones: state.spiritStones - run.base.spiritStones + (run.spentSpiritStones || 0),
        contribution: state.contribution - run.base.contribution,
      },
    }
    const stoneLoot = spiritStoneLootSummary(snapshot)
    // At the resource cap the credited delta can be smaller than actual drops.
    // Keep the existing settlement valid without presenting uncredited loot.
    if (stoneLoot && validStoneLoot(stoneLoot, state.lastResult.earned)) state.lastResult.stoneLoot = stoneLoot
    state.activeRun = null
    return { ok: true, hp: state.hp, ...copy(state.lastResult) }
  }
}
