import { SAVE_KEY } from '../constants.js'

// Integrity check, not encryption. Profile schema migrations stay in the state layer.
function checksum(text){
  let hash=2166136261
  for(let i=0;i<text.length;i++)hash=Math.imul(hash^text.charCodeAt(i),16777619)
  return (hash>>>0).toString(16)
}
function encode(data){return {format:'rainy-save-1',data,checksum:checksum(data)}}
function decode(value){
  if(!value||typeof value!=='object'||Array.isArray(value))return null
  if(value.format==='rainy-save-1'){
    if(typeof value.data!=='string'||checksum(value.data)!==value.checksum)return null
    value=JSON.parse(value.data)
  }
  return value&&typeof value==='object'&&!Array.isArray(value)?value:null
}

export class StorageService {
  constructor(api, key = SAVE_KEY) {
    this.api = api
    this.key = key
    this.backupKey=key+':backup'
    this.lastData=null
    this.pending=null
    this.retryAt=0
    this.recovered=false
  }

  load() {
    for(const key of [this.key,this.backupKey]){
      try {
        const value=decode(this.api.getStorageSync(key))
        if(value){
          this.lastData=JSON.stringify(value)
          this.recovered=key===this.backupKey
          return JSON.parse(this.lastData)
        }
      }catch{}
    }
    return null
  }

  save(profile) {
    try {
      const data=JSON.stringify(profile)
      if(!data||!decode(profile))return false
      if(data===this.lastData&&!this.pending&&!this.recovered)return true
      this.pending=data
      return this.flushPending(Date.now(),true)
    }catch{return false}
  }

  flushPending(now=Date.now(),force=false){
    if(!this.pending)return true
    if(!force&&now<this.retryAt)return false
    try{
      // Never replace a good backup with a damaged primary record.
      try{this.api.setStorageSync(this.backupKey,encode(this.lastData||this.pending))}catch{}
      this.api.setStorageSync(this.key,encode(this.pending))
      this.lastData=this.pending;this.pending=null;this.recovered=false
      return true
    }catch{
      this.retryAt=now+3000
      return false
    }
  }

  clear() {
    try {
      this.api.removeStorageSync(this.key)
      this.api.removeStorageSync(this.backupKey)
      this.lastData=null;this.pending=null;this.recovered=false
      return true
    } catch (error) {
      return false
    }
  }
}
