import { SeededRandom } from '../core/Random.js'

export function expeditionVariation(scene,visit){
  const random=new SeededRandom(`walk:${scene.id}:${visit}`)
  const light=visit===1?0:(visit-1)%3
  const weather=[{name:'雨后微光',sky:null,fog:null},{name:'薄雾清晨',sky:'#c7d8d1',fog:'#bbcfc3'},{name:'暖光午后',sky:'#d8dfc9',fog:'#cbd3b2'}][light]
  return {
    visit,weather,
    animals:scene.animals.map((a,i)=>({...a,x:a.x+(visit===1?0:(random.next()-.5)*2),z:a.z+(visit===1?0:(random.next()-.5)*2),phase:random.next()*Math.PI*2})),
    positions:scene.spawns.map((s,i)=>{
      const [x,z]=s.position
      // Keep the entry clearing and large landscape landmarks recognizable.
      if(visit===1&&i===0)return [x,z]
      const dx=(random.next()-.5)*.8,dz=(random.next()-.5)*.8
      return [x+dx,z+dz]
    })
  }
}
