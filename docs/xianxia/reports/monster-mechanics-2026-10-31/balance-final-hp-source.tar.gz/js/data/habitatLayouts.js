import { GENERATED_HABITAT_IDS } from './generatedHabitatScenes.js'

// Coordinates refer to the entire 3:2 habitat, not the phone viewport.
// The same composition spec is used by the image prompts and runtime placement.
export const HABITAT_LAYOUTS = Object.freeze({
  'yn-pine': {
    title: '雨后松林', atmosphere: '雾气未散，留意松针之间的轮廓。',
    terrain: 'Warm humid mountain pine and broadleaf mixed forest after rain. Low eye level, layers of russet pine needles, old pine roots, dark moist humus, fern fronds and moss. Soft warm morning mist between irregular trunks. A thick tree trunk at x=39%.',
    spots: [
      [.18, .76, 'needles', '松针下', .044],
      [.39, .65, 'tree-behind', '树根背后', .045],
      [.64, .80, 'leaves', '落叶之间', .037],
      [.83, .69, 'needles', '松针堆边', .048]
    ]
  },
  'yn-alpine': {
    title: '风过高山草甸', atmosphere: '俯身看看矮草与土隙，只记录，不采挖。',
    terrain: 'High alpine meadow above the treeline, far layered blue-grey mountains, only a narrow strip of pale cloudy sky. Camera close to short tufted alpine grasses, wet dark earth, small lichen rocks, shallow uneven turf. No trees, farms, fences, paths or cultivated fields. Crisp cool daylight, golden olive grasses.',
    spots: [
      [.17, .77, 'grass', '矮草丛中', .034],
      [.39, .62, 'mound', '土隙边缘', .031],
      [.63, .82, 'grass', '草根之间', .036],
      [.84, .68, 'grass', '石旁草丛', .032]
    ]
  },
  'hl-mixed': {
    title: '白桦与红松', atmosphere: '从林下苔地，慢慢看到树干高处。',
    terrain: 'Cold temperate Korean pine and white birch mixed forest. Clearly visible white birch bark interspersed with tall dark pines. Lichen and moss floor, fallen leaves and needles. A broad old deciduous trunk with a small bark ledge at x=63%, y=43%. Cool silver light, amber needle litter, irregular natural forest with no road.',
    spots: [
      [.18, .78, 'leaves', '白桦落叶间', .040],
      [.39, .69, 'needles', '松根旁', .043],
      [.63, .43, 'bark', '阔叶树干', .050],
      [.83, .82, 'grass', '苔地草间', .037]
    ]
  },
  'hl-meadow': {
    title: '湿草地的清晨', atmosphere: '草丛里有细小变化，老树桩也值得一看。',
    terrain: 'Cool humid forest edge wet meadow after dawn rain, tall varied fine grasses and dew, patchy dark disturbed earth, irregular shrubs and birch forest in the background. Detailed foreground grass blades. An old weathered broadleaf stump at x=63%, y=59%, mossy top and split bark. Soft open daylight, fresh green and straw gold. No lawns or buildings.',
    spots: [
      [.17, .79, 'grass', '湿草丛中', .045],
      [.40, .70, 'grass', '草叶背后', .040],
      [.63, .59, 'wood', '老树桩侧面', .051],
      [.84, .83, 'grass', '林缘草根', .037]
    ]
  },
  'jl-mixed': {
    title: '冷雾深林', atmosphere: '老树的伤口、倒木的侧面，都藏着线索。',
    terrain: 'Dense cool damp conifer and broadleaf mixed old growth forest. Deep moss, spruce roots, thick damp leaf litter, ferns and sparse shafts of cool diffused light. An old deciduous tree at x=40% with a dark scar and bark shelf around y=40%. A decaying fallen broadleaf log crossing x=75% to 94%, y=67%, in close foreground. Deep green and umber.',
    spots: [
      [.17, .77, 'needles', '腐殖层里', .042],
      [.40, .40, 'bark', '老树伤口旁', .048],
      [.62, .82, 'leaves', '厚落叶下', .037],
      [.83, .67, 'wood', '倒木侧面', .048]
    ]
  },
  'jl-river': {
    title: '溪谷枯木', atmosphere: '顺着溪岸看，潮湿的木头上常有不同形状。',
    terrain: 'Cool humid wooded river valley, small shallow stream curving gently through the upper middle distance, rounded wet stones, ferns and moss. Foreground is accessible forest bank not water. Broad decaying log at x=18%, y=66%. Old deciduous trunk with a hollow at x=39%, y=43%. Moss covered rotten stump at x=63%, y=72%. Filtered soft blue-green daylight.',
    spots: [
      [.18, .66, 'wood', '溪边倒木', .049],
      [.39, .43, 'bark', '树洞旁', .048],
      [.63, .72, 'wood', '潮湿树桩', .051],
      [.83, .82, 'leaves', '溪岸落叶间', .037]
    ]
  },
  'ln-oak': {
    title: '橡树林的午后', atmosphere: '绕过树根，寻找枯木上的层层纹理。',
    terrain: 'Temperate hilly deciduous oak woodland, old gnarled oak trunks, yellow-brown lobed oak leaves, exposed roots and rich leaf litter, a few sunlit green saplings. Gentle slopes visible behind. Thick oak roots at x=18%, y=76%. Broad bark-textured fallen oak branch at x=62%, y=61%. A large foreground trunk at x=82%. Dappled warm autumn sunlight.',
    spots: [
      [.18, .76, 'roots', '橡树根旁', .047],
      [.40, .71, 'leaves', '橡叶下面', .043],
      [.62, .61, 'wood', '枯枝背面', .045],
      [.83, .81, 'tree-behind', '树后腐木', .042]
    ]
  },
  'ln-edge': {
    title: '山脚林缘', atmosphere: '林与草地的交界处，光影会藏住小小的菌盖。',
    terrain: 'Temperate foothill woodland edge, patchwork of long grasses, bare humus and weathered deciduous roots, hazel shrubs and an uneven oak woodland behind. Foreground rotting wood and a fallen branch at x=63%, y=58%. Natural herbaceous plants and russet leaf fragments. Late afternoon gentle sidelight with realistic shadow pockets, no road, fences or livestock.',
    spots: [
      [.17, .80, 'grass', '草叶阴影里', .034],
      [.39, .71, 'roots', '埋木根旁', .046],
      [.63, .58, 'wood', '林缘枯木', .049],
      [.83, .83, 'grass', '腐殖土边', .036]
    ]
  }
})

export function habitatAssets(sceneId) {
  const photoSources = { 'jl-mixed': 'yn-pine', 'ln-oak': 'hl-mixed', 'hl-meadow': 'ln-edge' }
  return {
    panorama: `assets/exploration/natural/scenes/${sceneId}.jpg`,
    card: `assets/exploration/natural/cards/${sceneId}.jpg`,
    hasGeneratedArt: GENERATED_HABITAT_IDS.includes(sceneId),
    fallbackCropTop: ['hl-meadow', 'ln-edge'].includes(sceneId) ? .35 : 0,
    fallbackPhoto: `assets/exploration/habitats/${photoSources[sceneId] || sceneId}.jpg`
  }
}

// Current photographic prototype: align each attachment with visible wood/root
// features. These are separate from the proposed generated-art composition.
export const PHOTO_SPOTS = Object.freeze({
  'yn-pine': [[.18,.76], [.85,.66], [.64,.80], [.43,.83]],
  'yn-alpine': [[.17,.77], [.39,.68], [.63,.82], [.84,.76]],
  'hl-mixed': [[.18,.72], [.39,.82], [.82,.52], [.86,.81]],
  'hl-meadow': [[.20,.915], [.43,.91], [.69,.90], [.85,.91]],
  'jl-mixed': [[.20,.82], [.86,.43], [.62,.80], [.32,.73]],
  'jl-river': [[.76,.79], [.46,.47], [.91,.66], [.31,.78]],
  'ln-oak': [[.19,.61], [.40,.83], [.755,.665], [.84,.74]],
  'ln-edge': [[.17,.914], [.686,.90], [.658,.715], [.43,.919]]
})
