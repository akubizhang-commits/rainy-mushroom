// Progression system (03 §3.4 step 11, §3.8). Pure logic only: no Math.random
// (uses SurvivorRandom sub-stream), no Date.now, no cc/wx.
//
// - xpToNext(L) = floor(5 + 6(L − 1) + 0.15(L − 1)²) (01 §15.1 / §15.2 table).
// - Banking xp can cross several level thresholds at once; each crossing enqueues one
//   pending level-up. SurvivorRun pops the queue to drive the levelup state.
// - draftOffer(state, rng) returns three cards following 01 §8.2 / §8.3:
//   evolution (S3 B2; gate 2026-10 S3 平衡): a weapon at max level whose `evolvesWith` passive is
//   at Lv ≥ EVOLUTION.passiveLevel (3), not evolved yet, once state.timeSec ≥ EVOLUTION.unlockSec
//   (6:00), is evolvable; if any, card 1 is fixed to the evolution card
//   of the earliest-acquired evolvable weapon (only one, no random numbers), the other two
//   are drawn as usual. Evolved weapons never get upgrade cards again.
//   candidate pool = upgrades of owned, non-maxed weapons/passives (weight 10) + every
//   unowned weapon while weapon slots remain (8) + every unowned passive while passive
//   slots remain (4, 08 K11). Only weapons with non-empty `levels` and passives present in
//   data/passives.js qualify (S2: all five weapons, 08 K8 — with 4 weapon slots each run
//   leaves one out; once 4 are owned no new-weapon card appears). Weighted draw without
//   replacement; short pools are padded with fallback cards (一捧露水 / 闪亮孢子, may
//   repeat). First level-up: at least one new-weapon card (首升保底). Pure, so tests
//   can enumerate it.
// Xianxia S4: target-stage candidates and committed-level evolution gates.
// Run owns lastEvolutionOfferedId, weaponUpgradeMisses and newWeaponMisses;
// drafting reads them without mutation, once per displayed offer.

import { WEAPONS, EVOLUTION, SWORD_EVOLUTION } from './data/weapons.js'
import { PASSIVES } from './data/passives.js'
import { PLAYER } from './data/player.js'
import { CLASSES } from '../xianxia/Catalog.js'
import { PILLS } from '../xianxia/Pills.js'

export const CLASSIC_WEAPON_IDS = Object.freeze(['spore_shot', 'umbrella_blades', 'dew_ring', 'raindrop', 'leaf_boomerang'])
export const CLASSIC_PASSIVE_IDS = Object.freeze(['might', 'cooldown', 'area', 'regen', 'speed', 'magnet'])

export function xpToNext(level) {
  const L = level
  return Math.floor(5 + 6 * (L - 1) + 0.15 * (L - 1) * (L - 1))
}

// Fallback cards always available (03 §3.8 兜底卡). ids are stable for compliance/strings.
export const CARD_HEAL = Object.freeze({ kind: 'heal', id: 'heal_dew', amount: 30 })
export const CARD_CRYSTAL = Object.freeze({ kind: 'crystal', id: 'shiny_spore', amount: 5 })

// Progression state carried on the run.
export function makeProgression() {
  return {
    level: 1,
    xp: 0,              // xp accumulated toward the next level
    needed: xpToNext(1),
    pendingLevels: 0,   // queued level-ups awaiting a card choice
    totalLevelUps: 0,   // how many level-ups have been resolved (for 首升保底)
  }
}

// Bank xp; may enqueue multiple level-ups. Returns the number of new level-ups queued.
export function addXp(prog, amount) {
  prog.xp += amount
  let gained = 0
  while (prog.xp >= prog.needed) {
    prog.xp -= prog.needed
    prog.level += 1
    prog.pendingLevels += 1
    prog.needed = xpToNext(prog.level)
    gained += 1
  }
  return gained
}

// Card weights (01 §8.2 第 3 条权重表). Evolution / fallback cards are not weighted.
export const WEIGHT_UPGRADE = 10
export const WEIGHT_NEW_WEAPON = 8
export const WEIGHT_NEW_PASSIVE = 4 // 08 K11：6 → 4

// Build the candidate list for an offer. `state` = {
//   weapons: [{id, level}] (equipped, in acquisition order),
//   passives: {id: level},
//   weaponSlots?, passiveSlots? (default data/player.js),
// }. Returns [{card, weight}] in a stable order (owned order, then data order).
export function draftCandidates(state) {
  const cultivation = state.ruleset === 'xianxia'
  const weaponIds = cultivation ? CLASSES.sword.weaponPool : CLASSIC_WEAPON_IDS
  const passiveIds = cultivation ? CLASSES.sword.passivePool : CLASSIC_PASSIVE_IDS
  const weapons = state.weapons || []
  const passives = state.passives || {}
  const weaponSlots = Number.isInteger(state.weaponSlots) ? state.weaponSlots : PLAYER.weaponSlots
  const passiveSlots = Number.isInteger(state.passiveSlots) ? state.passiveSlots : PLAYER.passiveSlots
  const out = []
  // The pending choice unlocks its stage, while evolution uses committed state only.
  const targetLevel = state.targetLevel ?? ((state.appliedLevel ?? 1) + 1)
  const owned = new Set()
  for (const w of weapons) {
    owned.add(w.id)
    const def = WEAPONS[w.id]
    if (!weaponIds.includes(w.id) || !def || def.levels.length === 0 || w.evolved) continue
    if (cultivation && (!Number.isInteger(w.level) || w.level < 1)) continue
    if (w.level < def.levels.length) {
      out.push({ card: card('weapon', w.id, w.level + 1, false), weight: WEIGHT_UPGRADE })
    }
  }
  const ownedPassives = Object.keys(passives).filter((id) => passiveIds.includes(id) && PASSIVES[id] && passives[id] >= 1)
  for (const id of ownedPassives) {
    if (cultivation && !Number.isInteger(passives[id])) continue
    if (passives[id] < PASSIVES[id].levels.length) {
      out.push({ card: card('passive', id, passives[id] + 1, false), weight: WEIGHT_UPGRADE })
    }
  }
  if (weapons.length < weaponSlots) {
    for (const id of weaponIds) {
      if (owned.has(id) || !WEAPONS[id] || WEAPONS[id].levels.length === 0) continue
      if (cultivation && ['sj_line', 'sj_shadow', 'sj_formation'].includes(id) && !(targetLevel >= 10)) continue
      out.push({ card: card('weapon', id, 1, true), weight: WEIGHT_NEW_WEAPON })
    }
  }
  if (ownedPassives.length < passiveSlots) {
    for (const id of passiveIds) {
      if (!PASSIVES[id] || ownedPassives.includes(id)) continue
      if (cultivation && id === 'sj_gate' && !(targetLevel >= 10)) continue
      out.push({ card: card('passive', id, 1, true), weight: WEIGHT_NEW_PASSIVE })
    }
  }
  if (cultivation && state.targetLevel >= 5) {
    for (const id of CLASSES.sword.pillPool) if (PILLS[id]) out.push({ card: Object.freeze({ kind: 'pill', id }), weight: 3 })
  }
  return out
}

// 01 §8.3: the earliest-acquired weapon (state.weapons order) that can evolve now, or null.
// weapons entries are {id, level, evolved?}; passives is {id: level}. Gate (data/weapons.js
// EVOLUTION, 2026-10 S3 平衡): passive level ≥ EVOLUTION.passiveLevel and timeSec ≥
// EVOLUTION.unlockSec. timeSec omitted = no time gate (pure tests); SurvivorRun always passes run.time.
export function evolvableWeapon(weapons, passives, timeSec = Infinity, classPassive = null, ruleset = 'survivor') {
  // The fourth argument is retained for callers from the former cultivation slice.
  // A legacy class passive is also a cultivation marker; S1 has no evolutions.
  if (ruleset === 'xianxia' || classPassive) return null
  const p = passives || {}
  if (!(timeSec >= EVOLUTION.unlockSec)) return null
  for (const w of weapons || []) {
    const def = WEAPONS[w.id]
    if (!CLASSIC_WEAPON_IDS.includes(w.id) || !def || !def.evolved || w.evolved) continue
    if (w.level < def.levels.length) continue
    const requiredLevel = p[def.evolvesWith]
    if (!(requiredLevel >= EVOLUTION.passiveLevel)) continue
    return w
  }
  return null
}
// Shared with Run's choice validator. Returns inventory entries in acquisition order.
// No inferred committed level or omitted time bypass is allowed for sword evolutions.
export function eligibleEvolutions(state) {
  if (state.ruleset !== 'xianxia') {
    const first = evolvableWeapon(state.weapons, state.passives, state.timeSec, null, state.ruleset)
    return first ? [first] : []
  }
  const weapons = state.weapons || []
  if (!Number.isInteger(state.appliedLevel) || state.appliedLevel < SWORD_EVOLUTION.appliedLevel ||
      !Number.isFinite(state.timeSec) || state.timeSec < SWORD_EVOLUTION.unlockSec ||
      weapons.filter(w => w.evolved).length >= SWORD_EVOLUTION.maxEvolved) return []
  return weapons.filter(w => {
    const def = WEAPONS[w.id]
    const passiveLevel = state.passives?.[def?.evolvesWith]
    return CLASSES.sword.weaponPool.includes(w.id) && def?.evolved && !w.evolved &&
      w.level === def.levels.length && Number.isInteger(passiveLevel) &&
      passiveLevel >= SWORD_EVOLUTION.passiveLevel
  })
}

function nextEvolution(state) {
  const eligible = eligibleEvolutions(state)
  if (state.ruleset !== 'xianxia' || eligible.length < 2) return eligible[0]
  const weapons = state.weapons || []
  const last = weapons.findIndex(w => w.id === state.lastEvolutionOfferedId)
  if (last < 0) return eligible[0]
  // Search inventory, not just the eligible subset: last shown may now be evolved.
  for (let step = 1; step <= weapons.length; step++) {
    const next = weapons[(last + step) % weapons.length]
    if (eligible.includes(next)) return next
  }
}

// Evolution card (01 §8.2 第 1 条，金色边框由表现层画). level = 进化档（满级 + 1）.
export function evolveCard(id, ruleset = 'survivor') {
  const def = WEAPONS[id]
  const ids = ruleset === 'xianxia' ? CLASSES.sword.weaponPool : CLASSIC_WEAPON_IDS
  if (!ids.includes(id) || !def?.evolved) return null
  return Object.freeze({ kind: 'evolve', id, level: def.levels.length + 1, isNew: false, evolution: def.evolution })
}
// Build the three-card offer for the current pending level-up (see header). `state` is
// as in draftCandidates plus `isFirstLevelUp`. Card shape:
//   {kind:'weapon'|'passive', id, level, isNew, evolution:false},
//   {kind:'evolve', id (weapon id), level, isNew:false, evolution (evolved form id)} or a fallback card.
// Without the first-level-up guarantee, offer[i] is the i-th weighted draw, so the
// first card's type frequency follows the weight ratio.
export function draftOffer(state, rng) {
  const pool = draftCandidates(state)
  const cards = []
  const cultivation = state.ruleset === 'xianxia'
  const evo = nextEvolution(state)
  if (evo) {
    cards.push(evolveCard(evo.id, state.ruleset))
    for (let i = pool.length - 1; i >= 0; i--) if (pool[i].card.id === evo.id) pool.splice(i, 1)
  }
  if (cultivation) {
    if (state.isFirstLevelUp) {
      for (const [id, level] of [['sj_arc', 1], ['sj_wanjian', 1]]) {
        const index = pool.findIndex(({ card: c }) => c.kind === 'weapon' && c.id === id && c.level === level)
        if (index >= 0 && cards.length < 3) cards.push(pool.splice(index, 1)[0].card)
      }
      if (cards.filter(c => c.kind === 'weapon').length < 2 && cards.length < 3) {
        const initial = pool.findIndex(({ card: c }) => c.kind === 'weapon' && c.id === 'sj_yujian' && !c.isNew)
        if (initial >= 0) cards.push(pool.splice(initial, 1)[0].card)
      }
      // Even a restored first-offer state must not substitute a pill for its third card.
      for (let i = pool.length - 1; i >= 0; i -= 1) if (pool[i].card.kind === 'pill') pool.splice(i, 1)
    }
    if (state.breakthrough && !cards.some(c => c.kind === 'weapon' || c.kind === 'evolve')) {
      takeGuaranteedWeapon(pool, cards, rng, false)
    }
    if (state.weaponUpgradeMisses >= 2 && !cards.some(c => c.kind === 'weapon' && !c.isNew)) {
      takeGuaranteedWeapon(pool, cards, rng, true)
    }
    // Match candidate unlock and Run's miss counter, including later Jindan drafts.
    const targetLevel = state.targetLevel ?? ((state.appliedLevel ?? 1) + 1)
    const stageIds = targetLevel >= 10 ? ['sj_line', 'sj_shadow', 'sj_formation'] : []
    const stageNew = c => c.isNew && stageIds.includes(c.id)
    if (state.newWeaponMisses >= 2 && !cards.some(c => c.kind === 'weapon' && stageNew(c))) {
      takeGuaranteedWeapon(pool, cards, rng, false, stageNew)
    }
  } else if (state.isFirstLevelUp) {
    // 首升保底：先从新武器卡中抽 1 张（权重相同 → 均匀）。
    let best = -1
    let total = 0
    for (let i = 0; i < pool.length; i += 1) if (pool[i].card.kind === 'weapon' && (!state.isFirstLevelUp || pool[i].card.isNew)) total += pool[i].weight
    if (total > 0) {
      let roll = rng.next() * total
      for (let i = 0; i < pool.length; i += 1) {
        const c = pool[i]
        if (!(c.card.kind === 'weapon' && (!state.isFirstLevelUp || c.card.isNew))) continue
        best = i
        roll -= c.weight
        if (roll < 0) break
      }
      cards.push(pool[best].card)
      pool.splice(best, 1)
    }
  }
  while (cards.length < 3 && pool.length > 0) {
    let total = 0
    for (let i = 0; i < pool.length; i += 1) total += pool[i].weight
    let roll = rng.next() * total
    let pick = pool.length - 1
    for (let i = 0; i < pool.length; i += 1) {
      roll -= pool[i].weight
      if (roll < 0) {
        pick = i
        break
      }
    }
    const selected = pool[pick].card
    cards.push(selected)
    pool.splice(pick, 1)
    if (selected.kind === 'pill') for (let i = pool.length - 1; i >= 0; i -= 1) if (pool[i].card.kind === 'pill') pool.splice(i, 1)
  }
  // 兜底卡（01 §8.2 第 4 条，可重复）：先放两张不同的，仍不足再补一捧露水。
  if (cards.length < 3) {
    const fallbacks = rng.shuffle([CARD_HEAL, CARD_CRYSTAL])
    for (let i = 0; i < fallbacks.length && cards.length < 3; i += 1) cards.push(fallbacks[i])
    while (cards.length < 3) cards.push(CARD_HEAL)
  }
  return cards
}

function takeGuaranteedWeapon(pool, cards, rng, ownedOnly, predicate = () => true) {
  const eligible = ({ card: c }) => c.kind === 'weapon' && (!ownedOnly || !c.isNew) && predicate(c)
  const total = pool.reduce((sum, entry) => sum + (eligible(entry) ? entry.weight : 0), 0)
  if (total === 0 || cards.length >= 3) return
  let roll = rng.next() * total
  let pick = -1
  for (let i = 0; i < pool.length; i += 1) {
    if (!eligible(pool[i])) continue
    pick = i
    roll -= pool[i].weight
    if (roll < 0) break
  }
  cards.push(pool.splice(pick, 1)[0].card)
}

function card(kind, id, level, isNew) {
  return Object.freeze({ kind, id, level, isNew, evolution: false })
}
