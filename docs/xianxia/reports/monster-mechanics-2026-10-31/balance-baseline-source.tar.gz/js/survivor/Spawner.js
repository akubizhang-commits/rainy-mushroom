// Spawner (03 §3.4 step 3, §3.8). Pure logic only: no Math.random (uses SurvivorRandom),
// no Date.now, no cc/wx.
//
// - Accumulates `spawnRate × DT` per step and spawns the whole-number part (03 §3.8).
// - Spawn position: on a circle of radius `spawnRadius` = hypot(viewW/2, viewH/2) + margin
//   (03 §1-2), at a random angle from the `spawn` sub-stream, centred on the player.
// - Composition is drawn by weight from the active wave segment (percent weights).
// - On-screen cap: never exceed the segment cap or the enemy pool capacity.
// - Timed events (WAVES.events: 2:30 ring, 4:30 cross, 5:00 elite, 6:30 snail wall) fire
//   once each and obey the global hard cap of 200 (01 §10). The 5:00 elite (S3 B4) spawns
//   on the spawn circle at a random angle; if the field is at the hard cap it waits
//   (pendingElites) and spawns on the first step with a free slot, so it is never lost. A ring with `gap` (6:30 wall, 08 K12)
//   anchors its slots on the player's facing and consumes no random numbers.
// - Diagnostics (08 L11 / OBS-1): spawns skipped because the segment cap or the global
//   hard cap is full are designed behaviour → diag.capSkipped.enemies; only a full
//   enemy pool (03 §10) counts as diag.dropped.enemies.
// - Enemies that drift beyond max(900, spawnRadius + 120) are relocated back onto the
//   spawn circle around the player (03 §1-2, §3.8). Elites and the Boss are exempt (01 §9).

import { ENEMIES } from './data/enemies.js'
import { WAVES } from './data/waves.js'
import { LIMITS } from './data/limits.js'
import { enemyHp, enemyContactDamage } from './Stats.js'
import { resetEnemy } from './Enemies.js'
import { scaleEnemyHp, scaleEnemyDamage } from '../xianxia/Realms.js'
import { COURTYARD, isCourtyard, courtyardSpawnPosition } from '../xianxia/Courtyard.js'

const TWO_PI = Math.PI * 2

// Compute the spawn radius from the viewport (03 §1-2).
export function spawnRadiusFor(viewport, margin) {
  return Math.hypot(viewport.width / 2, viewport.height / 2) + margin
}

export function relocateDistanceFor(spawnRadius) {
  return Math.max(900, spawnRadius + 120)
}

// Pick an enemy id from a segment's composition (percent weights) using rng.
// Deterministic: iterates composition entries in insertion order.
export function pickComposition(composition, rng) {
  const roll = rng.next() * 100
  let acc = 0
  let last = null
  for (const id in composition) {
    last = id
    acc += composition[id]
    if (roll < acc) return id
  }
  return last // guards against float rounding when weights sum to exactly 100
}

// Find the wave segment covering `timeSec`; the last segment may be open-ended
// (`toSec: null`, 08 K2). Returns null only past a closed last segment.
export function segmentAt(timeSec) {
  const segments = WAVES.segments
  for (let i = 0; i < segments.length; i += 1) {
    const s = segments[i]
    if (timeSec >= s.fromSec && (s.toSec === null || timeSec < s.toSec)) return s
  }
  return null
}

// Living enemies that count toward the segment / hard caps. The Boss sits in one of
// the pool's reserved slots (03 §3.5) and never counts (world.bossEnemy, SurvivorRun).
export function normalEnemyCount(world) {
  return world.enemies.count - (world.bossEnemy ? 1 : 0)
}

// Facing angle θf of the player (01 §4: last non-zero move direction).
export function ringAnchorAngle(player) {
  const fx = Number.isFinite(player.dirX) ? player.dirX : 0
  const fy = Number.isFinite(player.dirY) ? player.dirY : 0
  return fx === 0 && fy === 0 ? 0 : Math.atan2(fy, fx)
}

export class Spawner {
  constructor(viewport, margin, rng) {
    this.spawnRadius = spawnRadiusFor(viewport, margin)
    this.relocateDistance = relocateDistanceFor(this.spawnRadius)
    // Cross-event column starts / ends this far beside the player (screen half-width + margin).
    this.crossLimit = viewport.width / 2 + margin
    this.rng = rng
    this.accumulator = 0
    this.nextEvent = 0 // index into WAVES.events; each event fires once
    this.pendingElites = [] // elite events waiting for a free slot under the hard cap
  }

  // One step. `world` provides: time, player, enemies (Pool), diag.
  step(world, dt) {
    this._relocate(world)
    const minute = Math.floor(world.time / 60) // 01 §9.1: whole minutes
    this._events(world, minute)
    this._pendingElites(world, minute)
    const seg = segmentAt(world.time)
    if (!seg) {
      // Past a closed last segment: no routine spawns, but relocation above still
      // keeps existing enemies in range.
      return
    }
    this.accumulator += seg.spawnRate * dt
    let due = Math.floor(this.accumulator)
    if (due <= 0) return
    this.accumulator -= due
    while (due > 0) {
      due -= 1
      if (normalEnemyCount(world) >= seg.cap) {
        world.diag.capSkipped.enemies += 1
        continue
      }
      const id = pickComposition(seg.composition, this.rng)
      const angle = this.rng.next() * TWO_PI
      this._spawnOne(world, id, minute, {
        x: world.player.x + Math.cos(angle) * this.spawnRadius,
        y: world.player.y + Math.sin(angle) * this.spawnRadius,
      })
    }
  }

  // Timed events (01 §10 事件列, data-driven by WAVES.events). Each fires once when the
  // clock reaches atSec; `optional: true` events are skipped (not implemented in S2).
  // Every event spawn obeys the global hard cap (limits.hardCaps.enemies).
  _events(world, minute) {
    const events = WAVES.events
    while (this.nextEvent < events.length && world.time >= events[this.nextEvent].atSec) {
      const ev = events[this.nextEvent]
      this.nextEvent += 1
      if (ev.optional) continue
      const px = world.player.x
      const py = world.player.y
      if (ev.type === 'ring' && ev.gap) {
        // 01 §10 蜗牛围墙缺口：slot k at θf + (360°/slots)(k + 0.5); skipped slots stay
        // empty so the gap faces the player's heading. Spawn in k order, stop at the cap.
        const slots = ev.gap.slots
        const facing = ringAnchorAngle(world.player)
        for (let k = 0; k < slots; k += 1) {
          if (ev.gap.skip.includes(k)) continue
          const a = facing + (TWO_PI * (k + 0.5)) / slots
          if (!this._spawnEvent(world, ev.enemy, minute, { x: px + Math.cos(a) * ev.radius, y: py + Math.sin(a) * ev.radius })) break
        }
      } else if (ev.type === 'ring') {
        // Evenly spaced on a circle around the player, then chase (收拢).
        const start = this.rng.next() * TWO_PI
        for (let i = 0; i < ev.count; i += 1) {
          const a = start + (TWO_PI * i) / ev.count
          if (!this._spawnEvent(world, ev.enemy, minute, { x: px + Math.cos(a) * ev.radius, y: py + Math.sin(a) * ev.radius })) break
        }
      } else if (ev.type === 'elite') {
        for (let i = 0; i < ev.count; i += 1) this.pendingElites.push(ev.enemy)
      } else if (ev.type === 'cross') {
        // A vertical column just outside one side of the screen, flying straight across.
        const dir = this.rng.next() < 0.5 ? 1 : -1
        const speed = ENEMIES[ev.enemy].moveSpeed
        const limit = this.crossLimit
        const life = (2 * limit) / speed + 2 // safety net if the player keeps pace
        for (let i = 0; i < ev.count; i += 1) {
          const y = py + (i - (ev.count - 1) / 2) * ev.spacing
          if (!this._spawnEvent(world, ev.enemy, minute, { x: px - dir * limit, y, behavior: 'cross', dirX: dir, dirY: 0, limit, timer: life })) break
        }
      }
    }
  }

  // 5:00 精英（01 §9 / §10）：hard cap 满时顺延到有空位；生成在屏外刷怪圆上的随机角度，
  // 生命 / 伤害按生成时的分钟 m 成长（01 §9.1）。One random number per spawned elite.
  _pendingElites(world, minute) {
    const queue = this.pendingElites
    while (queue.length > 0) {
      if (normalEnemyCount(world) >= LIMITS.hardCaps.enemies) return
      const id = queue[0]
      const angle = this.rng.next() * TWO_PI
      const ok = this._spawnOne(world, id, minute, {
        x: world.player.x + Math.cos(angle) * this.spawnRadius,
        y: world.player.y + Math.sin(angle) * this.spawnRadius,
        timer: ENEMIES[id].chargeEvery,
      })
      if (!ok) return // pool full (counted in diag.dropped): retry next step
      queue.shift()
      const e = world.enemies.active[world.enemies.count - 1]
      world.events.push({ type: 'eliteSpawn', x: e.x, y: e.y })
    }
  }

  // Boss 召唤虫群 (01 §9.2): `count` × `id` evenly spaced on a circle of `radius`
  // around (cx, cy), obeying the global hard cap (fewer spawn when capped). Returns the
  // number actually spawned.
  spawnAround(world, id, count, cx, cy, radius) {
    const minute = Math.floor(world.time / 60)
    let spawned = 0
    for (let i = 0; i < count; i += 1) {
      const a = (TWO_PI * i) / count
      if (!this._spawnEvent(world, id, minute, { x: cx + Math.cos(a) * radius, y: cy + Math.sin(a) * radius })) break
      spawned += 1
    }
    return spawned
  }

  // Event spawn: global hard cap instead of the segment cap. Returns false when capped.
  _spawnEvent(world, id, minute, at) {
    if (normalEnemyCount(world) >= LIMITS.hardCaps.enemies) {
      world.diag.capSkipped.enemies += 1
      return false
    }
    return this._spawnOne(world, id, minute, at)
  }

  _spawnOne(world, id, minute, at) {
    const def = ENEMIES[id]
    const hpFor = world.ruleset === 'xianxia' ? scaleEnemyHp : enemyHp
    const damageFor = world.ruleset === 'xianxia' ? scaleEnemyDamage : enemyContactDamage
    const enemy = world.enemies.acquire()
    if (!enemy) {
      world.diag.dropped.enemies += 1 // pool full (03 §10)
      return false
    }
    resetEnemy(enemy, {
      kind: id,
      x: at.x,
      y: at.y,
      r: def.radius,
      hp: hpFor(def.hp, def.hpGrowthPerMin, minute),
      speed: def.moveSpeed,
      damage: damageFor(def.contactDamage, def.damageGrowthPerMin, minute),
      xp: def.xp,
      kbRes: def.knockbackResist,
      behavior: at.behavior || def.behavior,
      // Ranged enemies wait one full interval before their first bubble.
      timer: at.timer !== undefined ? at.timer : def.fireInterval || 0,
      dirX: at.dirX,
      dirY: at.dirY,
      limit: at.limit,
    })
    if (isCourtyard(world)) {
      Object.assign(enemy, courtyardSpawnPosition(world, enemy.x, enemy.y, enemy.r))
    }
    return true
  }

  // Relocate enemies that drifted too far back onto the spawn circle (03 §3.8).
  // Cross-event enemies are exempt: they fly straight and are recycled on exit. The
  // Boss is exempt too (01 §9 通用规则：精英与 Boss 不受此规则影响).
  // In the finite courtyard, only a radius crossing the field boundary triggers
  // relocation, regardless of behavior. Valid field positions never need recycling.
  _relocate(world) {
    const enemies = world.enemies
    const px = world.player.x
    const py = world.player.y
    const maxD2 = this.relocateDistance * this.relocateDistance
    const bounds = isCourtyard(world) ? COURTYARD.bounds : null
    for (let i = 0; i < enemies.count; i += 1) {
      const e = enemies.active[i]
      if (bounds) {
        if (e.x - e.r >= bounds.xmin && e.x + e.r <= bounds.xmax &&
            e.y - e.r >= bounds.ymin && e.y + e.r <= bounds.ymax) continue
      } else {
        if (e.behavior === 'cross' || e.behavior === 'boss' || e.behavior === 'charge') continue
        const dx = e.x - px
        const dy = e.y - py
        if (dx * dx + dy * dy <= maxD2) continue
      }
      const angle = this.rng.next() * TWO_PI
      e.x = px + Math.cos(angle) * this.spawnRadius
      e.y = py + Math.sin(angle) * this.spawnRadius
      if (bounds) {
        Object.assign(e, courtyardSpawnPosition(world, e.x, e.y, e.r))
      }
      e.kbX = 0
      e.kbY = 0
    }
  }
}
