// Enemy system (03 §3.4 steps 4 & 6, §3.8). Pure logic only: no Math.random,
// no Date.now, no cc/wx.
//
// Behaviours (01 §9, 03 §3.8): gnat / beetle / snail chase in a straight line; moth
// chases with a perpendicular sway; sporeling approaches to range and spits mist
// bubbles; 4:30 cross moths fly straight and are recycled silently off-screen; the 5:00
// elite (behavior 'charge', S3 B4) chases and every chargeEvery seconds (start-to-start,
// counted from its spawn) stands still for chargeWindup seconds with the direction locked
// toward the player at windup start (eliteCharge event), then dashes chargeDuration seconds
// at ×chargeSpeedMul — the same windup / lock pattern as the Boss charge (Boss.js). The
// Boss (behavior 'boss') is skipped here and driven by Boss.js.
// Knockback impulses from projectiles decay here; separation pushes overlapping
// neighbours apart using the spatial grid (≤6 neighbours, 03 §3.6).
import { ENEMIES } from './data/enemies.js'
import { LIMITS } from './data/limits.js'
import { swordFormationSlow } from './Weapons.js'
import { spawnBubble } from './Projectiles.js'

export function makeEnemy() {
  return {
    slot: 0,
    uid: 0,
    kind: '',
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    r: 10,
    hp: 1,
    maxHp: 1,
    speed: 0,
    damage: 0,
    xp: 0,
    kbRes: 0,  // knockback resistance [0,1]
    kbX: 0,    // residual knockback velocity
    kbY: 0,
    lastHitTime: -1,
    contactCooldown: 0, // per-enemy gate so one enemy hurts the player ≤ once / invuln window
    slow: 0,   // movement slow ratio [0,1); cleared each step 4, re-set by auras (max of sources)
    hitAt: new Float64Array(LIMITS.weaponIndexSlots), // per weapon index; includes xianxia wanjian
    behavior: 'chase', // chase | sway | ranged | cross | charge (data/enemies.js; cross = 4:30 event)
    age: 0,    // seconds since spawn (moth sway phase)
    timer: 0,  // ranged: fire cooldown left; cross: lifetime left; charge: seconds to next windup
    phase: 0,  // charge: 0 chase, 1 windup (still, dir locked), 2 dash
    phaseLeft: 0, // charge: seconds left in windup / dash
    dirX: 0,   // cross: fixed flight direction; charge: locked dash direction
    dirY: 0,
    limit: 0,  // cross: recycle once dirX·(x − player.x) exceeds this (screen half-width + margin)
    takenMul: 1, // damage-taken multiplier; only the Boss changes it (01 §9.2 超时兜底)
  }
}

// Reset an enemy on spawn. `spec` carries resolved per-minute values from the spawner.
export function resetEnemy(enemy, spec) {
  enemy.kind = spec.kind
  enemy.x = spec.x
  enemy.y = spec.y
  enemy.vx = 0
  enemy.vy = 0
  enemy.r = spec.r
  enemy.hp = spec.hp
  enemy.maxHp = spec.hp
  enemy.speed = spec.speed
  enemy.damage = spec.damage
  enemy.xp = spec.xp
  enemy.kbRes = spec.kbRes
  enemy.kbX = 0
  enemy.kbY = 0
  enemy.lastHitTime = -1
  enemy.contactCooldown = 0
  enemy.slow = 0
  enemy.hitAt.fill(0)
  enemy.behavior = spec.behavior || 'chase'
  enemy.age = 0
  enemy.timer = spec.timer || 0
  enemy.phase = 0
  enemy.phaseLeft = 0
  enemy.dirX = spec.dirX || 0
  enemy.dirY = spec.dirY || 0
  enemy.limit = spec.limit || 0
  enemy.takenMul = 1
}

const KB_DECAY = 8 // per-second exponential-ish decay of residual knockback
const TWO_PI = Math.PI * 2
// Step 4: behaviour (chase / sway / ranged / cross), apply + decay knockback.
// Movement integrates here. Iterates backwards because cross enemies that leave the
// screen are released (swap-remove) silently: no spores, no purify count (03 §3.8).
export function stepEnemyBehavior(world, dt) {
  const enemies = world.enemies
  const px = world.player.x
  const py = world.player.y
  for (let i = enemies.count - 1; i >= 0; i -= 1) {
    const e = enemies.active[i]
    // The Boss moves in Boss.js (stepBoss, right after this pass).
    if (e.behavior === 'boss') continue
    const def = ENEMIES[e.kind]
    // Slow from auras set last step (dew_ring, max of sources), then cleared so it
    // only lasts while the enemy stays inside (03 §3.4 step 4).
    const slow = Math.max(e.slow, swordFormationSlow(world, e))
    const speed = e.speed * (1 - slow)
    e.slow = 0
    const dx = px - e.x
    const dy = py - e.y
    const dist = Math.hypot(dx, dy) || 1
    const ux = dx / dist
    const uy = dy / dist
    let vx
    let vy
    if (e.behavior === 'cross') {
      // Straight line, no tracking (01 §10 4:30 灰蛾横穿).
      vx = e.dirX * speed
      vy = e.dirY * speed
      e.timer -= dt
      if (e.timer <= 0 || e.dirX * (e.x - px) > e.limit) {
        enemies.release(e)
        continue
      }
    } else if (e.behavior === 'sway' && def) {
      // Tracking + perpendicular sway: lateral offset A·sin(ωt) → velocity A·ω·cos(ωt).
      const omega = TWO_PI / def.swayPeriod
      const lateral = def.swayAmplitude * omega * Math.cos(omega * e.age) * (1 - slow)
      vx = ux * speed - uy * lateral
      vy = uy * speed + ux * lateral
    } else if (e.behavior === 'charge' && def) {
      // 精英冲撞（01 §9）：chase → windup（原地、锁向）→ dash（×chargeSpeedMul）→ chase。
      e.timer -= dt
      if (e.phase === 1) {
        vx = 0
        vy = 0
        e.kbX = 0 // 蓄力期间不被击退挪动
        e.kbY = 0
        e.phaseLeft -= dt
        if (e.phaseLeft <= 1e-9) {
          e.phase = 2
          e.phaseLeft = def.chargeDuration
        }
      } else if (e.phase === 2) {
        vx = e.dirX * speed * def.chargeSpeedMul
        vy = e.dirY * speed * def.chargeSpeedMul
        e.phaseLeft -= dt
        if (e.phaseLeft <= 1e-9) {
          e.phase = 0
          e.phaseLeft = 0
        }
      } else if (e.timer <= 1e-9) {
        e.timer += def.chargeEvery
        e.phase = 1
        e.phaseLeft = def.chargeWindup
        e.dirX = ux
        e.dirY = uy
        vx = 0
        vy = 0
        e.kbX = 0
        e.kbY = 0
        world.events.push({ type: 'eliteCharge', dx: ux, dy: uy })
      } else {
        vx = ux * speed
        vy = uy * speed
      }
    } else if (e.behavior === 'ranged' && def) {
      // Approach while farther than approachRange, otherwise hold position; spit a
      // mist bubble every fireInterval while within fireRange (01 §9 迷途菌灵).
      if (dist > def.approachRange) {
        vx = ux * speed
        vy = uy * speed
      } else {
        vx = 0
        vy = 0
      }
      if (e.timer > 0) e.timer -= dt
      if (dist <= def.fireRange && e.timer <= 0) {
        spawnBubble(world, e.x, e.y, px, py, def.bubble, e.kind)
        e.timer = def.fireInterval
      }
    } else {
      // Straight-line tracking toward the player (gnat / beetle / snail).
      vx = ux * speed
      vy = uy * speed
    }
    e.age += dt
    e.x += (vx + e.kbX) * dt
    e.y += (vy + e.kbY) * dt
    e.vx = vx
    e.vy = vy
    // Decay knockback toward zero.
    const decay = Math.max(0, 1 - KB_DECAY * dt)
    e.kbX *= decay
    e.kbY *= decay
    if (e.contactCooldown > 0) e.contactCooldown -= dt
  }
}
// Step 6: push overlapping enemies apart (grid neighbours, ≤6), then keep them from
// overlapping the player (03 §3.6: slide to player.r + enemy.r along the connecting line).
export function stepSeparation(world) {
  const enemies = world.enemies
  const grid = world.grid
  const buf = world.queryBuf
  const px = world.player.x
  const py = world.player.y
  const pr = world.player.r
  for (let i = 0; i < enemies.count; i += 1) {
    const e = enemies.active[i]
    const n = grid.queryCircle(e.x, e.y, e.r, buf)
    let handled = 0
    for (let k = 0; k < n && handled < 6; k += 1) {
      const other = enemies.items[buf[k]]
      if (other === e || !enemies.isActive(other)) continue
      const dx = e.x - other.x
      const dy = e.y - other.y
      const minDist = e.r + other.r
      const d2 = dx * dx + dy * dy
      if (d2 >= minDist * minDist || d2 === 0) {
        if (d2 === 0) {
          // Perfectly coincident: nudge deterministically along +x by half the radius.
          e.x += minDist * 0.25
          other.x -= minDist * 0.25
          handled += 1
        }
        continue
      }
      const dist = Math.sqrt(d2)
      const overlap = minDist - dist
      // Each moves half the overlap × 0.5 (03 §3.6).
      const push = (overlap * 0.5) / dist
      const sx = dx * push
      const sy = dy * push
      if (e.behavior === 'boss') {
        // The Boss (kbRes 100%) is not jostled by small enemies: they take the full push.
        other.x -= 2 * sx
        other.y -= 2 * sy
      } else {
        e.x += sx
        e.y += sy
        other.x -= sx
        other.y -= sy
      }
      handled += 1
    }
    // Do not let the enemy overlap the player: slide to touching distance.
    const pdx = e.x - px
    const pdy = e.y - py
    const touch = pr + e.r
    const pd2 = pdx * pdx + pdy * pdy
    if (pd2 < touch * touch) {
      const pd = Math.sqrt(pd2) || 1
      e.x = px + (pdx / pd) * touch
      e.y = py + (pdy / pd) * touch
    }
  }
}
