// 局外成长纯函数（03 §2 Meta.js、01-gdd §13）。Pure logic only: no storage, no cc/wx,
// no Date/Math.random. 所有函数不修改入参，返回新的 profile 对象；profile 结构见
// 03 §5.2 schema 1，调用方应传入经 SurvivorSave 清洗过的 profile。
import { PERMANENT, CRYSTAL_CAP } from './data/permanent.js'

const BY_ID = new Map(PERMANENT.map((p) => [p.id, p]))

function cloneProfile(profile) {
  return {
    ...profile,
    permanent: { ...profile.permanent },
    settings: { ...profile.settings },
    tutorial: { ...profile.tutorial },
  }
}
function level(profile, id) {
  return (profile.permanent && profile.permanent[id]) || 0
}
function round6(x) {
  return Math.round(x * 1e6) / 1e6
}
function nonNegInt(x) {
  return Number.isFinite(x) && x > 0 ? Math.floor(x) : 0
}

// 01 §13.1 露晶公式，返回各项明细（结算页逐项展示，02 §4.6）。
export function crystalsForRun(summary) {
  const s = summary || {}
  const survival = Math.floor(nonNegInt(s.survivalSec) / 10)
  const purified = Math.floor(nonNegInt(s.purified) / 50)
  const elite = nonNegInt(s.eliteDefeated) > 0 ? 5 : 0
  const boss = s.bossDefeated ? 30 : 0
  const victory = s.outcome === 'won' ? 20 : 0
  const shiny = nonNegInt(s.shinyCards) * 5
  return { survival, purified, elite, boss, victory, shiny, total: survival + purified + elite + boss + victory + shiny }
}

// 结算：发放露晶、累计局数/胜场、更新最佳存活。放弃按失败结算，露晶照常（01 §12）。
export function settle(profile, summary) {
  const earned = crystalsForRun(summary)
  const next = cloneProfile(profile)
  next.crystals = Math.min(CRYSTAL_CAP, profile.crystals + earned.total)
  next.runs = profile.runs + 1
  if (summary && summary.outcome === 'won') next.wins = profile.wins + 1
  next.bestSurvivalSec = Math.max(profile.bestSurvivalSec, nonNegInt(summary && summary.survivalSec))
  return { profile: next, earned }
}

// 局外加成，字段与 Stats.readBonuses 对齐。
export function bonuses(profile) {
  const out = { maxHp: 0, might: 0, moveSpeed: 0, pickup: 0, regen: 0 }
  for (const p of PERMANENT) out[p.bonus] = round6(out[p.bonus] + p.perLevel * level(profile, p.id))
  return out
}

// 下一级价格；满级或未知 id 返回 null。
export function nextPrice(profile, id) {
  const p = BY_ID.get(id)
  if (!p) return null
  const lv = level(profile, id)
  return lv < p.prices.length ? p.prices[lv] : null
}

// 购买一级。失败不改变 profile：reason ∈ 'unknown' | 'max' | 'insufficient'。
export function buy(profile, id) {
  if (!BY_ID.has(id)) return { ok: false, reason: 'unknown', profile }
  const price = nextPrice(profile, id)
  if (price === null) return { ok: false, reason: 'max', profile }
  if (profile.crystals < price) return { ok: false, reason: 'insufficient', profile }
  const next = cloneProfile(profile)
  next.crystals = profile.crystals - price
  next.permanent[id] = level(profile, id) + 1
  return { ok: true, price, profile: next }
}

// 当前所有强化已花费的露晶（重置时全额退还的数额）。
export function spentTotal(profile) {
  let sum = 0
  for (const p of PERMANENT) {
    const lv = Math.min(level(profile, p.id), p.prices.length)
    for (let i = 0; i < lv; i++) sum += p.prices[i]
  }
  return sum
}

// 免费重置，全额退还（01 §13.2）。
export function reset(profile) {
  const refunded = spentTotal(profile)
  const next = cloneProfile(profile)
  next.crystals = Math.min(CRYSTAL_CAP, profile.crystals + refunded)
  for (const p of PERMANENT) next.permanent[p.id] = 0
  return { profile: next, refunded }
}
