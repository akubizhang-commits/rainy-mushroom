// Boss 浊雾巨蜗 boss_mist_snail (01 §9.2, 03 §3.4 steps 3–4). Pure logic only: no
// Math.random, no Date.now, no cc/wx.
//
// - Spawned once at WAVES.boss.atSec straight above the player, just off-screen, into
//   one of the enemy pool's reserved slots (03 §3.5). Fixed stats: no §9.1 growth, no
//   far-away relocation (Spawner skips behavior 'boss'), r56 → grid `large` list.
// - Three skills, each on its own start-to-start cooldown counted from the spawn:
//     summon     — every 8 s, 12 gnats evenly around the Boss (global hard cap applies)
//     charge     — every 6 s: 0.8 s windup (stands still, direction locked → bossCharge
//                  event + run.boss.dirX/dirY for the arrow), then 1 s at ×2.5 speed
//     bubbleRing — every 10 s but only while hp < 50%: 8 mist bubbles in 8 directions
// - 超时兜底 (01 §9.2, 08 K13): `def.enrage` phases sorted by atSec (10:00 狂暴 I,
//   11:00 狂暴 II) — a later phase REPLACES the earlier multipliers (never stacked):
//   speedMul (move speed), damageMul (contact + mist bubble), cooldownMul (all three
//   skills), ringIgnoresHp (bubble ring no longer needs hp < 50%), takenMul (damage the
//   Boss takes, applied before rounding via enemy.takenMul). `def.erosion` (雾壳剥落)
//   adds takenStep per full everySec from fromSec, capped at takenMax. Every new stage
//   (including each erosion layer) emits one bossEnrage event with its stage number.
//   No timeout defeat.
// - 贴近追击 (01 §9.2, 08 K15/L13): from enrageStage ≥ def.approach.fromStage (狂暴 II and
//   every erosion layer after it), while in 'chase': d > enterDist → approaching (one
//   bossApproach event per entry); approaching and d ≤ exitDist → back to normal. While
//   approaching the Boss moves at the fixed approach.speed (no speedMul, ignores dew-ring
//   slow) and never starts a charge windup (chargeCd keeps counting down, clamped at 0, so
//   the windup starts on the first non-approaching step). Windup / charge in progress are
//   never interrupted and charge speed stays the non-approach speed × charge.speedMul.
//   Distance / time only — no random numbers.
//   无伤触发 (01 §9.2, 08 K22): independently of the clock, once the Boss has gone
//   approach.idleSec seconds without taking any damage (counted from its spawn or its last
//   hit, via enemy.lastHitTime) it latches b.idleApproach = true and the same approach
//   rules apply for the rest of the fight. The 11:00 (fromStage) rule is unchanged.
// - `world.boss` is the read-only render view (position, hp ratio, current skill /
//   warning direction). `world.bossEnemy` is the live pool entity (null once defeated).
import { swordFormationSlow } from './Weapons.js'
import { ENEMIES } from './data/enemies.js'
import { WAVES } from './data/waves.js'
import { LIMITS } from './data/limits.js'
import { resetEnemy } from './Enemies.js'
import { spawnBubble } from './Projectiles.js'
import { scaleBossHp, scaleEnemyDamage } from '../xianxia/Realms.js'
import { isCourtyard, courtyardSpawnPosition } from '../xianxia/Courtyard.js'

const TWO_PI = Math.PI * 2

function makeBossView(def) {
  return {
    kind: WAVES.boss.enemy,
    x: 0,
    y: 0,
    r: def.radius,
    hp: def.hp,
    maxHp: def.hp,
    hpRatio: 1,
    alive: true,
    skill: 'chase',   // chase | windup (arrow shown) | charge | defeated
    skillLeft: 0,     // seconds left in windup / charge
    dirX: 0,          // locked charge direction (valid during windup / charge)
    dirY: 0,
    enraged: false,
    enrageStage: 0,   // 0 = none, 1 = 狂暴 I, 2 = 狂暴 II, 3+ = 狂暴 II + (stage − 2) 层雾壳剥落
    speedMul: 1,
    damageMul: 1,
    cooldownMul: 1,
    ringIgnoresHp: false,
    approaching: false, // 贴近追击中（01 §9.2，狂暴 II 起或无伤触发后、skill === 'chase' 时可为 true）
    idleApproach: false, // 08 K22：连续 approach.idleSec 秒未受伤后锁定为 true，本场不再复位
    spawnedAt: 0,     // 出现时刻（无伤计时起点）
    takenMul: 1,      // Boss 受到伤害倍率（mirrored on the entity as enemy.takenMul）
    // Skill cooldowns (seconds until next use, start-to-start).
    summonCd: def.summon.every,
    chargeCd: def.charge.every,
    ringCd: def.bubbleRing.every,
    bubble: { ...def.bubbleRing.bubble }, // mutable copy so enrage can scale damage
  }
}

// Step 3 (after the spawner): 6:58 warning, 7:00 spawn. Each fires once per run.
export function stepBossSchedule(world) {
  const cfg = WAVES.boss
  if (!world.bossWarned && world.time >= cfg.atSec - cfg.warningSec) {
    world.bossWarned = true
    world.events.push({ type: 'bossWarning' })
  }
  if (!world.boss && world.time >= cfg.atSec) spawnBoss(world)
}

export function spawnBoss(world) {
  const def = ENEMIES[WAVES.boss.enemy]
  const e = world.enemies.acquire() // reserved slot: normal spawns stop at 200 of 202
  if (!e) {
    world.diag.dropped.enemies += 1 // pool full (03 §10), not a cap skip
    return null
  }
  const x = world.player.x
  const y = world.player.y + world.viewport.height / 2 + LIMITS.spawnMarginU + def.radius
  resetEnemy(e, {
    kind: WAVES.boss.enemy,
    x,
    y,
    r: def.radius,
    hp: world.ruleset === 'xianxia' ? scaleBossHp(def.hp) : def.hp,
    speed: def.moveSpeed,
    damage: world.ruleset === 'xianxia' ? scaleEnemyDamage(def.contactDamage, 0, 7) : def.contactDamage,
    xp: def.xp,
    kbRes: def.knockbackResist,
    behavior: 'boss',
  })
  if (isCourtyard(world)) Object.assign(e, courtyardSpawnPosition(world, e.x, e.y, e.r))
  world.bossEnemy = e
  world.boss = makeBossView(def)
  world.boss.maxHp = e.maxHp
  world.boss.spawnedAt = world.time
  syncBossView(world)
  world.events.push({ type: 'bossSpawn', x: e.x, y: e.y })
  return e
}

// Step 4 (after stepEnemyBehavior): enrage, skills, movement.
export function stepBoss(world, dt) {
  const e = world.bossEnemy
  if (!e) return
  const b = world.boss
  const def = ENEMIES[e.kind]
  const st = bossEnrageAt(def, world.time)
  if (st.stage !== b.enrageStage) applyEnrage(world, e, b, def, st)
  // Dew-ring slow from last step, cleared like other enemies (03 §3.4 step 4).
  const speed = e.speed * (1 - Math.max(e.slow, swordFormationSlow(world, e)))
  e.slow = 0
  const px = world.player.x
  const py = world.player.y
  const dx = px - e.x
  const dy = py - e.y
  const dist = Math.hypot(dx, dy) || 1
  const ux = dx / dist
  const uy = dy / dist

  // Summon 虫群.
  b.summonCd -= dt
  if (b.summonCd <= 0) {
    b.summonCd += def.summon.every * b.cooldownMul
    const n = world.spawner.spawnAround(world, def.summon.enemy, def.summon.count, e.x, e.y, def.summon.radius)
    world.events.push({ type: 'bossSummon', count: n })
  }

  // 浊雾泡环: ready after its cooldown, fires only while hp < hpBelow × maxHp.
  b.ringCd -= dt
  if (b.ringCd <= 0 && (b.ringIgnoresHp || e.hp < e.maxHp * def.bubbleRing.hpBelow)) {
    b.ringCd = def.bubbleRing.every * b.cooldownMul
    const n = def.bubbleRing.count
    for (let i = 0; i < n; i += 1) {
      const a = (TWO_PI * i) / n
      spawnBubble(world, e.x, e.y, e.x + Math.cos(a), e.y + Math.sin(a), b.bubble, e.kind)
    }
    world.events.push({ type: 'bossBubbleRing' })
  }

  // 贴近追击 (01 §9.2): hysteresis on centre distance, only judged while chasing.
  const ap = def.approach
  if (ap && !b.idleApproach && ap.idleSec) {
    const lastDamage = Math.max(b.spawnedAt, e.lastHitTime)
    if (world.time - lastDamage + STAGE_EPS >= ap.idleSec) b.idleApproach = true
  }
  if (!ap || (b.enrageStage < ap.fromStage && !b.idleApproach)) {
    b.approaching = false
  } else if (b.skill === 'chase') {
    if (!b.approaching && dist > ap.enterDist) {
      b.approaching = true
      world.events.push({ type: 'bossApproach' })
    } else if (b.approaching && dist <= ap.exitDist) {
      b.approaching = false
    }
  }

  // 雾壳冲撞 state machine: chase → windup (0.8 s, still) → charge (1 s, ×2.5) → chase.
  b.chargeCd -= dt
  let vx = 0
  let vy = 0
  if (b.approaching) {
    // No windup while approaching: the cooldown stays ready (clamped at 0) instead.
    b.chargeCd = Math.max(0, b.chargeCd)
    vx = ux * ap.speed
    vy = uy * ap.speed
  } else if (b.skill === 'windup') {
    b.skillLeft -= dt
    if (b.skillLeft <= 1e-9) {
      b.skill = 'charge'
      b.skillLeft = def.charge.duration
    }
  } else if (b.skill === 'charge') {
    vx = b.dirX * speed * def.charge.speedMul
    vy = b.dirY * speed * def.charge.speedMul
    b.skillLeft -= dt
    if (b.skillLeft <= 1e-9) {
      b.skill = 'chase'
      b.skillLeft = 0
    }
  } else if (b.chargeCd <= 0) {
    b.chargeCd += def.charge.every * b.cooldownMul
    b.skill = 'windup'
    b.skillLeft = def.charge.windup
    b.dirX = ux
    b.dirY = uy
    world.events.push({ type: 'bossCharge', dx: ux, dy: uy })
  } else {
    vx = ux * speed
    vy = uy * speed
  }
  e.x += vx * dt
  e.y += vy * dt
  e.vx = vx
  e.vy = vy
}

// Enrage stage at game time t (01 §9.2 超时兜底表). Pure: returns the active phase
// multipliers (later phase replaces earlier) plus the erosion-adjusted takenMul.
// stage = index of the active phase (1-based) + erosion layers that still change the
// multiplier (layers past takenMax add no stage).
const STAGE_EPS = 1e-6 // world.time accumulates DT; treat 659.9999999 as 11:00
export function bossEnrageAt(def, t) {
  const phases = def.enrage
  let phase = null
  let stage = 0
  for (let i = 0; i < phases.length; i += 1) {
    if (t + STAGE_EPS >= phases[i].atSec) {
      phase = phases[i]
      stage = i + 1
    }
  }
  const out = {
    stage,
    layers: 0,
    speedMul: phase ? phase.speedMul : 1,
    damageMul: phase ? phase.damageMul : 1,
    cooldownMul: phase && phase.cooldownMul ? phase.cooldownMul : 1,
    ringIgnoresHp: !!(phase && phase.ringIgnoresHp),
    takenMul: phase && phase.takenMul ? phase.takenMul : 1,
  }
  const er = def.erosion
  if (er && phase && t + STAGE_EPS >= er.fromSec) {
    const layers = Math.floor((t + STAGE_EPS - er.fromSec) / er.everySec) + 1
    const maxLayers = Math.ceil((er.takenMax - out.takenMul) / er.takenStep - 1e-9)
    out.layers = Math.min(layers, maxLayers)
    out.takenMul = Math.min(er.takenMax, out.takenMul + er.takenStep * out.layers)
    out.stage += out.layers
  }
  return out
}

function applyEnrage(world, e, b, def, st) {
  const prevCdMul = b.cooldownMul
  b.enrageStage = st.stage
  b.enraged = st.stage > 0
  b.speedMul = st.speedMul
  b.damageMul = st.damageMul
  b.cooldownMul = st.cooldownMul
  b.ringIgnoresHp = st.ringIgnoresHp
  b.takenMul = st.takenMul
  e.speed = def.moveSpeed * st.speedMul
  const contact = world.ruleset === 'xianxia' ? scaleEnemyDamage(def.contactDamage, 0, 7) : def.contactDamage
  e.damage = contact * st.damageMul
  e.takenMul = st.takenMul
  b.bubble.damage = def.bubbleRing.bubble.damage * st.damageMul
  // Shorter cooldowns take effect now: no running timer may exceed the new interval.
  if (st.cooldownMul < prevCdMul) {
    b.summonCd = Math.min(b.summonCd, def.summon.every * st.cooldownMul)
    b.chargeCd = Math.min(b.chargeCd, def.charge.every * st.cooldownMul)
    b.ringCd = Math.min(b.ringCd, def.bubbleRing.every * st.cooldownMul)
  }
  world.events.push({ type: 'bossEnrage', stage: st.stage, layers: st.layers, takenMul: st.takenMul })
}

// Copy the live entity into the read-only view (end of each step).
export function syncBossView(world) {
  const e = world.bossEnemy
  if (!e) return
  const b = world.boss
  b.x = e.x
  b.y = e.y
  b.hp = Math.max(0, e.hp)
  b.hpRatio = b.hp / e.maxHp
}

// Boss hp reached 0 (step 10): freeze the view as defeated and drop the entity ref.
export function defeatBoss(world) {
  const b = world.boss
  if (b) {
    syncBossView(world)
    b.hp = 0
    b.hpRatio = 0
    b.alive = false
    b.skill = 'defeated'
    b.skillLeft = 0
  }
  world.bossEnemy = null
}
