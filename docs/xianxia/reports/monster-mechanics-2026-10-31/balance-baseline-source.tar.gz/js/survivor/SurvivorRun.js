import { ensureSwordCombat, stepSwordEffects, clearSwordCombat } from '../xianxia/SwordCombat.js'
// Single-run entry point: state machine, fixed-step loop, system scheduling, event
// queue, result summary (03 §3.1–§3.4). Pure logic only: no Math.random (uses
// SurvivorRandom sub-streams), no Date.now, no cc/wx.
//
// States (03 §3.1): playing / levelup / paused / cleansing / extract / won / lost.
// Victory only comes from the Boss: Boss hp 0 → cleansing (1.5 s, player invulnerable,
// every enemy and mist bubble purified, no spores — 08 K4) → extract (sunlight point
// 250 away, no spawns, +5 hp per second) → standing inside for 2 s in a row → won
// (01 §9.3, §12). The S1 180 s timed victory is only a debug option:
// `new SurvivorRun({ debug: { timedWinSec: 180 } })` (08 K1, off by default).

import { SimClock, DT } from './SimClock.js'
import { SeededRandom } from './SurvivorRandom.js'
import { Pool } from './Pool.js'
import { SpatialGrid } from './SpatialGrid.js'
import { computeStats, incomingDamage } from './Stats.js'
import { CLASSES } from '../xianxia/Catalog.js'
import { normalizeEquipment, applyEquipmentStats } from '../xianxia/EquipmentCombat.js'
import { realmAt } from '../xianxia/Realms.js'
import { COURTYARD, isCourtyard, clampToCourtyard } from '../xianxia/Courtyard.js'
import { PILLS, takePill, expirePills, pillModifiers } from '../xianxia/Pills.js'
import { PLAYER } from './data/player.js'
import { WAVES } from './data/waves.js'
import { LIMITS } from './data/limits.js'
import { WEAPONS } from './data/weapons.js'
import { PASSIVES } from './data/passives.js'
import { validate } from './data/validate.js'
import { Spawner } from './Spawner.js'
import { makeEnemy } from './Enemies.js'
import { stepEnemyBehavior, stepSeparation } from './Enemies.js'
import { stepWeapons, cancelWanjian, cancelSwordSkills, initializeSwordEvolution } from './Weapons.js'
import { stepBossSchedule, stepBoss, syncBossView, defeatBoss } from './Boss.js'
import { makeShot, makeWeaponState } from './Weapons.js'
import { stepProjectiles, stepZones, makeZone, makeBubble, stepMistBubbles, prepareMistBubbleStep } from './Projectiles.js'
import { makeSpore, dropSpore, stepPickups, makeDrop, rollDrop, dropEliteLoot } from './Pickups.js'
import {
  CLASSIC_WEAPON_IDS, CLASSIC_PASSIVE_IDS,
  makeProgression,
  addXp,
  draftOffer,
  evolvableWeapon,
  eligibleEvolutions,
  xpToNext,
} from './Progression.js'

const PILL_IDS = Object.freeze(Object.keys(PILLS))

export class SurvivorDataError extends Error {
  constructor(errors) {
    super('SurvivorDataError: ' + errors.join('; '))
    this.name = 'SurvivorDataError'
    this.errors = errors
  }
}

function clampViewport(viewport) {
  const w = viewport && viewport.width
  const h = viewport && viewport.height
  if (!Number.isFinite(w) || !Number.isFinite(h)) {
    throw new RangeError('viewport.width/height must be finite numbers')
  }
  return {
    width: Math.min(1000, Math.max(320, w)),
    height: Math.min(1800, Math.max(480, h)),
  }
}

export class SurvivorRun {
  constructor(options = {}) {
    const errors = validate()
    if (errors.length) throw new SurvivorDataError(errors)

    if (typeof options.seed !== 'string' || options.seed.length === 0) {
      throw new TypeError('seed must be a non-empty string')
    }
    if (options.ruleset !== undefined && !['survivor', 'xianxia'].includes(options.ruleset)) throw new RangeError('Unknown ruleset')
    this.ruleset = options.ruleset || 'survivor'
    if (this.ruleset === 'xianxia' && options.arena === COURTYARD.id) this.arena = COURTYARD.id
    if (this.ruleset === 'xianxia' && options.equipment !== undefined) {
      Object.defineProperty(this, 'equipment', { value: normalizeEquipment(options.equipment), enumerable: true })
    }
    this.simulationTick = 0
    this.pillEndTicks = new Float64Array(3)
    this.pillTakenCounts = new Uint32Array(3)
    this.classPassive = null
    if (this.ruleset === 'xianxia') {
      this.skillRulesVersion = 'sword-s4'
      this.swordFacing = { x: 0, y: -1, hasMoved: false }
      this.weaponUpgradeMisses = 0
      this.newWeaponMisses = 0
      this.lastEvolutionOfferedId = null
    }
    this.appliedLevel = 1
    this.realm = realmAt(1)
    this.offerInfo = null
    this._offerSerial = 0
    this.seed = options.seed
    this.viewport = clampViewport(options.viewport || { width: 720, height: 1560 })
    this.bonuses = options.bonuses || {}
    this.firstRun = !!options.firstRun
    // 08 K1: debug-only timed victory (seconds); 0 = disabled (default).
    const debug = options.debug || {}
    this.timedWinSec = Number.isFinite(debug.timedWinSec) && debug.timedWinSec > 0 ? debug.timedWinSec : 0

    const rng = new SeededRandom(this.seed)
    this._spawnRng = rng.derive('spawn')
    this._draftRng = rng.derive('draft')
    this._combatRng = rng.derive('combat')
    if (this.ruleset === 'xianxia') ensureSwordCombat(this)
    this.weaponRng = rng.derive('weapon') // raindrop target / fallback picks (03 §3.3)
    this.dropRng = rng.derive('drop')     // 露珠 / 林风 掉落（01 §11，03 §3.3）

    this.clock = new SimClock()
    this.state = 'playing'
    this._prevState = 'playing'
    this.time = 0
    this.offer = null

    // Passive levels {id: level} in acquisition order (≤ PLAYER.passiveSlots).
    this.passives = {}

    // Derived stats (recomputed on open / level-up).
    this.stats = this._computeStats()

    // Player entity.
    this.player = {
      x: 0,
      y: 0,
      r: PLAYER.radius,
      hp: this.stats.maxHp,
      maxHp: this.stats.maxHp,
      invuln: 0,
      regenAcc: 0, // accumulates to 1s for regen ticks
      dirX: 0,
      dirY: -1,
    }
    this._inX = 0
    this._inY = 0

    // Pools (03 §7.3).
    this.enemies = new Pool(LIMITS.pools.enemies, makeEnemy)
    this.shots = new Pool(LIMITS.pools.playerProjectiles, makeShot)
    this.mistBubbles = new Pool(LIMITS.pools.mistBubbles, makeBubble) // enemy projectiles (01 §9)
    this.spores = new Pool(LIMITS.pools.spores, makeSpore)
    this.zones = new Pool(LIMITS.pools.raindropZones, makeZone) // raindrop shadows (01 §6.4)
    this.drops = new Pool(LIMITS.pools.pickups, makeDrop) // 露珠 / 大露珠 / 林风（01 §11）
    this.targetBuf = new Array(16) // 孢子风暴多目标（Weapons.nearestEnemies）

    // Spatial grid + reusable query buffer.
    this.grid = new SpatialGrid({ capacity: LIMITS.pools.enemies })
    this.queryBuf = new Int32Array(LIMITS.pools.enemies)
    this.hitBuf = new Array(LIMITS.pools.enemies) // area-weapon hit list (Weapons.js)
    this.weaponAngleBuf = new Float64Array(16)

    // Weapons (≤ PLAYER.weaponSlots, acquisition order): start with spore_shot Lv1.
    this.weapons = [makeWeaponState(this.ruleset === 'xianxia' ? CLASSES.sword.startWeapon : 'spore_shot', 1)]

    // Progression.
    this.progression = makeProgression()

    // Diagnostics (03 §3.1, §10; 08 L11): capSkipped = spawns skipped by the segment /
    // global hard cap (designed behaviour); dropped = pool full (should stay 0).
    // pickups: capSkipped = 露珠 / 林风 掉落时同类已达场上上限；dropped = 拾取物池满（01 §11）。
    this.diag = { capSkipped: { enemies: 0, pickups: 0 }, dropped: { enemies: 0, shots: 0, bubbles: 0, zones: 0, pickups: 0 }, droppedTime: 0 }

    // Event queue (one-shot events drained each frame).
    this.events = []

    // Boss + extraction (01 §9.2–§9.3). Read-only for the presentation layer:
    //   run.boss       — null until 7:00, then {x, y, r, hpRatio, alive, skill, dirX, dirY, enraged, …}
    //   run.extraction — null until extract, then {x, y, r, progress (0..1), heldSec}
    this.boss = null
    this.bossEnemy = null // live pool entity (reserved slot), null once defeated
    this.bossWarned = false
    this.extraction = null
    this._phaseSteps = 0  // cleansing: steps left
    this._healAcc = 0     // extract: per-second heal accumulator

    // Summary bookkeeping.
    this.purified = 0
    this._eliteDefeated = 0 // 精英被击败次数（01 §13.1 露晶精英奖励；cleansing 净化不算）
    this._bossDefeated = false
    this._killer = ''
    this._outcome = ''

    // Spawner.
    this.spawner = new Spawner(this.viewport, LIMITS.spawnMarginU, this._spawnRng)

    // Expose world refs so systems read a single object.
    this.world = this
  }

  _computeStats() {
    return applyEquipmentStats(this, computeStats(PLAYER, this.bonuses, this.passives, { ruleset: this.ruleset, level: this.appliedLevel, pillModifiers: pillModifiers(this) }))
  }

  // --- input ---
  setInput(x, y) {
    const vx = Number.isFinite(x) ? x : 0
    const vy = Number.isFinite(y) ? y : 0
    let mag = Math.hypot(vx, vy)
    if (mag > 1) {
      this._inX = vx / mag
      this._inY = vy / mag
    } else {
      this._inX = vx
      this._inY = vy
    }
    if (mag > 0.0001) {
      const dmag = Math.hypot(this._inX, this._inY) || 1
      this.player.dirX = this._inX / dmag
      this.player.dirY = this._inY / dmag
    }
  }

  // --- fixed-step driver ---
  // States in which the simulation advances (03 §3.1).
  get simulating() {
    return this.state === 'playing' || this.state === 'cleansing' || this.state === 'extract'
  }

  advance(frameDt) {
    if (!this.simulating) return 0
    const steps = this.clock.advance(frameDt)
    this.diag.droppedTime = this.clock.droppedTime
    let run = 0
    for (let i = 0; i < steps; i += 1) {
      if (!this.simulating) break
      this.step()
      run += 1
    }
    return run
  }

  // One fixed step (03 §3.4). Advances in 'playing', 'cleansing' and 'extract'.
  step() {
    if (this.simulating) {
      this.simulationTick += 1
      if (this.ruleset === 'xianxia') {
        for (const id of PILL_IDS) {
          const end = this.pillEndTicks[PILLS[id].index]
          if (end > 0 && this.simulationTick >= end) this.events.push({ type: 'pillExpired', id })
        }
      }
      if (this.ruleset === 'xianxia' && expirePills(this)) {
        this.stats = this._computeStats()
      }
    }
    if (this.state === 'cleansing' || this.state === 'extract') {
      this._stepAfterBoss(DT)
      return
    }
    if (this.state !== 'playing') return
    const dt = DT
    this._stepInput(dt)        // 1 input
    this._stepPlayer(dt)       // 2 player
    prepareMistBubbleStep(this, dt) // allow expiry-only reclamation if firing needs a full pool's slot
    this.spawner.step(this, dt) // 3 spawner
    stepBossSchedule(this)     // 3 Boss warning / spawn
    stepEnemyBehavior(this, dt) // 4 enemies
    stepBoss(this, dt)         // 4 Boss skills + movement
    this._clampCourtyardEnemies()
    this.grid.build(this.enemies.active, this.enemies.count, this.player) // 5 grid
    stepSeparation(this)       // 6 separation
    if (isCourtyard(this)) {
      this._clampCourtyardEnemies()
      // Separation can cross cell boundaries; combat must query final positions.
      this.grid.build(this.enemies.active, this.enemies.count, this.player)
    }
    stepWeapons(this, dt)      // 7 weapons
    stepProjectiles(this, dt)  // 8 projectiles
    stepZones(this)            // 8 raindrop zones
    this._stepHostile(dt)      // 9 hostile (mist bubbles, contact damage)
    stepSwordEffects(this)    // secondary sword effects, before enemy pool recycling
    this._stepDeaths()         // 10 deaths
    this._stepPickups(dt)      // 11 pickups → maybe levelup
    this._stepPhase(dt)        // 12 phase (win/lose, time += DT)
    syncBossView(this)
  }

  _clampCourtyardEnemies() {
    if (!isCourtyard(this)) return
    for (let i = 0; i < this.enemies.count; i += 1) clampToCourtyard(this.enemies.active[i])
  }

  _clampCourtyardLoot() {
    if (!isCourtyard(this)) return
    for (const pool of [this.spores, this.drops]) {
      for (let i = 0; i < pool.count; i += 1) {
        const e = pool.active[i]
        // A player center must be able to reach loot even at a diagonal corner.
        const at = clampToCourtyard({ x: e.x, y: e.y, r: Math.max(this.player.r, e.r || 0) })
        e.x = at.x
        e.y = at.y
      }
    }
  }

  // cleansing / extract step: no spawns, no enemies, no pickups (so no level-up can
  // interrupt the ending). The player still moves and weapons keep orbiting the player.
  _stepAfterBoss(dt) {
    if (!(this.ruleset === 'xianxia' && this.state === 'cleansing')) this._stepInput(dt)
    this._stepPlayer(dt)
    this.grid.build(this.enemies.active, this.enemies.count, this.player)
    if (!(this.ruleset === 'xianxia' && this.state === 'cleansing')) {
      stepWeapons(this, dt)
      stepProjectiles(this, dt)
      stepZones(this)
    }
    const cfg = WAVES.extraction
    if (this.state === 'cleansing') {
      this._phaseSteps -= 1
      if (this._phaseSteps <= 0) this._openExtraction()
    } else {
      // 每秒回复（01 §9.3 第 5 条），满血时不发 heal 事件。
      this._healAcc += dt
      if (this._healAcc >= 1 - 1e-9) {
        this._healAcc -= 1
        if (this.player.hp < this.player.maxHp) {
          this.player.hp = Math.min(this.player.maxHp, this.player.hp + cfg.healPerSec)
          this.events.push({ type: 'heal', amount: cfg.healPerSec })
        }
      }
      // Stand inside for holdSec in a row; stepping out resets the progress.
      const x = this.extraction
      const dx = this.player.x - x.x
      const dy = this.player.y - x.y
      if (dx * dx + dy * dy <= x.r * x.r) x._steps += 1
      else x._steps = 0
      x.heldSec = x._steps * DT
      x.progress = Math.min(1, x._steps / x._need)
    }
    this.time += DT
    if (this.state === 'extract' && this.extraction._steps >= this.extraction._need) this._win()
  }

  // Boss defeated (step 10): 1.5 s cleansing, player invulnerable, purify the field.
  _enterCleansing() {
    if (this.ruleset === 'xianxia') { cancelWanjian(this); cancelSwordSkills(this); clearSwordCombat(this) }
    const cfg = WAVES.extraction
    this.state = 'cleansing'
    this._phaseSteps = Math.round(cfg.cleansingSec / DT)
    this.player.invuln = Math.max(this.player.invuln, cfg.cleansingSec)
    this.events.push({ type: 'cleansing' })
    // 08 K4: every remaining enemy is purified (counted) but drops no spores.
    const enemies = this.enemies
    for (let i = enemies.count - 1; i >= 0; i -= 1) {
      const e = enemies.active[i]
      this.purified += 1
      this.events.push({ type: 'purified', kind: e.kind, x: e.x, y: e.y })
      enemies.release(e)
    }
    this.mistBubbles.releaseAll()
    this.shots.releaseAll()
    this.zones.releaseAll()
  }

  // Cleansing over: open the sunlight extraction point 250 away in a random direction.
  _openExtraction() {
    const cfg = WAVES.extraction
    const a = this._spawnRng.next() * Math.PI * 2
    const x = this.player.x + Math.cos(a) * cfg.distance
    const y = this.player.y + Math.sin(a) * cfg.distance
    this.extraction = { x, y, r: cfg.radius, progress: 0, heldSec: 0, _steps: 0, _need: Math.round(cfg.holdSec / DT) }
    if (isCourtyard(this)) clampToCourtyard(this.extraction)
    this._healAcc = 0
    this.state = 'extract'
    this.events.push({ type: 'extractionOpen', x: this.extraction.x, y: this.extraction.y })
  }

  _stepInput() {
    if (this.swordFacing && (this._inX || this._inY)) {
      this.swordFacing = { x: this._inX, y: this._inY, hasMoved: true }
    }
    const speed = this.stats.moveSpeed
    this.player.x += this._inX * speed * DT
    this.player.y += this._inY * speed * DT
    if (isCourtyard(this)) clampToCourtyard(this.player)
  }

  _stepPlayer(dt) {
    if (isCourtyard(this)) clampToCourtyard(this.player)
    if (this.player.invuln > 0) this.player.invuln -= dt
    // Regen settles once per second (01 §15.1).
    if (this.stats.regenPerSec > 0 && this.player.hp < this.player.maxHp) {
      this.player.regenAcc += dt
      if (this.player.regenAcc >= 1) {
        this.player.regenAcc -= 1
        this.player.hp = Math.min(this.player.maxHp, this.player.hp + this.stats.regenPerSec)
        this.events.push({ type: 'heal', amount: this.stats.regenPerSec })
      }
    }
  }

  // Step 9: mist bubbles move + hit the player, then enemy contact damage (query grid
  // around the player). Both respect the shared invulnerability window.
  _stepHostile(dt) {
    const hpBefore = this.player.hp
    const bubbleSource = stepMistBubbles(this, dt, PLAYER.invulnTime)
    if (bubbleSource) {
      this._killer = 'mist_bubble'
      this.events.push({ type: 'playerHurt', ...(this.ruleset === 'xianxia' ? {
        sourceKind:'mist_bubble',attackerKind:bubbleSource,hpBefore,hpAfter:this.player.hp,
        amount:hpBefore-this.player.hp,effectiveAmount:Math.min(hpBefore,hpBefore-this.player.hp),
        tick:this.simulationTick,
      } : {}) })
    }
    if (this.player.invuln > 0) return
    const n = this.grid.queryCircle(this.player.x, this.player.y, this.player.r, this.queryBuf)
    for (let k = 0; k < n; k += 1) {
      const e = this.enemies.items[this.queryBuf[k]]
      if (!this.enemies.isActive(e) || e.hp <= 0) continue
      if (this._contact(e)) return // one hit per invuln window
    }
    // Large entities (the Boss) live outside the grid (03 §3.6).
    const large = this.grid.large
    for (let k = 0; k < large.length; k += 1) {
      const e = large[k]
      if (!this.enemies.isActive(e) || e.hp <= 0) continue
      if (this._contact(e)) return
    }
  }

  // Contact test + damage for one enemy; returns true when it hurt the player.
  _contact(e) {
    const rr = this.player.r + e.r
    const dx = e.x - this.player.x
    const dy = e.y - this.player.y
    // Separation places enemies exactly at tangency; diagonal normalisation can
    // leave a tiny positive squared-distance error. Do not turn that into immunity.
    if (dx * dx + dy * dy > rr * rr + 1e-7) return false
    const hpBefore = this.player.hp
    this.player.hp -= incomingDamage(e.damage, this.ruleset, this.stats.damageTakenMul)
    this.player.invuln = PLAYER.invulnTime
    this._killer = e.kind
    this.events.push({ type: 'playerHurt', ...(this.ruleset === 'xianxia' ? {
      sourceKind:e.kind,attackerKind:e.kind,sourceUid:e.uid,hpBefore,hpAfter:this.player.hp,
      amount:hpBefore-this.player.hp,effectiveAmount:Math.min(hpBefore,hpBefore-this.player.hp),
      tick:this.simulationTick,
    } : {}) })
    return true
  }

  // Step 10: resolve deaths (hp ≤ 0) → purify event, spore drop, counter. The Boss
  // reaching 0 starts the cleansing phase (01 §9.3). Normal enemies roll for 露珠 / 林风;
  // the elite drops its 50 xp spore + 大露珠 + 林风 (01 §11, S3 B3/B4).
  _stepDeaths() {
    const enemies = this.enemies
    let bossDown = false
    for (let i = enemies.count - 1; i >= 0; i -= 1) {
      const e = enemies.active[i]
      if (e.hp > 0) continue
      if (isCourtyard(this)) clampToCourtyard(e)
      this.purified += 1
      this.events.push({ type: 'purified', kind: e.kind, x: e.x, y: e.y })
      if (e === this.bossEnemy) {
        bossDown = true
        defeatBoss(this)
      } else {
        if (e.xp > 0) dropSpore(this, e.x, e.y, e.xp)
        if (e.behavior === 'charge') {
          this._eliteDefeated += 1
          dropEliteLoot(this, e.x, e.y)
          this.events.push({ type: 'eliteDefeated', x: e.x, y: e.y })
        } else {
          rollDrop(this, e.x, e.y)
        }
      }
      this.swordCombat?.marks.delete(e.uid)
      enemies.release(e)
    }
    this._clampCourtyardLoot()
    if (bossDown) {
      this._bossDefeated = true
      this.events.push({ type: 'bossDefeated' })
      if (this.state === 'playing' && this.player.hp > 0) this._enterCleansing()
    }
  }

  // Step 11: pickups → xp → maybe enqueue level-ups → enter levelup state.
  _stepPickups(dt) {
    if (this.ruleset === 'xianxia' && (this.player.hp <= 0 || this.state !== 'playing')) return
    this._clampCourtyardLoot()
    const gained = stepPickups(this, dt)
    this._clampCourtyardLoot()
    if (gained > 0) {
      const levels = addXp(this.progression, gained)
      if (levels > 0) {
        this.events.push({ type: 'levelUp', level: this.progression.level })
      }
    }
    if (this.progression.pendingLevels > 0 && this.state === 'playing') {
      this._enterLevelup()
    }
  }

  // Step 12: phase — death, advance time, debug-only timed victory (08 K1).
  _stepPhase() {
    if (this.player.hp <= 0) {
      this.player.hp = 0
      this._lose()
      return
    }
    this.time += DT
    if (this.state === 'playing' && this.timedWinSec > 0 && this.time >= this.timedWinSec) {
      this._win()
    }
  }

  // --- level-up ---
  _enterLevelup() {
    if (this.state === 'levelup' && this.offer) return
    this.state = 'levelup'
    this.progression.totalLevelUps += 1
    const isFirst = this.progression.totalLevelUps === 1
    this.offer = draftOffer(
      {
        weapons: this.weapons,
        passives: this.passives,
        weaponSlots: PLAYER.weaponSlots,
        passiveSlots: PLAYER.passiveSlots,
        isFirstLevelUp: isFirst,
        timeSec: this.time,
        ruleset: this.ruleset,
        classPassive: this.classPassive,
        weaponUpgradeMisses: this.weaponUpgradeMisses || 0,
        newWeaponMisses: this.newWeaponMisses || 0,
        lastEvolutionOfferedId: this.lastEvolutionOfferedId,
        appliedLevel: this.appliedLevel,
        targetLevel: this.appliedLevel + 1,
        breakthrough: this.appliedLevel + 1 === 10 || this.appliedLevel + 1 === 19,
      },
      this._draftRng,
    )
    if (this.ruleset === 'xianxia') {
      const hasUpgrade = this.offer.some(c => c.kind === 'weapon' && this.weapons.some(w => w.id === c.id && c.level === w.level + 1))
      this.weaponUpgradeMisses = hasUpgrade ? 0 : this.weaponUpgradeMisses + 1
      const stageIds = ['sj_line', 'sj_shadow', 'sj_formation']
      const hasStageRoom = this.appliedLevel + 1 >= 10 && this.weapons.length < PLAYER.weaponSlots &&
        stageIds.some(id => !this.weapons.some(w => w.id === id))
      const offeredNew = this.offer.some(c => c.kind === 'weapon' && c.isNew && stageIds.includes(c.id))
      this.newWeaponMisses = hasStageRoom && !offeredNew ? this.newWeaponMisses + 1 : 0
      const evolution = this.offer.find(c => c.kind === 'evolve')
      if (evolution) this.lastEvolutionOfferedId = evolution.id
    }
    const targetLevel = this.appliedLevel + 1
    this.offerInfo = Object.freeze({ id: ++this._offerSerial, targetLevel, breakthrough: this.ruleset === 'xianxia' && (targetLevel === 10 || targetLevel === 19) })
    this.events.push({ type: 'levelUpOffer', cards: this.offer.map((c) => c.id) })
  }

  choose(i, expectedOfferId) {
    if (this.state !== 'levelup' || !this.offer) return false
    if (expectedOfferId !== undefined && expectedOfferId !== this.offerInfo?.id) return false
    if (this.ruleset === 'xianxia' && this.player.hp <= 0) return false
    if (!Number.isInteger(i) || i < 0 || i >= this.offer.length) return false
    const card = this.offer[i]
    if (!this._canApplyCard(card)) return false
    this._applyCard(card)
    this.appliedLevel += 1
    this.realm = realmAt(this.appliedLevel)
    if (this.ruleset === 'xianxia') this._commitRealm(this.offerInfo.breakthrough)
    this.events.push({ type: 'levelUpPick', picked: card.id })
    this.progression.pendingLevels -= 1
    this.offer = null
    this.offerInfo = null
    if (this.progression.pendingLevels > 0) {
      // Another queued level-up pops immediately.
      this._enterLevelup()
    } else {
      this.state = 'playing'
    }
    return true
  }

  // Validate before mutating inventory or consuming a queued level.
  _canApplyCard(card) {
    if (!card) return false
    if (card.kind === 'weapon') {
      const pool = this.ruleset === 'xianxia' ? CLASSES.sword.weaponPool : CLASSIC_WEAPON_IDS
      if (!pool.includes(card.id)) return false
      const def = WEAPONS[card.id]
      const w = this.weapons.find((x) => x.id === card.id)
      if (this.ruleset === 'xianxia' && ['sj_line','sj_shadow','sj_formation'].includes(card.id) && !w && this.appliedLevel + 1 < 10) return false
      return !!def && (w
        ? !w.evolved && w.level < def.levels.length && card.level === w.level + 1
        : this.weapons.length < PLAYER.weaponSlots && card.level === 1)
    }
    if (card.kind === 'classPassive') return false
    if (card.kind === 'pill') return this.ruleset === 'xianxia' && this.appliedLevel + 1 >= 5 && Object.hasOwn(PILLS, card.id)
    if (card.kind === 'passive') {
      const pool = this.ruleset === 'xianxia' ? CLASSES.sword.passivePool : CLASSIC_PASSIVE_IDS
      if (!pool.includes(card.id)) return false
      const def = PASSIVES[card.id]
      const current = this.passives[card.id] || 0
      if (this.ruleset === 'xianxia' && card.id === 'sj_gate' && !current && this.appliedLevel + 1 < 10) return false
      return !!def && card.level === current + 1 && current < def.levels.length &&
        (current > 0 || Object.keys(this.passives).length < PLAYER.passiveSlots)
    }
    if (card.kind === 'evolve') return this.ruleset === 'xianxia'
      ? eligibleEvolutions(this._evolutionDraftState()).some(w => w.id === card.id) &&
        card.level === WEAPONS[card.id].levels.length + 1 && card.evolution === WEAPONS[card.id].evolution
      : evolvableWeapon(this.weapons, this.passives, this.time, this.classPassive)?.id === card.id
    if (card.kind === 'heal') return Number.isFinite(card.amount) && card.amount > 0
    return card.kind === 'crystal' && card.id === 'shiny_spore'
  }

  _commitRealm(breakthrough) {
    const oldMax = this.player.maxHp
    this.stats = this._computeStats()
    this.player.maxHp = this.stats.maxHp
    this.player.hp = breakthrough ? this.player.maxHp : Math.min(this.player.maxHp, this.player.hp + Math.max(0, this.player.maxHp - oldMax))
    if (!breakthrough) return
    this.player.invuln = Math.max(this.player.invuln, 1.5)
    for (let i = 0; i < this.enemies.count; i += 1) {
      const e = this.enemies.active[i]
      const dx = e.x - this.player.x, dy = e.y - this.player.y
      const distance = Math.hypot(dx, dy)
      if (e.hp <= 0 || distance > 220) continue
      const shift = 80 * (1 - Math.min(1, Math.max(0, e.kbRes || 0)))
      e.kbX += (distance ? dx / distance : 1) * shift
      e.kbY += (distance ? dy / distance : 0) * shift
    }
    this.events.push({ type: 'breakthrough', level: this.appliedLevel, realm: this.realm.key })
  }

  _evolutionDraftState() {
    return { ruleset: this.ruleset, weapons: this.weapons, passives: this.passives,
      appliedLevel: this.appliedLevel, timeSec: this.time }
  }

  _applyCard(card) {
    if (card.kind === 'classPassive') {
      this.classPassive.level = card.level
      this.events.push({ type: 'classPassiveUp', id: card.id, level: card.level })
      return
    }
    if (card.kind === 'pill') {
      const refreshed = this.pillEndTicks[PILLS[card.id].index] > this.simulationTick
      if (takePill(this, card.id)) this.events.push({ type: 'pillTaken', id: card.id, refreshed })
      return
    }
    if (card.kind === 'weapon') {
      const def = WEAPONS[card.id]
      if (!def || def.levels.length === 0) return
      const w = this.weapons.find((x) => x.id === card.id)
      if (w) {
        if (w.level < def.levels.length) w.level = Math.min(def.levels.length, card.level)
      } else if (this.weapons.length < PLAYER.weaponSlots) {
        this.weapons.push(makeWeaponState(card.id, 1))
      }
    } else if (card.kind === 'evolve') {
      // 01 §8.3：只在条件仍满足时进化；占原栏位、被动保留，进化后不再升级。
      const w = this.ruleset === 'xianxia'
        ? eligibleEvolutions(this._evolutionDraftState()).find(w => w.id === card.id)
        : evolvableWeapon(this.weapons, this.passives, this.time, this.classPassive)
      if (!w || w.id !== card.id) return
      w.evolved = true
      w.level = WEAPONS[w.id].levels.length
      if (this.ruleset === 'xianxia') initializeSwordEvolution(this, w)
      this.events.push({ type: 'evolved', id: w.id })
    } else if (card.kind === 'passive') {
      const def = PASSIVES[card.id]
      if (!def) return
      const cur = this.passives[card.id] || 0
      if (cur === 0 && Object.keys(this.passives).length >= PLAYER.passiveSlots) return
      if (cur < def.levels.length) this.passives[card.id] = Math.min(def.levels.length, cur + 1)
      this.stats = this._computeStats()
    } else if (card.kind === 'heal') {
      this.player.hp = Math.min(this.player.maxHp, this.player.hp + card.amount)
    } else if (card.kind === 'crystal') {
      // Meta.crystalsForRun multiplies the selected-card count by five.
      this._shinyCards = (this._shinyCards || 0) + 1
    }
  }

  // --- pause / resume / abandon ---
  pause() {
    if (this.simulating || this.state === 'levelup') {
      this._prevState = this.state
      this.state = 'paused'
      return true
    }
    return false
  }

  resume() {
    if (this.state !== 'paused') return false
    this.state = this._prevState
    return true
  }

  abandon() {
    if (this.state !== 'paused') return false
    if (this.ruleset === 'xianxia') { cancelWanjian(this); cancelSwordSkills(this); clearSwordCombat(this) }
    this._outcome = 'lost'
    this._abandoned = true
    this.state = 'lost'
    this.events.push({ type: 'lost' })
    return true
  }

  _win() {
    if (this.ruleset === 'xianxia') { cancelWanjian(this); cancelSwordSkills(this); clearSwordCombat(this) }
    this._outcome = 'won'
    this.state = 'won'
    this.events.push({ type: 'won' })
  }

  _lose() {
    if (this.ruleset === 'xianxia') { cancelWanjian(this); cancelSwordSkills(this); clearSwordCombat(this) }
    this._outcome = 'lost'
    this.state = 'lost'
    this.events.push({ type: 'lost' })
  }

  // --- events ---
  drainEvents() {
    const out = this.events
    this.events = []
    return out
  }

  // --- summary (03 §3.1) ---
  summary() {
    return {
      outcome: this._outcome || (this.state === 'won' ? 'won' : this.state === 'lost' ? 'lost' : ''),
      survivalSec: this.time,
      purified: this.purified,
      level: this.progression.level,
      weapons: this.weapons.map((w) => ({ id: w.id, level: w.level, evolved: !!w.evolved })),
      passives: Object.keys(this.passives).map((id) => ({ id, level: this.passives[id] })),
      eliteDefeated: this._eliteDefeated,
      bossDefeated: this._bossDefeated,
      shinyCards: this._shinyCards || 0,
      abandoned: !!this._abandoned,
      ...(this.ruleset === 'xianxia' ? { skillRulesVersion: this.skillRulesVersion, classPassive: null, pills: Object.keys(PILLS).map(id => ({ id, count: this.pillTakenCounts[PILLS[id].index] })) } : {}),
      ...(this.equipment ? { equipment: this.equipment } : {}),
      killer: this._outcome === 'won' ? '' : this._killer,
    }
  }
}

export { xpToNext }
