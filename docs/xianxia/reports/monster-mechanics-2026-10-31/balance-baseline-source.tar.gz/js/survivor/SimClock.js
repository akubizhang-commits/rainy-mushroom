// Fixed-step accumulator (03 §3.2). Pure logic only: no Math.random, no Date.now.
//
// - Step length DT = 1/60 s.
// - advance(frameDt) adds real time to an accumulator and returns how many whole
//   steps are due this frame, capped at `maxSteps` (default 5 ≈ 83 ms). Time beyond
//   the cap is discarded (not carried over) and added to `droppedTime`, so a stutter
//   never snowballs into an ever-growing catch-up.
// - A non-finite or negative frameDt is treated as 0 (03 §3.2, §11).

export const DT = 1 / 60

export class SimClock {
  constructor(options = {}) {
    this.dt = options.dt || DT
    this.maxSteps = options.maxSteps || 5
    this.accumulator = 0
    this.droppedTime = 0
  }

  // Returns the number of fixed steps the caller should run this frame.
  advance(frameDt) {
    const safeDt = Number.isFinite(frameDt) && frameDt > 0 ? frameDt : 0
    this.accumulator += safeDt
    let steps = Math.floor(this.accumulator / this.dt)
    this.accumulator -= steps * this.dt
    if (steps > this.maxSteps) {
      // Discard the excess instead of carrying it forward.
      this.droppedTime += (steps - this.maxSteps) * this.dt
      steps = this.maxSteps
    }
    return steps
  }

  reset() {
    this.accumulator = 0
    this.droppedTime = 0
  }
}
