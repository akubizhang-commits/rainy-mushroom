// Player projectile system (03 §3.4 step 8). Pure logic only: no Math.random,
// no Date.now, no cc/wx.
//
// Each spore shot moves in a straight line, queries the enemy grid, applies damage once
// per enemy (tracked by uid so a reused slot is never double-counted), and ends when it
// has pierced its budget of enemies or its lifetime expires. Leaf shots (kind 'leaf',
// leaf_boomerang) pierce without limit, fly out and home back to the player, hitting
// each enemy once per leg. Raindrop zones resolve in stepZones. Player shots never test
// against mistBubbles (裁决 L4 — S1 has none anyway).
//
// Damage is only marked here (sets enemy.hp and enemy.lastHitTime); deaths are
// resolved together in SurvivorRun step 10 so one step's hits drop loot once.

import { makeShot, makeZone, enemiesInCircle } from './Weapons.js'
import { hitDamage, incomingDamage } from './Stats.js'
import { WAVES } from './data/waves.js'
import { applySwordHit } from '../xianxia/SwordCombat.js'
import { equipmentDamage } from '../xianxia/EquipmentCombat.js'
import { scaleEnemyDamage } from '../xianxia/Realms.js'

// Advance every active shot by dt. `world` provides: shots (Pool), enemies (Pool),
// grid (SpatialGrid), queryBuf (Int32Array), time.
export function stepProjectiles(world, dt) {
  const shots = world.shots
  const enemies = world.enemies
  const grid = world.grid
  const buf = world.queryBuf
  // Pooled active-array order changes after release. Sword RNG must follow UID,
  // not storage order, so collect a stable snapshot before any swap-removal.
  const ordered = world._swordShotOrder || (world._swordShotOrder = [])
  ordered.length = 0
  for (let i = 0; i < shots.count; i++) if (shots.active[i].kind === 'sword') ordered.push(shots.active[i])
  ordered.sort((a,b) => a.uid - b.uid)
  for (const shot of ordered) stepSwordProjectile(world, shot, dt)
  ordered.length = 0
  // Iterate backwards because release() swap-removes into the current index.
  for (let i = shots.count - 1; i >= 0; i -= 1) {
    const shot = shots.active[i]
    if (shot.kind === 'sword') continue
    const leaf = shot.kind === 'leaf'
    if (leaf) {
      if (moveLeaf(shot, world.player, dt)) {
        shots.release(shot) // back at the player → recycled (01 §6.5)
        continue
      }
    } else {
      shot.x += shot.vx * dt
      shot.y += shot.vy * dt
    }
    shot.life -= dt
    if (shot.life <= 0) {
      shots.release(shot)
      continue
    }
    // Broad-phase: candidate enemy slots near the shot.
    const n = grid.queryCircle(shot.x, shot.y, shot.r, buf)
    let ended = false
    for (let k = 0; k < n && !ended; k += 1) {
      const enemy = enemies.items[buf[k]]
      if (!enemies.isActive(enemy) || enemy.hp <= 0) continue
      if (hasHit(shot, enemy.uid)) continue
      const rr = shot.r + enemy.r
      const dx = enemy.x - shot.x
      const dy = enemy.y - shot.y
      if (dx * dx + dy * dy > rr * rr) continue
      // Mark damage + knockback; death is resolved in step 10.
      applyHit(enemy, shot, world)
      rememberHit(shot, enemy.uid)
      if (leaf) continue // 无限穿透
      shot.pierceLeft -= 1
      if (shot.pierceLeft <= 0) {
        shots.release(shot)
        ended = true
      }
    }
    // Also test the `large` list (the Boss lives there, 03 §3.6).
    if (!ended) {
      const large = grid.large
      for (let k = 0; k < large.length && !ended; k += 1) {
        const enemy = large[k]
        if (!enemies.isActive(enemy) || enemy.hp <= 0) continue
        if (hasHit(shot, enemy.uid)) continue
        const rr = shot.r + enemy.r
        const dx = enemy.x - shot.x
        const dy = enemy.y - shot.y
        if (dx * dx + dy * dy > rr * rr) continue
        applyHit(enemy, shot, world)
        rememberHit(shot, enemy.uid)
        if (leaf) continue
        shot.pierceLeft -= 1
        if (shot.pierceLeft <= 0) {
          shots.release(shot)
          ended = true
        }
      }
    }
  }
}

// Sweep the final, range-clamped segment too. Sorting entry times prevents pool
// swap-removal order from deciding which opponent consumes a sword's pierce.
function stepSwordProjectile(world, shot, dt) {
  const elapsed = Math.min(dt, Math.max(0, shot.life))
  const dx = shot.vx * elapsed, dy = shot.vy * elapsed
  const length2 = dx * dx + dy * dy
  const candidates = []
  for (let i = 0; i < world.enemies.count; i += 1) {
    const enemy = world.enemies.active[i]
    if (enemy.hp <= 0 || hasHit(shot, enemy.uid)) continue
    const ox = shot.x - enemy.x, oy = shot.y - enemy.y
    const rr = shot.r + enemy.r
    const c = ox * ox + oy * oy - rr * rr
    let entry = 0
    if (c > 0) {
      if (length2 === 0) continue
      const b = ox * dx + oy * dy
      const disc = b * b - length2 * c
      if (disc < 0) continue
      entry = (-b - Math.sqrt(disc)) / length2
      if (entry < 0 || entry > 1) continue
    }
    candidates.push({ enemy, entry })
  }
  candidates.sort((a, b) => a.entry - b.entry || a.enemy.uid - b.enemy.uid)
  shot.x += dx
  shot.y += dy
  shot.life -= elapsed
  for (const { enemy } of candidates) {
    applyHit(enemy, shot, world)
    world.events.push({ type: 'swordHit', x: enemy.x, y: enemy.y, dirX: shot.vx, dirY: shot.vy, tick: world.simulationTick })
    rememberHit(shot, enemy.uid)
    shot.pierceLeft -= 1
    if (shot.pierceLeft <= 0) break
  }
  if (shot.pierceLeft <= 0 || shot.life <= 1e-9) world.shots.release(shot)
}

// Leaf boomerang flight (01 §6.5). Out leg: straight along its launch direction until
// `travelLeft` is used up, then it turns back and forgets its out-leg hits (去程、回程
// 对同一敌人各结算一次). Back leg: homes on the player's *current* position each step.
// Returns true when the leaf has reached the player and must be recycled.
function moveLeaf(shot, player, dt) {
  if (!shot.returning) {
    shot.x += shot.vx * dt
    shot.y += shot.vy * dt
    shot.travelLeft -= shot.speed * dt
    if (shot.travelLeft <= 0) {
      shot.returning = true
      shot.hitUids.length = 0
    }
    return false
  }
  const dx = player.x - shot.x
  const dy = player.y - shot.y
  const d = Math.hypot(dx, dy)
  if (d <= shot.catchR) return true
  const step = Math.min(shot.speed * dt, d)
  shot.vx = (dx / d) * shot.speed
  shot.vy = (dy / d) * shot.speed
  shot.x += (dx / d) * step
  shot.y += (dy / d) * step
  return false
}

function applyHit(enemy, shot, world) {
  if (world.ruleset === 'xianxia' && shot.sourceId === 'sj_yujian') {
    applySwordHit(world, enemy, shot.raw, shot.sourceId, shot.castId || 0)
  } else enemy.hp -= equipmentDamage(world, enemy, hitDamage(enemy, shot.damage, shot.raw), shot.sourceId)
  enemy.lastHitTime = world.time
  const push = shot.knockback * (1 - enemy.kbRes)
  if (!(push > 0)) return
  if (shot.kind === 'leaf') {
    // 01 §6 通用击退：沿“角色→敌人”方向（回程也向外推，不把敌人拽向角色）。
    const dx = enemy.x - world.player.x
    const dy = enemy.y - world.player.y
    const d = Math.hypot(dx, dy) || 1
    enemy.kbX += (dx / d) * push
    enemy.kbY += (dy / d) * push
    return
  }
  // Spore shot: knockback along the shot's travel direction, reduced by resistance.
  const speed = Math.hypot(shot.vx, shot.vy) || 1
  enemy.kbX += (shot.vx / speed) * push
  enemy.kbY += (shot.vy / speed) * push
}

// Raindrop zones (01 §6.4, 03 §3.4 step 8): a zone resolves once world.time reaches
// `at` (0.4 s after the shadow appeared), damaging every enemy within its radius at the
// locked landing point, then returns to the pool. Knockback along 角色→敌人 (01 §6).
export function stepZones(world) {
  const zones = world.zones
  const t = world.time
  for (let i = zones.count - 1; i >= 0; i -= 1) {
    const z = zones.active[i]
    if (t + 1e-9 < z.at) continue
    const m = enemiesInCircle(world, z.x, z.y, z.r)
    for (let k = 0; k < m; k += 1) {
      const e = world.hitBuf[k]
      e.hp -= equipmentDamage(world, e, hitDamage(e, z.damage, z.raw), z.sourceId)
      e.lastHitTime = t
      const push = z.knockback * (1 - e.kbRes)
      if (push > 0) {
        const dx = e.x - world.player.x
        const dy = e.y - world.player.y
        const d = Math.hypot(dx, dy) || 1
        e.kbX += (dx / d) * push
        e.kbY += (dy / d) * push
      }
    }
    zones.release(z)
  }
}

// hitUids is a small fixed array on each shot (pierce is tiny: 1–3 in S1).
function hasHit(shot, uid) {
  const list = shot.hitUids
  for (let i = 0; i < list.length; i += 1) {
    if (list[i] === uid) return true
  }
  return false
}
function rememberHit(shot, uid) {
  shot.hitUids.push(uid)
}

// Factories for the shots / zones pools (used by SurvivorRun when building pools).
export { makeShot, makeZone }

// --- Hostile mist bubbles (01 §9 迷途菌灵, 03 §3.4 step 9, §3.5 mistBubbles 池) ---
// Straight-line enemy projectiles that only test against the player. Player weapons
// never touch them (裁决 L4). A bubble is consumed on contact with the player; it deals
// damage and starts invulnerability only when the player is not already invulnerable.
export function makeBubble() {
  return { slot: 0, uid: 0, x: 0, y: 0, vx: 0, vy: 0, r: 12, damage: 0, life: 0, source: '' }
}

// Register the OLD population before any firing. Reclamation is deferred until a
// shot needs a full pool's slot, leaving non-full trajectories/order unchanged.
export function prepareMistBubbleStep(world, dt) {
  world._mistBubbleStepDt = dt
  world._mistBubbleOldUid = world.mistBubbles.nextUid - 1
}

function reclaimExpiringMistBubbles(world) {
  const pool = world.mistBubbles
  const dt = world._mistBubbleStepDt
  for (let i = pool.count - 1; i >= 0; i -= 1) {
    const b = pool.active[i]
    // UID cutoff excludes every shot born during this firing phase, even if its
    // entire lifetime is shorter than dt. Only hostile update may age new shots.
    if (b.uid > world._mistBubbleOldUid || !(b.life - dt <= 0)) continue
    pool.release(b)
    if (i >= pool.count) continue
    // release swap-removes the tail. Restore stable survivor order before firing:
    // hostile collisions run backwards, so swapping could change the first hit.
    // At most 60 entries; rotate in place without allocating or changing free slots.
    const tail = pool.active[i]
    for (let j = i; j < pool.count - 1; j += 1) {
      const survivor = pool.active[j + 1]
      pool.active[j] = survivor
      pool.activeIndex[survivor.slot] = j
    }
    pool.active[pool.count - 1] = tail
    pool.activeIndex[tail.slot] = pool.count - 1
  }
}

// Fire one bubble from (x, y) toward (tx, ty). Pool full → counted in diag, not fired.
export function spawnBubble(world, x, y, tx, ty, spec, source) {
  if (world.mistBubbles.count === world.mistBubbles.capacity && world._mistBubbleStepDt > 0) {
    reclaimExpiringMistBubbles(world)
  }
  const b = world.mistBubbles.acquire()
  if (!b) {
    world.diag.dropped.bubbles = (world.diag.dropped.bubbles || 0) + 1
    return null
  }
  const dx = tx - x
  const dy = ty - y
  const d = Math.hypot(dx, dy) || 1
  b.x = x
  b.y = y
  b.vx = (dx / d) * spec.speed
  b.vy = (dy / d) * spec.speed
  b.r = spec.radius
  // Boss specs already include enrage, but not D. Lock compensation at fire time;
  // ordinary bubbles have no contact-damage minute growth.
  b.damage = world.ruleset === 'xianxia'
    ? scaleEnemyDamage(spec.damage, 0, source === WAVES.boss.enemy ? 7 : Math.floor(world.time / 60))
    : spec.damage
  b.life = spec.life
  b.source = source
  return b
}
// Move bubbles, expire them, and resolve hits on the player. Returns the bubble that
// hurt the player this step (or null) so the caller can record the killer / event.
export function stepMistBubbles(world, dt, invulnTime) {
  // The pre-fire eligibility window ends here; ad-hoc later spawns must not use
  // this step's old-population snapshot.
  world._mistBubbleStepDt = 0
  const bubbles = world.mistBubbles
  const p = world.player
  let hurtBy = null
  for (let i = bubbles.count - 1; i >= 0; i -= 1) {
    const b = bubbles.active[i]
    b.x += b.vx * dt
    b.y += b.vy * dt
    b.life -= dt
    if (b.life <= 0) {
      bubbles.release(b)
      continue
    }
    const rr = b.r + p.r
    const dx = b.x - p.x
    const dy = b.y - p.y
    if (dx * dx + dy * dy > rr * rr) continue
    if (p.invuln <= 0) {
      p.hp -= incomingDamage(b.damage, world.ruleset, world.stats?.damageTakenMul)
      p.invuln = invulnTime
      hurtBy = b.source
    }
    bubbles.release(b)
  }
  return hurtBy
}
