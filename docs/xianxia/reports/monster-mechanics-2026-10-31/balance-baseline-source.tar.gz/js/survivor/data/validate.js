// Data validation (03 §4). validate() returns an array of error strings; an empty
// array means the data is sound. Pure logic only: no Math.random, no Date.now, no cc/wx.
// Run in tests and once in the SurvivorRun constructor; a non-empty result is fatal
// (03 §4: 表现层显示「游戏数据异常」页面, 不带病运行).
//
// Validates player, weapons (all five, 01 §6.1–§6.5; a `placeholder: true` weapon must
// have empty levels and is excluded from drafts), passives, enemies, waves, limits.

import { PLAYER } from './player.js'
import { WEAPONS, EVOLUTION, SWORD_EVOLUTION, YUJIAN_LEVELS } from './weapons.js'
import { PASSIVES } from './passives.js'
import { ENEMIES } from './enemies.js'
import { WAVES } from './waves.js'
import { LIMITS } from './limits.js'
import { PERMANENT } from './permanent.js'
import { PICKUPS } from './pickups.js'

function isFiniteNumber(v) {
  return typeof v === 'number' && Number.isFinite(v)
}
function isPositiveNumber(v) {
  return isFiniteNumber(v) && v > 0
}
function isPositiveInt(v) {
  return Number.isInteger(v) && v > 0
}
function isNonNegativeNumber(v) {
  return isFiniteNumber(v) && v >= 0
}

// deepEqual via JSON round-trip (03 §4): catches functions, Infinity, NaN, undefined.
function jsonRoundTripsEqual(x) {
  let serialized
  try {
    serialized = JSON.stringify(x)
  } catch {
    return false
  }
  if (serialized === undefined) return false
  const parsed = JSON.parse(serialized)
  return JSON.stringify(parsed) === serialized
}

// 角色理论最高移速（01 §9.2 贴近追击）：基础移速 × (1 + 局外轻灵蕨步满级) × (1 + 蕨叶轻靴满级)
// = 160 × 1.15 × 1.4 = 257.6。由 permanent.js / passives.js 推导，避免手写常量漂移。
export function maxPlayerMoveSpeed() {
  const perm = PERMANENT.find((u) => u.bonus === 'moveSpeed')
  const permMax = perm ? perm.perLevel * perm.prices.length : 0
  let passiveMax = 0
  for (const id of Object.keys(PASSIVES)) {
    const def = PASSIVES[id]
    if (def.stat === 'moveSpeed') passiveMax += def.levels[def.levels.length - 1]
  }
  return PLAYER.moveSpeed * (1 + permMax) * (1 + passiveMax)
}

// Boss 贴近追击参数（01 §9.2，08 K15/L13）。返回错误字符串数组，空数组 = 合法。
// 四个字段为正数；enterDist > exitDist；exitDist > Boss 半径 + 角色半径（不会靠追近撞到角色）；
// speed > 角色理论最高移速（任何构筑都甩不开）；idleSec（08 K22 无伤触发秒数）为正数。
export function validateBossApproach(approach, bossRadius, path = 'approach') {
  const errors = []
  const push = (p, msg) => errors.push(`${p}: ${msg}`)
  if (!approach || typeof approach !== 'object') {
    push(path, 'Boss 必须有贴近追击参数')
    return errors
  }
  for (const f of ['fromStage', 'enterDist', 'exitDist', 'speed']) {
    if (!isPositiveNumber(approach[f])) push(`${path}.${f}`, '必须为有限正数')
  }
  if (!isPositiveInt(approach.fromStage)) push(`${path}.fromStage`, '必须为正整数')
  if (!(approach.enterDist > approach.exitDist)) push(`${path}.enterDist`, '必须大于 exitDist')
  const contact = bossRadius + PLAYER.radius
  if (!(approach.exitDist > contact)) push(`${path}.exitDist`, `必须大于 Boss 与角色接触距离 ${contact}`)
  const vmax = Math.round(maxPlayerMoveSpeed() * 1000) / 1000
  if (!(approach.speed > vmax)) push(`${path}.speed`, `必须大于角色理论最高移速 ${vmax}`)
  // 08 K22：无伤触发秒数，为正数
  if (!isPositiveNumber(approach.idleSec)) push(`${path}.idleSec`, '必须为有限正数')
  return errors
}

export function validate() {
  const errors = []
  const push = (path, msg) => errors.push(`${path}: ${msg}`)

  // --- player ---
  const playerNumericFields = [
    'maxHp', 'moveSpeed', 'pickupRadius', 'might', 'cooldown', 'area', 'invulnTime', 'radius',
  ]
  for (const field of playerNumericFields) {
    if (!isPositiveNumber(PLAYER[field])) push(`player.${field}`, '必须为有限正数')
  }
  if (!isNonNegativeNumber(PLAYER.regen)) push('player.regen', '必须为非负有限数')
  if (!isPositiveInt(PLAYER.weaponSlots)) push('player.weaponSlots', '必须为正整数')
  if (!isPositiveInt(PLAYER.passiveSlots)) push('player.passiveSlots', '必须为正整数')

  // --- weapons ---
  // Required per-level fields by weapon id (01 §6.1–§6.5). Every non-placeholder weapon
  // must be listed here; `positive` fields > 0, `ints` additionally integers,
  // `ratios` in (0, 1), `top` = weapon-level (not per-level) positive fields.
  const weaponSchemas = {
    spore_shot: {
      positive: ['damage', 'cooldown', 'count', 'pierce', 'speed', 'knockback', 'life'],
      ints: ['count', 'pierce'],
      ratios: [],
      evolvedRequired: true,
    },
    umbrella_blades: {
      positive: ['damage', 'count', 'orbitRadius', 'angularSpeedDeg', 'hitInterval', 'knockback'],
      ints: ['count'],
      ratios: [],
      evolvedRequired: true,
    },
    dew_ring: {
      positive: ['damage', 'radius', 'interval', 'slow'],
      ints: [],
      ratios: ['slow'],
      evolvedRequired: true,
    },
    raindrop: {
      positive: ['damage', 'count', 'radius', 'cooldown', 'knockback'],
      ints: ['count'],
      ratios: [],
      evolvedRequired: true,
      top: ['range', 'warnSec', 'fallbackMin', 'fallbackMax'],
    },
    leaf_boomerang: {
      positive: ['damage', 'count', 'maxDistance', 'speed', 'cooldown', 'knockback'],
      ints: ['count'],
      ratios: [],
      evolvedRequired: true,
      top: ['spreadDeg', 'leafRadius', 'catchRadius', 'maxLife'],
    },
    wanjian: {
      positive: ['coefPct', 'cooldown'],
      ints: [],
      ratios: [],
      evolvedRequired: false,
      top: ['warnSec'],
    },
    sj_yujian: {
      positive: ['damage', 'cooldown', 'count', 'pierce', 'speed', 'life'],
      nonNegative: ['knockback'],
      ints: ['count', 'pierce'],
      ratios: [],
      evolvedRequired: true,
      top: ['range'],
    },
    sj_arc: {
      positive: ['damage', 'cooldown', 'radius', 'angleDeg'],
      ints: [],
      ratios: [],
      evolvedRequired: false,
      top: ['warnSec'],
    },
    sj_wanjian: {
      positive: ['damage', 'count', 'orbitRadius', 'angularSpeedDeg', 'hitInterval'],
      ints: ['count'],
      ratios: [],
      evolvedRequired: true,
      top: ['bladeRadius'],
    },
    sj_shadow: {
      positive: ['damage', 'cooldown', 'radius'], ints: [], ratios: [],
      evolvedRequired: false, top: ['range', 'delaySec', 'maxPending'],
    },
    sj_formation: {
      positive: ['damage', 'cooldown', 'radius', 'duration'], ints: [], ratios: [],
      evolvedRequired: true, top: ['range', 'interval', 'slow', 'bossSlow', 'maxActive'],
    },
    sj_line: {
      positive: ['damage', 'cooldown', 'length', 'width', 'hitCap'],
      ints: ['hitCap'],
      ratios: [],
      evolvedRequired: true,
      top: ['warnSec'],
    },
  }
  const indices = new Set()
  for (const [id, weapon] of Object.entries(WEAPONS)) {
    if (!Number.isInteger(weapon.index) || weapon.index < 0 || weapon.index >= LIMITS.weaponIndexSlots) {
      push(`weapons.${id}.index`, `必须为 0–${LIMITS.weaponIndexSlots - 1} 的整数（敌人 hitAt 范围）`)
    } else if (indices.has(weapon.index)) {
      push(`weapons.${id}.index`, '与其它武器重复')
    } else {
      indices.add(weapon.index)
    }
    if (['wanjian', 'sj_yujian', 'sj_arc', 'sj_wanjian', 'sj_line', 'sj_shadow', 'sj_formation'].includes(id)) {
      if (['wanjian', 'sj_arc', 'sj_shadow'].includes(id) && (weapon.evolvesWith !== null || weapon.evolution !== null || weapon.evolved !== null)) {
        push(`weapons.${id}`, '当前无进化，三个进化字段必须为 null')
      }
      if (weapon.ruleset !== 'xianxia') push(`weapons.${id}.ruleset`, '必须为 xianxia')
      for (const axis of id === 'wanjian' ? ['width', 'height'] : []) {
        if (!isPositiveNumber(weapon.rect?.[axis])) push(`weapons.${id}.rect.${axis}`, '必须为有限正数')
      }
      const fixedIndex = { wanjian: 5, sj_yujian: 6, sj_arc: 7, sj_wanjian: 8, sj_line: 9, sj_shadow: 10, sj_formation: 11 }[id]
      if (weapon.index !== fixedIndex) push(`weapons.${id}.index`, `必须保留内部索引 ${fixedIndex}`)
    } else if (typeof weapon.evolvesWith !== 'string' || weapon.evolvesWith.length === 0) {
      push(`weapons.${id}.evolvesWith`, '必须指向一个被动 id')
    }
    // Out-of-scope weapons (08 §2) are explicit placeholders with empty levels.
    if (weapon.placeholder === true) {
      if (!Array.isArray(weapon.levels) || weapon.levels.length !== 0) {
        push(`weapons.${id}.levels`, '占位武器的 levels 必须为空数组')
      }
      continue
    }
    const schema = weaponSchemas[id]
    if (!schema) {
      push(`weapons.${id}`, '未知武器 id（非占位武器必须有校验规则）')
      continue
    }
    if (!Array.isArray(weapon.levels) || weapon.levels.length !== 5) {
      push(`weapons.${id}.levels`, '必须正好 5 档')
      continue
    }
    const checkLevel = (lvl, at) => {
      for (const f of schema.positive) {
        if (id === 'sj_line' && lvl === weapon.evolved && f === 'hitCap' && lvl.unlimitedTargets === true && lvl.hitCap === null) continue
        if (!isPositiveNumber(lvl[f])) push(`${at}.${f}`, '必须为有限正数')
      }
      for (const f of schema.ints) {
        if (id === 'sj_line' && lvl === weapon.evolved && f === 'hitCap' && lvl.unlimitedTargets === true && lvl.hitCap === null) continue
        if (!isPositiveInt(lvl[f])) push(`${at}.${f}`, '必须为正整数')
      }
      for (const f of schema.nonNegative || []) {
        if (!isNonNegativeNumber(lvl[f])) push(`${at}.${f}`, '必须为非负有限数')
      }
      if (id === 'sj_arc' && lvl.angleDeg > 360) push(`${at}.angleDeg`, '不得超过 360 度')
      for (const f of schema.ratios) {
        if (!(isPositiveNumber(lvl[f]) && lvl[f] < 1)) push(`${at}.${f}`, '必须在 (0,1)')
      }
    }
    weapon.levels.forEach((lvl, i) => checkLevel(lvl, `weapons.${id}.levels[${i}]`))
    if (id === 'umbrella_blades' && !isPositiveNumber(weapon.bladeRadius)) {
      push(`weapons.${id}.bladeRadius`, '必须为有限正数')
    }
    for (const f of schema.top || []) {
      if (!isPositiveNumber(weapon[f])) push(`weapons.${id}.${f}`, '必须为有限正数')
    }
    for (const field of id === 'sj_shadow' ? ['maxPending'] : id === 'sj_formation' ? ['maxActive'] : []) {
      if (!isPositiveInt(weapon[field]) || weapon[field] > 2) push(`weapons.${id}.${field}`, '必须为不超过 2 的正整数')
    }
    if (id === 'sj_formation') {
      if (!(weapon.slow <= .5)) push(`weapons.${id}.slow`, '普通减速不得超过 50%')
      if (!(weapon.bossSlow <= .1 && weapon.bossSlow <= weapon.slow)) push(`weapons.${id}.bossSlow`, 'Boss 减速不得超过 10% 或普通减速')
    }
    if (id === 'raindrop') {
      if (!(weapon.fallbackMin < weapon.fallbackMax)) push(`weapons.${id}.fallbackMin`, '必须小于 fallbackMax')
      const zoneCap = LIMITS.pools.raindropZones
      for (let i = 0; i < weapon.levels.length; i += 1) {
        if (weapon.levels[i].count > zoneCap) push(`weapons.${id}.levels[${i}].count`, `落点数不得超过 limits.pools.raindropZones (${zoneCap})`)
      }
      if (weapon.evolved && weapon.evolved.count > zoneCap) push(`weapons.${id}.evolved.count`, `落点数不得超过 limits.pools.raindropZones (${zoneCap})`)
    }
    if (id === 'leaf_boomerang') {
      // 无限穿透只能靠回收结束：安全寿命必须够飞一个来回。
      const tiers = weapon.evolved ? [...weapon.levels, weapon.evolved] : weapon.levels
      for (let i = 0; i < tiers.length; i += 1) {
        const lvl = tiers[i]
        if (isPositiveNumber(lvl.speed) && !(weapon.maxLife > (2 * lvl.maxDistance) / lvl.speed)) {
          push(`weapons.${id}.maxLife`, `必须大于${i < weapon.levels.length ? ` Lv${i + 1}` : '进化档'}往返时间`)
        }
      }
    }
    // Evolution (01 §6: 5 级 + 1 进化；S3 B2 起五把都必须有进化档)。
    if (weapon.evolved === null && !schema.evolvedRequired) {
      // allowed
    } else if (!weapon.evolved || typeof weapon.evolved !== 'object') {
      push(`weapons.${id}.evolved`, '必须有进化形态')
    } else {
      checkLevel(weapon.evolved, `weapons.${id}.evolved`)
      const swordFields = {
        sj_yujian: ['rainCooldown', 'rainRange', 'rainWidth', 'rainHeight', 'rainWarnSec', 'rainHits', 'rainInterval', 'rainDamage'],
        sj_wanjian: ['innerRadius', 'innerDamage', 'windowTicks'],
        sj_line: ['chargeSec', 'lockSec'],
        sj_formation: ['eyeOffset', 'eyeCount', 'interval', 'slow', 'bossSlow', 'maxActive'],
      }
      const evolved = weapon.evolved
      for (const field of swordFields[id] || []) {
        if (!isPositiveNumber(evolved[field])) push(`weapons.${id}.evolved.${field}`, '必须为有限正数')
      }
      const recipes = { sj_yujian: 'sj_heart', sj_wanjian: 'sj_mark', sj_line: 'sj_bone', sj_formation: 'sj_gate' }
      if (recipes[id] && weapon.evolvesWith !== recipes[id]) push(`weapons.${id}.evolvesWith`, '必须匹配剑修进化配方')
      if (id === 'sj_yujian' && (!isPositiveInt(evolved.rainHits) || evolved.rainHits !== 6 || Math.max(evolved.rainWidth, evolved.rainHeight) > 760)) push(`weapons.${id}.evolved`, '剑雨必须为6跳、有限世界区域')
      if (id === 'sj_wanjian' && evolved.windowTicks !== 30) push(`weapons.${id}.evolved.windowTicks`, '必须为30个模拟tick')
      if (id === 'sj_line' && (!(evolved.lockSec < evolved.chargeSec) || evolved.unlimitedTargets !== true || evolved.hitCap !== null || evolved.length > 760)) push(`weapons.${id}.evolved`, '蓄势锁定及有限长度贯穿参数错误')
      if (id === 'sj_formation' && (evolved.eyeCount !== 4 || evolved.maxActive !== 2 || evolved.duration / evolved.interval !== 9 || evolved.slow > .5 || evolved.bossSlow > .1)) push(`weapons.${id}.evolved`, '四阵眼共享9跳、最多2组，遵守减速上限')
      if (typeof weapon.evolved.name !== 'string' || weapon.evolved.name.length === 0) push(`weapons.${id}.evolved.name`, '必须有进化名')
      if (typeof weapon.evolution !== 'string' || weapon.evolution.length === 0) push(`weapons.${id}.evolution`, '必须有进化形态 id')
      if (!PASSIVES[weapon.evolvesWith]) push(`weapons.${id}.evolvesWith`, '必须指向 data/passives.js 中的被动')
      if (id === 'umbrella_blades' && weapon.evolved.count > 8) push(`weapons.${id}.evolved.count`, '片数不得超过 8（MAX_BLADES）')
    }
  }

  if (!isPositiveInt(LIMITS.weaponIndexSlots)) push('limits.weaponIndexSlots', '必须为正整数')
  if (YUJIAN_LEVELS.length !== 5) push('weapons.yujian', '必须正好 5 档')
  YUJIAN_LEVELS.forEach((row, i) => {
    for (const field of ['lifeAdd', 'knockbackAdd']) {
      if (!isNonNegativeNumber(row[field])) push(`weapons.yujian[${i}].${field}`, '必须为非负有限数')
    }
    for (const field of ['pierceAdd', 'countAdd']) {
      if (!Number.isInteger(row[field]) || row[field] < 0) push(`weapons.yujian[${i}].${field}`, '必须为非负整数')
    }
    if (!isPositiveNumber(row.speedMul)) push(`weapons.yujian[${i}].speedMul`, '必须为有限正数')
    for (const tier of [...WEAPONS.spore_shot.levels, WEAPONS.spore_shot.evolved]) {
      if (tier.count + row.countAdd > 16) push(`weapons.yujian[${i}].countAdd`, '修正后弹数不得超过 16')
    }
  })

  // --- passives (01 §7) ---
  const passiveStats = new Set(['might', 'cooldown', 'area', 'moveSpeed', 'regen', 'pickup', 'damageTaken'])
  for (const [id, passive] of Object.entries(PASSIVES)) {
    const at = `passives.${id}`
    const swordFields = {
      sj_heart: ['critChance', 'critMultiplier'],
      sj_mark: ['maxStacks', 'damagePerSecond'],
      sj_bone: ['might', 'cooldown', 'moveSpeed'],
      sj_gate: ['chance', 'radius', 'damage'],
    }[id]
    if (swordFields) {
      if (passive.stat !== 'sword' || passive.ruleset !== 'xianxia') push(at, '剑修心法必须为 xianxia / sword')
      if (!Array.isArray(passive.levels) || passive.levels.length !== 5) {
        push(`${at}.levels`, '必须正好 5 档')
        continue
      }
      passive.levels.forEach((row, i) => {
        const path = `${at}.levels[${i}]`
        for (const field of swordFields) {
          if (!isPositiveNumber(row?.[field])) push(`${path}.${field}`, '必须为有限正数')
        }
        for (const field of ['critChance', 'chance', 'might', 'cooldown', 'moveSpeed']) {
          if (swordFields.includes(field) && !(row?.[field] < 1)) push(`${path}.${field}`, '必须小于 1')
        }
        if (id === 'sj_heart' && !(row?.critMultiplier >= 1)) push(`${path}.critMultiplier`, '暴击倍率不得小于 1')
        if (id === 'sj_mark' && !(isPositiveInt(row?.maxStacks) && row.maxStacks <= 8)) push(`${path}.maxStacks`, '必须为不超过 8 的正整数')
      })
      continue
    }
    if (!passiveStats.has(passive.stat)) push(`${at}.stat`, '必须为 might/cooldown/area/moveSpeed/regen/pickup/damageTaken 之一')
    if (!isPositiveNumber(passive.perLevel)) push(`${at}.perLevel`, '必须为有限正数')
    if (!Array.isArray(passive.levels) || passive.levels.length !== 5) {
      push(`${at}.levels`, '必须正好 5 档')
      continue
    }
    passive.levels.forEach((v, i) => {
      if (passive.stat === 'damageTaken' && !(v >= 0 && v < 1)) push(`${at}.levels[${i}]`, '减伤必须在 [0,1)')
      // 每级效果相同、线性叠加：Lv(i+1) 累计 = perLevel × (i+1)。
      if (!isPositiveNumber(v) || Math.abs(v - passive.perLevel * (i + 1)) > 1e-9) {
        push(`${at}.levels[${i}]`, '必须等于 perLevel × 等级（线性叠加）')
      }
    })
  }

  // --- enemies ---
  const enemyNumericFields = ['hp', 'moveSpeed', 'contactDamage', 'radius']
  for (const [id, enemy] of Object.entries(ENEMIES)) {
    for (const f of enemyNumericFields) {
      if (!isPositiveNumber(enemy[f])) push(`enemies.${id}.${f}`, '必须为有限正数')
    }
    if (!isNonNegativeNumber(enemy.xp)) push(`enemies.${id}.xp`, '必须为非负有限数')
    if (!(isNonNegativeNumber(enemy.knockbackResist) && enemy.knockbackResist <= 1)) {
      push(`enemies.${id}.knockbackResist`, '必须在 [0,1]')
    }
    if (!isNonNegativeNumber(enemy.firstSeenSec)) push(`enemies.${id}.firstSeenSec`, '必须为非负有限数')
    if (!isNonNegativeNumber(enemy.hpGrowthPerMin)) push(`enemies.${id}.hpGrowthPerMin`, '必须为非负有限数')
    if (!isNonNegativeNumber(enemy.damageGrowthPerMin)) push(`enemies.${id}.damageGrowthPerMin`, '必须为非负有限数')
    const behaviorFields = {
      chase: [],
      sway: ['swayAmplitude', 'swayPeriod'],
      ranged: ['approachRange', 'fireRange', 'fireInterval'],
      charge: ['chargeEvery', 'chargeWindup', 'chargeDuration', 'chargeSpeedMul'],
      boss: [],
    }
    if (enemy.behavior === 'boss') {
      const groups = {
        summon: ['every', 'count', 'radius'],
        charge: ['every', 'windup', 'duration', 'speedMul'],
        bubbleRing: ['every', 'hpBelow', 'count'],
        erosion: ['fromSec', 'everySec', 'takenStep', 'takenMax'],
      }
      for (const [g, gf] of Object.entries(groups)) {
        const obj = enemy[g]
        if (!obj || typeof obj !== 'object') {
          push(`enemies.${id}.${g}`, 'Boss 必须有该技能参数')
          continue
        }
        for (const f of gf) {
          if (!isPositiveNumber(obj[f])) push(`enemies.${id}.${g}.${f}`, '必须为有限正数')
        }
      }
      // 超时兜底阶段（01 §9.2，08 K13）：按 atSec 严格升序的非空数组；后档替换前档。
      const phases = enemy.enrage
      let lastTaken = 1
      if (!Array.isArray(phases) || phases.length === 0) {
        push(`enemies.${id}.enrage`, '必须为按 atSec 升序的非空阶段数组')
      } else {
        phases.forEach((ph, i) => {
          const at = `enemies.${id}.enrage[${i}]`
          for (const f of ['atSec', 'speedMul', 'damageMul']) {
            if (!isPositiveNumber(ph[f])) push(`${at}.${f}`, '必须为有限正数')
          }
          if (i > 0 && !(ph.atSec > phases[i - 1].atSec)) push(`${at}.atSec`, '必须严格大于前一阶段')
          if (ph.cooldownMul !== undefined && !(isPositiveNumber(ph.cooldownMul) && ph.cooldownMul <= 1)) push(`${at}.cooldownMul`, '必须在 (0,1]')
          if (ph.takenMul !== undefined && !isPositiveNumber(ph.takenMul)) push(`${at}.takenMul`, '必须为有限正数')
          if (ph.ringIgnoresHp !== undefined && typeof ph.ringIgnoresHp !== 'boolean') push(`${at}.ringIgnoresHp`, '必须为布尔值')
        })
        const last = phases[phases.length - 1]
        lastTaken = isPositiveNumber(last.takenMul) ? last.takenMul : 1
        if (enemy.erosion && isFiniteNumber(enemy.erosion.fromSec) && !(enemy.erosion.fromSec > last.atSec)) {
          push(`enemies.${id}.erosion.fromSec`, '必须晚于最后一个狂暴阶段')
        }
      }
      if (enemy.erosion && isFiniteNumber(enemy.erosion.takenMax) && !(enemy.erosion.takenMax >= lastTaken)) {
        push(`enemies.${id}.erosion.takenMax`, '不得小于最后阶段的 takenMul')
      }
      errors.push(...validateBossApproach(enemy.approach, enemy.radius, `enemies.${id}.approach`))
      if (enemy.approach && isPositiveInt(enemy.approach.fromStage) && Array.isArray(phases) && enemy.approach.fromStage > phases.length) {
        push(`enemies.${id}.approach.fromStage`, '不得超过狂暴阶段数')
      }
      if (enemy.summon && !ENEMIES[enemy.summon.enemy]) push(`enemies.${id}.summon.enemy`, '引用了不存在的敌人 id')
      if (enemy.summon && !isPositiveInt(enemy.summon.count)) push(`enemies.${id}.summon.count`, '必须为正整数')
      if (enemy.bubbleRing && !isPositiveInt(enemy.bubbleRing.count)) push(`enemies.${id}.bubbleRing.count`, '必须为正整数')
      if (enemy.bubbleRing && !(enemy.bubbleRing.hpBelow < 1)) push(`enemies.${id}.bubbleRing.hpBelow`, '必须在 (0,1)')
      if (enemy.charge && !(enemy.charge.windup + enemy.charge.duration < enemy.charge.every)) {
        push(`enemies.${id}.charge`, '预警 + 冲撞时长必须小于冷却')
      }
      const b = enemy.bubbleRing && enemy.bubbleRing.bubble
      if (!b || typeof b !== 'object') push(`enemies.${id}.bubbleRing.bubble`, '必须有浊雾泡参数')
      else {
        for (const f of ['speed', 'damage', 'life', 'radius']) {
          if (!isPositiveNumber(b[f])) push(`enemies.${id}.bubbleRing.bubble.${f}`, '必须为有限正数')
        }
      }
    }
    const fields = behaviorFields[enemy.behavior]
    if (!fields) {
      push(`enemies.${id}.behavior`, '必须为 chase/sway/ranged/charge/boss 之一')
    } else {
      for (const f of fields) {
        if (!isPositiveNumber(enemy[f])) push(`enemies.${id}.${f}`, '必须为有限正数')
      }
    }
    if (enemy.behavior === 'ranged') {
      const b = enemy.bubble
      if (!b || typeof b !== 'object') push(`enemies.${id}.bubble`, '远程敌人必须有浊雾泡参数')
      else {
        for (const f of ['speed', 'damage', 'life', 'radius']) {
          if (!isPositiveNumber(b[f])) push(`enemies.${id}.bubble.${f}`, '必须为有限正数')
        }
      }
    }
  }

  // --- waves ---
  // 08 K1：计时胜利只走 SurvivorRun 调试选项，数据里不再有 winAtSeconds。
  if ('winAtSeconds' in WAVES) push('waves.winAtSeconds', '已移除（08 K1：计时胜利改为调试选项 debug.timedWinSec）')
  const boss = WAVES.boss
  if (!boss || typeof boss !== 'object') {
    push('waves.boss', '必须为对象')
  } else {
    if (!ENEMIES[boss.enemy] || ENEMIES[boss.enemy].behavior !== 'boss') push('waves.boss.enemy', '必须引用 behavior=boss 的敌人')
    if (!isPositiveNumber(boss.atSec)) push('waves.boss.atSec', '必须为有限正数')
    if (!(isPositiveNumber(boss.warningSec) && boss.warningSec < boss.atSec)) push('waves.boss.warningSec', '必须为正数且小于 atSec')
  }
  const extraction = WAVES.extraction
  if (!extraction || typeof extraction !== 'object') {
    push('waves.extraction', '必须为对象')
  } else {
    for (const f of ['cleansingSec', 'distance', 'radius', 'holdSec', 'healPerSec']) {
      if (!isPositiveNumber(extraction[f])) push(`waves.extraction.${f}`, '必须为有限正数')
    }
  }
  const segments = WAVES.segments
  if (!Array.isArray(segments) || segments.length === 0) {
    push('waves.segments', '必须为非空数组')
  } else {
    const enemyCap = LIMITS.hardCaps.enemies
    segments.forEach((seg, i) => {
      const at = `waves.segments[${i}]`
      if (!isNonNegativeNumber(seg.fromSec)) push(`${at}.fromSec`, '必须为非负有限数')
      // 08 K2：只有最后一段可以用 toSec: null 表示开放区间（7:00–Boss 击败）。
      const last = i === segments.length - 1
      if (seg.toSec === null) {
        if (!last) push(`${at}.toSec`, '只有最后一段允许为 null')
      } else if (!isPositiveNumber(seg.toSec)) push(`${at}.toSec`, '必须为有限正数或（仅最后一段）null')
      if (isFiniteNumber(seg.fromSec) && isFiniteNumber(seg.toSec) && seg.toSec <= seg.fromSec) {
        push(`${at}`, 'toSec 必须大于 fromSec (单调递增)')
      }
      if (i === 0 && seg.fromSec !== 0) push(`${at}.fromSec`, '首段必须从 0 开始')
      if (i > 0 && seg.fromSec !== segments[i - 1].toSec) {
        push(`${at}.fromSec`, '波次段必须首尾相接')
      }
      if (!isPositiveNumber(seg.spawnRate)) push(`${at}.spawnRate`, '必须为有限正数')
      if (!isPositiveInt(seg.cap)) push(`${at}.cap`, '必须为正整数')
      else if (seg.cap > enemyCap) push(`${at}.cap`, `同屏上限不得超过 limits.hardCaps.enemies (${enemyCap})`)
      // composition: ids must exist in enemies, values sum to 100.
      const composition = seg.composition
      if (!composition || typeof composition !== 'object') {
        push(`${at}.composition`, '必须为对象')
      } else {
        let sum = 0
        for (const [enemyId, pct] of Object.entries(composition)) {
          if (!ENEMIES[enemyId]) push(`${at}.composition.${enemyId}`, '引用了不存在的敌人 id')
          if (!isNonNegativeNumber(pct)) push(`${at}.composition.${enemyId}`, '组成百分比必须为非负有限数')
          else sum += pct
        }
        if (sum !== 100) push(`${at}.composition`, `组成百分比之和必须为 100，当前 ${sum}`)
      }
    })
  }
  // events (01 §10 事件列): sorted by atSec, known type, known enemy, positive count.
  const events = WAVES.events
  if (!Array.isArray(events)) {
    push('waves.events', '必须为数组')
  } else {
    events.forEach((ev, i) => {
      const at = `waves.events[${i}]`
      if (!isNonNegativeNumber(ev.atSec)) push(`${at}.atSec`, '必须为非负有限数')
      if (i > 0 && isFiniteNumber(ev.atSec) && ev.atSec < events[i - 1].atSec) {
        push(`${at}.atSec`, '事件必须按时间升序')
      }
      if (!['ring', 'cross', 'elite'].includes(ev.type)) push(`${at}.type`, '必须为 ring/cross/elite 之一')
      if (!ENEMIES[ev.enemy]) push(`${at}.enemy`, '引用了不存在的敌人 id')
      if (!isPositiveInt(ev.count)) push(`${at}.count`, '必须为正整数')
      if (ev.type === 'ring' && !isPositiveNumber(ev.radius)) push(`${at}.radius`, '必须为有限正数')
      // 围墙缺口（01 §10，08 K12）：slots 为正整数，skip 为 0…slots−1 内不重复整数，count = slots − skip 数。
      if (ev.gap !== undefined) {
        const g = ev.gap
        if (ev.type !== 'ring') push(`${at}.gap`, '只有 ring 事件可以带 gap')
        if (!g || typeof g !== 'object') push(`${at}.gap`, '必须为对象')
        else {
          if (!isPositiveInt(g.slots)) push(`${at}.gap.slots`, '必须为正整数')
          if (!Array.isArray(g.skip)) push(`${at}.gap.skip`, '必须为数组')
          else {
            const seenSkip = new Set()
            for (const k of g.skip) {
              if (!Number.isInteger(k) || k < 0 || !(k < g.slots)) push(`${at}.gap.skip`, `槽号 ${k} 必须在 0…slots−1 内`)
              else if (seenSkip.has(k)) push(`${at}.gap.skip`, `槽号 ${k} 重复`)
              seenSkip.add(k)
            }
            if (isPositiveInt(g.slots) && ev.count !== g.slots - g.skip.length) push(`${at}.count`, 'gap 事件的 count 必须等于 slots − skip 数')
          }
          if (g.anchor !== 'facing') push(`${at}.gap.anchor`, "必须为 'facing'")
        }
      }
      if (ev.type === 'cross' && !isPositiveNumber(ev.spacing)) push(`${at}.spacing`, '必须为有限正数')
      if (ev.type === 'elite' && ENEMIES[ev.enemy] && ENEMIES[ev.enemy].behavior !== 'charge') push(`${at}.enemy`, 'elite 事件必须引用冲撞型（charge）精英')
      if (ev.optional !== undefined && typeof ev.optional !== 'boolean') push(`${at}.optional`, '必须为布尔值')
    })
  }

  // --- limits ---
  for (const group of ['hardCaps', 'pools', 'nodes']) {
    const bucket = LIMITS[group]
    if (!bucket || typeof bucket !== 'object') {
      push(`limits.${group}`, '必须为对象')
      continue
    }
    for (const [key, val] of Object.entries(bucket)) {
      if (!isPositiveInt(val)) push(`limits.${group}.${key}`, '必须为正整数')
    }
  }
  if (!isPositiveNumber(LIMITS.spawnMarginU)) push('limits.spawnMarginU', '必须为有限正数')

  // --- pickups (01 §11) ---
  let capped = 0
  for (const id of ['dew', 'bigDew', 'wind']) {
    const d = PICKUPS[id]
    const at = `pickups.${id}`
    if (!d || typeof d !== 'object') {
      push(at, '缺少拾取物参数')
      continue
    }
    for (const f of ['heal', 'chance']) if (!isNonNegativeNumber(d[f])) push(`${at}.${f}`, '必须为非负有限数')
    for (const f of ['lifeSec', 'radius']) if (!isPositiveNumber(d[f])) push(`${at}.${f}`, '必须为有限正数')
    if (d.cap !== null && !isPositiveInt(d.cap)) push(`${at}.cap`, '必须为正整数或 null（不计上限）')
    if (isPositiveInt(d.cap)) capped += d.cap
  }
  if (PICKUPS.dew && PICKUPS.wind && !(PICKUPS.dew.chance + PICKUPS.wind.chance < 1)) push('pickups', '露珠 + 林风掉率之和必须小于 1')
  if (PICKUPS.wind && !isPositiveNumber(PICKUPS.wind.attractSpeed)) push('pickups.wind.attractSpeed', '必须为有限正数')
  if (!(capped < LIMITS.pools.pickups)) push('pickups', `有上限的拾取物合计 ${capped} 必须小于 limits.pools.pickups，给大露珠留槽`)
  if (!Array.isArray(PICKUPS.eliteDrops) || PICKUPS.eliteDrops.some((k) => !PICKUPS[k] || k === 'eliteDrops')) push('pickups.eliteDrops', '必须为拾取物 id 数组')
  // --- evolution gate (01 §8.3, 2026-10 S3 平衡) ---
  const maxPassiveLv = Math.min(...Object.values(PASSIVES).map((p) => p.levels.length))
  if (!isPositiveInt(EVOLUTION.passiveLevel) || EVOLUTION.passiveLevel > maxPassiveLv) push('weapons.EVOLUTION.passiveLevel', `必须为 1–${maxPassiveLv} 的整数`)
  if (!isNonNegativeNumber(EVOLUTION.unlockSec)) push('weapons.EVOLUTION.unlockSec', '必须为非负有限数')
  for (const [field, expected] of Object.entries({ passiveLevel: 3, unlockSec: 360, appliedLevel: 19, maxEvolved: 2 })) {
    if (SWORD_EVOLUTION[field] !== expected) push(`weapons.SWORD_EVOLUTION.${field}`, `必须为 ${expected}`)
  }
  // --- JSON round-trip (03 §4): guards against functions / Infinity / NaN. ---
  for (const [name, mod] of [['player', PLAYER], ['weapons', WEAPONS], ['passives', PASSIVES], ['enemies', ENEMIES], ['waves', WAVES], ['limits', LIMITS], ['pickups', PICKUPS]]) {
    if (!jsonRoundTripsEqual(mod)) push(`${name}`, '无法 JSON 往返（混入了函数/Infinity/NaN）')
  }

  return errors
}
