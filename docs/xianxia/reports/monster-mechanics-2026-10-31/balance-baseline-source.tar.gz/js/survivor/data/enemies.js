// Enemy data (01-gdd §9). Only a frozen JSON literal: no functions, no imports.
// ids use 01 §15.5 English ids. S2 ships gnat / beetle / moth / snail / sporeling;
// elite_beetle spawns once at 5:00 (S3 B4, waves.js elite event).
// Each enemy carries the growth coefficients from 01 §9.1 so the spawner can scale
// hp/contact damage by the current whole minute m = floor(t / 60):
//   hp     = baseHp     × (1 + hpGrowthPerMin × m)
//   damage = baseDamage × (1 + damageGrowthPerMin × m)
// move speed and xp do not grow (01 §9.1).
//
// `behavior` selects the movement rule in Enemies.js:
//   chase  — straight-line tracking (gnat, beetle, snail)
//   sway   — tracking + perpendicular sway (moth: swayAmplitude / swayPeriod)
//   ranged — sporeling: approach while > approachRange, spit a mist bubble every
//            fireInterval while ≤ fireRange (bubble: speed / damage / life / radius)
//   charge — elite_beetle: chase; every chargeEvery s (start-to-start, from spawn) stand still
//            for chargeWindup s with the direction locked, then dash chargeDuration s at
//            ×chargeSpeedMul (Enemies.js, eliteCharge event); never relocated (01 §9)
//   boss   — boss_mist_snail: chase + summon / charge / bubbleRing skills, enrage phases + erosion (Boss.js)
const HP_GROWTH_PER_MIN = 0.15     // 01 §9.1 生命成长系数
const DAMAGE_GROWTH_PER_MIN = 0.05 // 01 §9.1 接触伤害成长系数
export const ENEMIES = Object.freeze({
  gnat: Object.freeze({
    name: '蚊蚋群',
    hp: 8,
    moveSpeed: 110,
    contactDamage: 5,
    xp: 1,
    radius: 10,
    knockbackResist: 0,        // 0%
    firstSeenSec: 0,           // 0:00
    behavior: 'chase',
    hpGrowthPerMin: HP_GROWTH_PER_MIN,
    damageGrowthPerMin: DAMAGE_GROWTH_PER_MIN,
  }),
  beetle: Object.freeze({
    name: '圆壳甲虫',
    hp: 25,
    moveSpeed: 70,
    contactDamage: 8,
    xp: 2,
    radius: 16,
    knockbackResist: 0.3,      // 30%
    firstSeenSec: 60,          // 1:00
    behavior: 'chase',
    hpGrowthPerMin: HP_GROWTH_PER_MIN,
    damageGrowthPerMin: DAMAGE_GROWTH_PER_MIN,
  }),
  moth: Object.freeze({
    name: '灰蛾',
    hp: 18,
    moveSpeed: 130,
    contactDamage: 6,
    xp: 2,
    radius: 14,
    knockbackResist: 0,        // 0%
    firstSeenSec: 120,         // 2:00
    behavior: 'sway',
    swayAmplitude: 40,         // 左右摆动振幅
    swayPeriod: 1.2,           // 摆动周期（秒）
    hpGrowthPerMin: HP_GROWTH_PER_MIN,
    damageGrowthPerMin: DAMAGE_GROWTH_PER_MIN,
  }),
  snail: Object.freeze({
    name: '雨夜蜗牛',
    hp: 80,
    moveSpeed: 35,
    contactDamage: 12,
    xp: 5,
    radius: 22,
    knockbackResist: 0.8,      // 80%
    firstSeenSec: 180,         // 3:00
    behavior: 'chase',
    hpGrowthPerMin: HP_GROWTH_PER_MIN,
    damageGrowthPerMin: DAMAGE_GROWTH_PER_MIN,
  }),
  sporeling: Object.freeze({
    name: '迷途菌灵',
    hp: 40,
    moveSpeed: 60,
    contactDamage: 6,
    xp: 4,
    radius: 16,
    knockbackResist: 0.2,      // 20%
    firstSeenSec: 240,         // 4:00
    behavior: 'ranged',
    approachRange: 180,        // 距离 > 180 时追近
    fireRange: 250,            // 距离 ≤ 250 时吐泡
    fireInterval: 2,           // 每 2 秒 1 个（08 K21：3 → 2）
    bubble: Object.freeze({
      speed: 150,
      damage: 6,
      life: 3,
      radius: 12,              // 02 §9 fx-mist-bubble 直径 24u
    }),
    hpGrowthPerMin: HP_GROWTH_PER_MIN,
    damageGrowthPerMin: DAMAGE_GROWTH_PER_MIN,
  }),
  elite_beetle: Object.freeze({
    name: '精英圆壳甲虫',
    hp: 1500,
    moveSpeed: 80,
    contactDamage: 15,
    xp: 50,
    radius: 28,
    knockbackResist: 0.9,      // 90%
    firstSeenSec: 300,         // 5:00
    behavior: 'charge',
    chargeEvery: 5,            // 每 5 秒
    chargeWindup: 0.8,         // 蓄力 0.8 秒
    chargeDuration: 1,         // 冲撞 1 秒
    chargeSpeedMul: 2.5,       // 速度 ×2.5
    hpGrowthPerMin: HP_GROWTH_PER_MIN,
    damageGrowthPerMin: DAMAGE_GROWTH_PER_MIN,
  }),
  // Boss（01 §9.2）。数值固定，不走 §9.1 成长（系数为 0），不受远离重定位。出现时间见 waves.boss。
  // 技能各自独立计时、从出现起算，冷却按“开始到开始”计。
  boss_mist_snail: Object.freeze({
    name: '浊雾巨蜗',
    hp: 5500,                  // 08 K7：10000 → 4500；2026-10 S3 平衡 用户拍板：4500 → 5500
    moveSpeed: 45,
    contactDamage: 20,
    xp: 0,                     // 击败后直接进入撤离阶段
    radius: 56,
    knockbackResist: 1,        // 100%
    firstSeenSec: 420,         // 7:00
    behavior: 'boss',
    hpGrowthPerMin: 0,
    damageGrowthPerMin: 0,
    summon: Object.freeze({
      every: 8,                // 召唤虫群：冷却 8 秒
      enemy: 'gnat',
      count: 12,               // 12 只蚊蚋，计入敌人上限
      radius: 96,              // 在 Boss 周围等距生成的半径（初稿待 M2 调）
    }),
    charge: Object.freeze({
      every: 6,                // 雾壳冲撞：冷却 6 秒
      windup: 0.8,             // 方向箭头预警 0.8 秒
      duration: 1,             // 冲 1 秒
      speedMul: 2.5,           // 速度 ×2.5
    }),
    bubbleRing: Object.freeze({
      every: 10,               // 浊雾泡环：冷却 10 秒
      hpBelow: 0.5,            // 仅生命 <50%
      count: 8,                // 8 个方向
      bubble: Object.freeze({ speed: 120, damage: 10, life: 4, radius: 12 }),
    }),
    // 超时兜底（01 §9.2，08 K13）：按时间升序的阶段，后档替换前档倍率、不连乘。
    // damageMul 作用于 Boss 接触伤害与浊雾泡；cooldownMul 作用于三个技能冷却；
    // ringIgnoresHp 时泡环不再要求生命 <50%；takenMul = Boss 受到伤害倍率（乘在取整前）。
    enrage: Object.freeze([
      Object.freeze({ atSec: 600, speedMul: 1.3, damageMul: 1.5 }), // 狂暴 I（10:00）
      Object.freeze({ atSec: 660, speedMul: 1.6, damageMul: 2.0, cooldownMul: 0.5, ringIgnoresHp: true, takenMul: 1.5 }), // 狂暴 II（11:00）
    ]),
    // 雾壳剥落：fromSec 起每满 everySec 秒叠 1 层，每层受到伤害 +takenStep，封顶 takenMax。
    erosion: Object.freeze({ fromSec: 720, everySec: 60, takenStep: 0.5, takenMax: 4.0 }),
    // 贴近追击（01 §9.2，08 K15）：enrageStage ≥ fromStage（2 = 狂暴 II 及其后所有雾壳剥落层）时，
    // 中心距 d > enterDist 进入追近、d ≤ exitDist 退出；追近移速固定 speed，不乘狂暴倍率、
    // 不受露珠环减速；追近期间不起手冲撞。只依赖距离与时间，不消耗随机数。
    // idleSec（08 K22）：Boss 出现后连续 idleSec 秒未受到任何伤害，立即按同一套规则开始追击，
    // 不等 fromStage；触发后本场保持。
    approach: Object.freeze({ fromStage: 2, enterDist: 120, exitDist: 90, speed: 320, idleSec: 60 }),
  }),
})
