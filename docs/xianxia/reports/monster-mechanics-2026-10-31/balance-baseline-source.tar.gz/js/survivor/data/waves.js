// Wave data (01-gdd §10). Only a frozen JSON literal: no functions, no imports.
// Segments follow 01 §10 from 0:00 to Boss 击败. The last segment (7:00–Boss 击败) is
// open-ended: `toSec: null` (08 K2 — must stay JSON-safe, so no Infinity); only the
// last segment may be null. Segments stay contiguous (each `fromSec` equals the
// previous `toSec`) and every composition sums to 100. 撤离阶段不刷怪（由状态机停掉）。
//
// `composition` maps enemy id → percent weight (integers summing to 100; 0% ids are
// omitted). `spawnRate` is enemies/second, `cap` is the on-screen cap (01 §10,
// ≤ limits hard cap).
//
// `events` (01 §10 事件列, sorted by atSec) fire once each when the run clock reaches
// `atSec`. All event spawns obey the global hard cap (limits.hardCaps.enemies):
//   ring  — `count` × `enemy` evenly spaced on a circle of `radius` around the player,
//           then they chase normally (收拢). Without `gap` the start angle is random.
//           With `gap: {slots, skip, anchor:'facing'}` (01 §10 围墙缺口规则, 08 K12) the
//           circle is split into `slots` slots at θf + 360°/slots × (k + 0.5), where θf
//           is the player's facing at trigger time; slots listed in `skip` stay empty and
//           the rest spawn in k order (no random numbers; count = slots − skip.length)
//   cross — `count` × `enemy` in a vertical column (`spacing` apart) just outside one
//           side of the screen, flying straight across; recycled silently on exit
//   elite — 5:00 精英（S3 B4）：`count` × `enemy` on the spawn circle (random angle, off-screen).
//           Obeys the global hard cap; when the field is full the spawn waits until a slot
//           frees up. `optional: true` would make the spawner skip an event (none left).
//
// `boss` (01 §9.2): 6:58 发 bossWarning（atSec − warningSec），7:00 在角色正上方屏外生成。
//
// 胜利只走 Boss → cleansing → extract 撤离（01 §12）。S1 的 180 秒计时胜利已移除，
// 仅保留为 SurvivorRun 调试选项 `debug.timedWinSec`（08 K1，默认关闭）。
export const WAVES = Object.freeze({
  boss: Object.freeze({ enemy: 'boss_mist_snail', atSec: 420, warningSec: 2 }),
  // 01 §9.3：击败 Boss → cleansing 演出 1.5 秒（玩家无敌、全场净化）→ 距角色 distance 的随机
  // 方向生成半径 radius 的阳光撤离点；连续停留 holdSec 秒胜利，离开清零；每秒回复 healPerSec。
  extraction: Object.freeze({ cleansingSec: 1.5, distance: 250, radius: 50, holdSec: 2, healPerSec: 5 }),
  segments: Object.freeze([
    Object.freeze({
      fromSec: 0,
      toSec: 60,
      spawnRate: 1.3, // 08 K9：1.0 → 1.3
      cap: 30,
      composition: Object.freeze({ gnat: 100 }),
    }),
    Object.freeze({
      fromSec: 60,
      toSec: 120,
      spawnRate: 1.6,
      cap: 50,
      composition: Object.freeze({ gnat: 70, beetle: 30 }),
    }),
    Object.freeze({
      fromSec: 120,
      toSec: 180,
      spawnRate: 2.53, // 08 K16：2.2 → 2.53（+15%）
      cap: 80,
      composition: Object.freeze({ gnat: 50, beetle: 30, moth: 20 }),
    }),
    Object.freeze({
      fromSec: 180,
      toSec: 240,
      spawnRate: 3.22, // 08 K16：2.8 → 3.22（+15%）
      cap: 110,
      composition: Object.freeze({ gnat: 40, beetle: 30, moth: 20, snail: 10 }),
    }),
    Object.freeze({
      fromSec: 240,
      toSec: 300,
      spawnRate: 3.4,
      cap: 140,
      composition: Object.freeze({ gnat: 25, beetle: 25, moth: 20, snail: 10, sporeling: 20 }), // 08 K21：菌灵 10 → 20，蚊蚋 35 → 25
    }),
    Object.freeze({
      fromSec: 300,
      toSec: 360,
      spawnRate: 4.0,
      cap: 160,
      composition: Object.freeze({ gnat: 20, beetle: 25, moth: 20, snail: 15, sporeling: 20 }), // 08 K21：菌灵 10 → 20，蚊蚋 30 → 20
    }),
    Object.freeze({
      fromSec: 360,
      toSec: 420,
      spawnRate: 4.8,
      cap: 160, // 08 K19：200 → 160（6:30 蜗牛围墙仍只受全局硬上限 200）
      composition: Object.freeze({ gnat: 20, beetle: 20, moth: 20, snail: 15, sporeling: 25 }), // 08 K21：菌灵 15 → 25，蚊蚋 30 → 20
    }),
    // 7:00–Boss 击败（开放区间，08 K2）
    Object.freeze({
      fromSec: 420,
      toSec: null,
      spawnRate: 1.5,
      cap: 80,
      composition: Object.freeze({ gnat: 60, moth: 40 }),
    }),
  ]),
  events: Object.freeze([
    // 2:30 蚊蚋包围圈（必做）
    Object.freeze({ atSec: 150, type: 'ring', enemy: 'gnat', count: 24, radius: 350 }),
    // 4:30 灰蛾横穿
    Object.freeze({ atSec: 270, type: 'cross', enemy: 'moth', count: 16, spacing: 48 }),
    // 5:00 精英圆壳甲虫 ×1（S3 B4）
    Object.freeze({ atSec: 300, type: 'elite', enemy: 'elite_beetle', count: 1 }),
    // 6:30 蜗牛围墙（08 K12：14 只 + 朝向缺口，规则见文件头 ring.gap）
    Object.freeze({
      atSec: 390,
      type: 'ring',
      enemy: 'snail',
      count: 14,
      radius: 400,
      gap: Object.freeze({ slots: 16, skip: Object.freeze([0, 15]), anchor: 'facing' }),
    }),
  ]),
})
