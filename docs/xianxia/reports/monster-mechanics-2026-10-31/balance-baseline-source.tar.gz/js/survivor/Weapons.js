// Weapon system (03 §3.4 step 7, §3.8). Pure logic only: no Math.random, no Date.now,
// no cc/wx.
//
// Every weapon implements the same interface `{ id, index, tick(world, state, dt) }`
// and reads all numbers from data/weapons.js — no magic numbers in code. S2 ships
// all five weapons (raindrop / leaf_boomerang per 08 K8/L9, see their objects below).
// spore_shot rules (01 §6.1, 03 §3.8):
//   - lock the nearest living enemy (linear scan of enemies.active, ≤202);
//   - fire `count` projectiles in a fan centred on the aim direction, `spreadDeg` apart;
//   - each projectile pierces `pierce` enemies, lives `life` seconds;
//   - 无目标不进入冷却：with no enemy on the field the weapon does not consume cooldown
//     (so the first shot lands immediately once an enemy appears).
// umbrella_blades (01 §6.2): blades at angle = ω·t + 2πi/n around the player (no pool);
//   blade radius 16 × area, orbit radius × area; 单敌受击间隔 is per whole weapon
//   (enemy.hitAt[index]) and scaled by cooldown; knockback along player→enemy.
// dew_ring (01 §6.3): radius × area; every `interval × cooldown` seconds damages every
//   enemy inside; enemies inside get slow = max(slow, level slow) each step (enemy step
//   clears it, so leaving the ring restores speed immediately); no knockback.
// Evolution (S3 B2, 01 §8.3): once state.evolved is true every weapon reads its `evolved`
// tier from data/weapons.js instead of Lv5 (tierOf). Same mechanics as Lv5 and still scaled
// by might / cooldown / area; the only extra rules are the ones 01 spells out:
//   孢子风暴 (multiTarget) — each shot locks one of the nearest distinct enemies, surplus
//     shots aim at the nearest; 秋风叶舞 (radial) — leaves go out 360°/count apart around the
//     player (fan centred on +x), independent of facing.

import { WEAPONS, YUJIAN_LEVELS } from './data/weapons.js'
import { actualDamage, actualCooldown, hitDamage } from './Stats.js'
import { equipmentDamage } from '../xianxia/EquipmentCombat.js'
import { applySwordHit } from '../xianxia/SwordCombat.js'
import { DT } from './SimClock.js'

// Shot pool object factory + reset signature used by Projectiles / SurvivorRun.
export function makeShot() {
  return {
    slot: 0,
    uid: 0,
    castId: 0,
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    r: 6,          // 03 §3.2 弹体半径 6
    damage: 0,
    raw: 0,        // unrounded 武器档位伤害 × might (Boss 受到伤害倍率, Stats.hitDamage)
    knockback: 0,
    life: 0,
    pierceLeft: 1,
    hitUids: [],
    // leaf_boomerang only (kind 'leaf'): unlimited pierce, out → back legs.
    kind: 'spore',   // 'spore' | 'leaf'
    speed: 0,
    travelLeft: 0,   // out leg: distance still to fly before turning back
    returning: false,
    catchR: 0,       // back leg: recycled once within this distance of the player
  }
}

export function resetShot(shot, { x, y, vx, vy, damage, raw, knockback, life, pierce, sourceId }) {
  shot.castId = 0
  // Clear provenance when a pooled sword slot is reused by another weapon.
  if (sourceId !== undefined) shot.sourceId = sourceId
  else delete shot.sourceId
  shot.x = x
  shot.y = y
  shot.vx = vx
  shot.vy = vy
  shot.r = 6
  shot.damage = damage
  shot.raw = raw === undefined ? damage : raw
  shot.knockback = knockback
  shot.life = life
  shot.pierceLeft = pierce
  shot.hitUids.length = 0
  shot.kind = 'spore'
  shot.speed = 0
  shot.travelLeft = 0
  shot.returning = false
  shot.catchR = 0
}

// Leaf (boomerang) shot reset: flies `distance` along (dirX, dirY), then homes back.
export function resetLeaf(shot, { x, y, dirX, dirY, speed, distance, damage, raw, knockback, r, catchR, life }) {
  resetShot(shot, { x, y, vx: dirX * speed, vy: dirY * speed, damage, raw, knockback, life, pierce: 0 })
  shot.r = r
  shot.kind = 'leaf'
  shot.speed = speed
  shot.travelLeft = distance
  shot.catchR = catchR
}

// Raindrop zone pool object (03 §3.5 zones 池：雨滴落点 阴影 → 伤害). The landing point is
// locked when the shadow appears (01 §6.4 落点不追踪); it resolves once world.time
// reaches `at`.
export function makeZone() {
  return { slot: 0, uid: 0, kind: 'raindrop', x: 0, y: 0, r: 0, damage: 0, raw: 0, knockback: 0, bornAt: 0, at: 0 }
}

// Find the nearest living enemy to (px, py); linear scan (03 §3.6). Returns the enemy
// object or null. Ties resolve to the earliest active-table index (deterministic).
export function nearestEnemy(enemies, px, py, maxDistance = Infinity) {
  let best = null
  let bestD = Infinity
  for (let i = 0; i < enemies.count; i += 1) {
    const e = enemies.active[i]
    if (e.hp <= 0) continue
    const dx = e.x - px
    const dy = e.y - py
    const d = dx * dx + dy * dy
    if (d > maxDistance * maxDistance + 1e-7) continue
    if (d < bestD) {
      bestD = d
      best = e
    }
  }
  return best
}

// Build the fan of aim angles: `count` rays centred on `baseAngle`, `spreadRad` apart.
// count=1 → [base]; count=2 → base ± spread/2; count=3 → base-spread, base, base+spread.
export function fanAngles(baseAngle, count, spreadRad, out) {
  const start = baseAngle - (spreadRad * (count - 1)) / 2
  for (let i = 0; i < count; i += 1) {
    out[i] = start + spreadRad * i
  }
  return out
}

const DEG = Math.PI / 180

// spore_shot weapon object.
export const sporeShot = {
  id: 'spore_shot',
  index: WEAPONS.spore_shot.index,
  tick(world, state, dt) {
    const lvl = world.ruleset === 'xianxia' ? refreshTier(world, state) : tierOf('spore_shot', state)
    const range = world.ruleset === 'xianxia' ? lvl.speed * lvl.life : Infinity
    // Cooldown counts down only while there is a target (无目标不进入冷却).
    const target = nearestEnemy(world.enemies, world.player.x, world.player.y, range)
    if (!target) return
    if (state.cooldown > 0) {
      state.cooldown -= dt
      return
    }
    const might = world.stats.might
    const damage = actualDamage(lvl.damage, might)
    const px = world.player.x
    const py = world.player.y
    const angles = world.weaponAngleBuf
    if (lvl.multiTarget) {
      // 孢子风暴：k 个最近的不同敌人各一发，不足时剩余发数打向最近者（01 §6.1）。
      const targets = world.targetBuf || (world.targetBuf = [])
      const found = nearestEnemies(world.enemies, px, py, lvl.count, targets, range)
      for (let i = 0; i < lvl.count; i += 1) {
        const e = i < found ? targets[i] : targets[0]
        angles[i] = Math.atan2(e.y - py, e.x - px)
      }
    } else {
      const baseAngle = Math.atan2(target.y - py, target.x - px)
      const spreadRad = (WEAPONS.spore_shot.spreadDeg || 0) * DEG
      fanAngles(baseAngle, lvl.count, spreadRad, angles)
    }
    let fired = 0
    for (let i = 0; i < lvl.count; i += 1) {
      const shot = world.shots.acquire()
      if (!shot) break // pool full → fire fewer this tick (diag counted by caller)
      const a = angles[i]
      resetShot(shot, {
        x: world.player.x,
        y: world.player.y,
        vx: Math.cos(a) * lvl.speed,
        vy: Math.sin(a) * lvl.speed,
        damage,
        raw: lvl.damage * might,
        knockback: lvl.knockback,
        life: lvl.life,
        pierce: lvl.pierce,
      })
      fired += 1
    }
    if (fired > 0) {
      // Only consume cooldown when at least one shot actually launched.
      state.cooldown = actualCooldown(lvl.cooldown, world.stats.cooldownMul)
      world.events.push({ type: 'weaponFired', id: 'spore_shot' })
    }
  },
}

function clampLevel(id, level) {
  const max = WEAPONS[id].levels.length
  if (!(level >= 1)) return 0
  if (level > max) return max - 1
  return level - 1
}
// Current tier parameters of an equipped weapon: the evolved tier once evolved (01 §8.3),
// otherwise the (clamped) level row.
export function tierOf(id, state) {
  const def = WEAPONS[id]
  if (state.evolved && def.evolved) return def.evolved
  return def.levels[clampLevel(id, state.level)]
}

// Exported for acquisition/upgrade/evolution handlers. Also checked lazily by the
// spore weapon, so callers cannot leave a stale tier after changing classPassive.
// Repeated refreshes reuse the cache; additions never accumulate on a derived tier.
export function refreshTier(world, state) {
  const base = tierOf(state.id, state)
  const cp = world.classPassive
  const level = world.ruleset === 'xianxia' && state.id === 'spore_shot' &&
    cp?.id === 'yujian' && Number.isFinite(cp.level)
    ? Math.min(5, Math.max(0, Math.floor(cp.level))) : 0
  if (state._tierBase === base && state._tierYujian === level) return state._tier
  state._tierBase = base
  state._tierYujian = level
  if (!level) {
    state._tier = base
  } else {
    const bonus = YUJIAN_LEVELS[level - 1]
    state._tier = {
      ...base,
      life: base.life + bonus.lifeAdd,
      pierce: base.pierce + bonus.pierceAdd,
      count: Math.min(16, base.count + bonus.countAdd),
      speed: base.speed * bonus.speedMul,
      knockback: base.knockback + bonus.knockbackAdd,
    }
  }
  return state._tier
}
// The `k` nearest living enemies to (px, py), nearest first, written into `out`; returns how
// many were found (≤ k). Insertion into a k-long sorted list over enemies.active (≤202), so
// ties resolve to the earlier active-table index (deterministic) and nothing is allocated
// once `out` has grown to k.
const nearDist = new Float64Array(16)
export function nearestEnemies(enemies, px, py, k, out, maxDistance = Infinity) {
  k = Math.min(16, Math.max(0, Math.floor(k)))
  if (!k) return 0
  let n = 0
  for (let i = 0; i < enemies.count; i += 1) {
    const e = enemies.active[i]
    if (e.hp <= 0) continue
    const dx = e.x - px
    const dy = e.y - py
    const d = dx * dx + dy * dy
    if (d > maxDistance * maxDistance + 1e-7) continue
    if (n === k && d >= nearDist[n - 1]) continue
    let j = n < k ? n : k - 1
    if (n < k) n += 1
    while (j > 0 && nearDist[j - 1] > d) {
      nearDist[j] = nearDist[j - 1]
      out[j] = out[j - 1]
      j -= 1
    }
    nearDist[j] = d
    out[j] = e
  }
  return n
}

// Runtime state for one equipped weapon (run.weapons entry). All fields exist up front
// so no weapon allocates during the step loop. bladeX/bladeY/bladeCount/bladeR and
// ringR are written by the weapon each step for the presentation layer to read.
export const MAX_BLADES = 8
export function makeWeaponState(id, level = 1) {
  const state = {
    id,
    level,
    evolved: false, // 01 §8.3: true once the evolution card was chosen (tier = data evolved)
    cooldown: 0, // spore_shot: seconds until next volley; dew_ring: seconds until next pulse
    bladeCount: 0,
    bladeR: 0,
    bladeX: new Float64Array(MAX_BLADES),
    bladeY: new Float64Array(MAX_BLADES),
    ringR: 0,
    _tier: null,
    _tierBase: null,
    _tierYujian: -1,
    // Wanjian uses actual simulation ticks; combatTick is a fallback for standalone
    // worlds without a Run clock. Other weapons do not advance these fields.
    combatTick: 0,
    lastWanjianTick: -1,
    phase: 'ready',
    strikeAtTick: 0,
    readyAtTick: 0,
    castId: 0,
    castX: 0,
    castY: 0,
  }
  if (id.startsWith('sj_')) Object.assign(state, {
    lastSwordTick: -1, swordTargets: [], castDirX: 1, castDirY: 0,
    castRadius: 0, castAngleDeg: 0, castLength: 0, castWidth: 0,
    angle: 0, orbitTick: -1, orbitX: 0, orbitY: 0,
    pendingShadows: [], formations: [],
    rain: null, rainReadyAtTick: 0, evolutionInitialized: false,
    orbitContacts: new Map(), orbitWindowEndTick: 0, chargeLockAtTick: 0,
  })
  return state
}

// Exact circle test against grid candidates + the large list. Writes matching enemies
// into world.hitBuf (reused array) and returns the count. Dead/inactive are skipped.
export function enemiesInCircle(world, x, y, r) {
  const enemies = world.enemies
  const grid = world.grid
  const buf = world.queryBuf
  const out = world.hitBuf || (world.hitBuf = new Array(enemies.capacity))
  let count = 0
  const n = grid.queryCircle(x, y, r, buf)
  for (let k = 0; k < n; k += 1) {
    const e = enemies.items[buf[k]]
    if (!enemies.isActive(e) || e.hp <= 0) continue
    const rr = r + e.r
    const dx = e.x - x
    const dy = e.y - y
    if (dx * dx + dy * dy > rr * rr) continue
    out[count++] = e
  }
  const large = grid.large
  for (let k = 0; k < large.length; k += 1) {
    const e = large[k]
    if (!enemies.isActive(e) || e.hp <= 0) continue
    const rr = r + e.r
    const dx = e.x - x
    const dy = e.y - y
    if (dx * dx + dy * dy > rr * rr) continue
    out[count++] = e
  }
  return count
}

// umbrella_blades weapon object (01 §6.2).
export const umbrellaBlades = {
  id: 'umbrella_blades',
  index: WEAPONS.umbrella_blades.index,
  tick(world, state) {
    const def = WEAPONS.umbrella_blades
    const lvl = tierOf('umbrella_blades', state)
    const area = world.stats.areaMul
    const orbit = lvl.orbitRadius * area
    const bladeR = def.bladeRadius * area
    const omega = lvl.angularSpeedDeg * DEG
    const n = Math.min(lvl.count, MAX_BLADES)
    const px = world.player.x
    const py = world.player.y
    const t = world.time
    const damage = actualDamage(lvl.damage, world.stats.might)
    const interval = actualCooldown(lvl.hitInterval, world.stats.cooldownMul)
    const idx = this.index
    state.bladeCount = n
    state.bladeR = bladeR
    for (let i = 0; i < n; i += 1) {
      const a = omega * t + (2 * Math.PI * i) / n
      const bx = px + Math.cos(a) * orbit
      const by = py + Math.sin(a) * orbit
      state.bladeX[i] = bx
      state.bladeY[i] = by
      const m = enemiesInCircle(world, bx, by, bladeR)
      for (let k = 0; k < m; k += 1) {
        const e = world.hitBuf[k]
        // Per-weapon gate: a second blade touching the same enemy this step is ignored.
        if (t < e.hitAt[idx]) continue
        e.hitAt[idx] = t + interval
        e.hp -= equipmentDamage(world, e, hitDamage(e, damage, lvl.damage * world.stats.might), this.id)
        e.lastHitTime = t
        const push = lvl.knockback * (1 - e.kbRes)
        if (push > 0) {
          const dx = e.x - px
          const dy = e.y - py
          const d = Math.hypot(dx, dy) || 1
          e.kbX += (dx / d) * push
          e.kbY += (dy / d) * push
        }
      }
    }
  },
}

// dew_ring weapon object (01 §6.3).
export const dewRing = {
  id: 'dew_ring',
  index: WEAPONS.dew_ring.index,
  tick(world, state, dt) {
    const lvl = tierOf('dew_ring', state)
    const r = lvl.radius * world.stats.areaMul
    state.ringR = r
    const t = world.time
    const m = enemiesInCircle(world, world.player.x, world.player.y, r)
    // Slow: take the max of all sources, never stack.
    for (let k = 0; k < m; k += 1) {
      const e = world.hitBuf[k]
      if (lvl.slow > e.slow) e.slow = lvl.slow
    }
    if (state.cooldown > 0) {
      state.cooldown -= dt
      if (state.cooldown > 0) return
    }
    const damage = actualDamage(lvl.damage, world.stats.might)
    for (let k = 0; k < m; k += 1) {
      const e = world.hitBuf[k]
      e.hp -= equipmentDamage(world, e, hitDamage(e, damage, lvl.damage * world.stats.might), this.id)
      e.lastHitTime = t
    }
    state.cooldown += actualCooldown(lvl.interval, world.stats.cooldownMul)
  },
}

// raindrop weapon object (01 §6.4). Picks random living enemies within `range` of the
// player (several drops in one cast prefer different enemies; repeats only once every
// candidate is used), else lands at a random point 150–300 from the player. Each drop
// becomes a zone (shadow) locked at that point; Projectiles.stepZones resolves it after
// `warnSec`. Random numbers come only from world.weaponRng (`${seed}:weapon`, 03 §3.3).
export const raindrop = {
  id: 'raindrop',
  index: WEAPONS.raindrop.index,
  tick(world, state, dt) {
    if (state.cooldown > 0) {
      state.cooldown -= dt
      if (state.cooldown > 0) return
    }
    const def = WEAPONS.raindrop
    const lvl = tierOf('raindrop', state)
    const rng = world.weaponRng
    const px = world.player.x
    const py = world.player.y
    // Candidates within range (linear scan, 03 §3.6), into the reusable hit buffer.
    const enemies = world.enemies
    const cand = world.hitBuf || (world.hitBuf = new Array(enemies.capacity))
    const range2 = def.range * def.range
    let n = 0
    for (let i = 0; i < enemies.count; i += 1) {
      const e = enemies.active[i]
      if (e.hp <= 0) continue
      const dx = e.x - px
      const dy = e.y - py
      if (dx * dx + dy * dy <= range2) cand[n++] = e
    }
    const radius = lvl.radius * world.stats.areaMul
    const damage = actualDamage(lvl.damage, world.stats.might)
    let left = 0 // candidates not yet picked this cast live in cand[0..left)
    let dropped = 0
    for (let i = 0; i < lvl.count; i += 1) {
      let x
      let y
      if (n > 0) {
        if (left === 0) left = n // every candidate used → allow repeats
        const j = rng.int(0, left - 1)
        const e = cand[j]
        // Move the pick out of the unpicked range (partial Fisher–Yates).
        cand[j] = cand[left - 1]
        cand[left - 1] = e
        left -= 1
        x = e.x
        y = e.y
      } else {
        const a = rng.next() * Math.PI * 2
        const d = rng.range(def.fallbackMin, def.fallbackMax)
        x = px + Math.cos(a) * d
        y = py + Math.sin(a) * d
      }
      const z = world.zones.acquire()
      if (!z) {
        dropped += 1
        continue
      }
      z.kind = 'raindrop'
      z.x = x
      z.y = y
      z.r = radius
      z.damage = damage
      z.raw = lvl.damage * world.stats.might
      z.knockback = lvl.knockback
      z.bornAt = world.time
      z.at = world.time + def.warnSec
      world.events.push({ type: 'raindropWarn', x, y, r: radius })
    }
    if (dropped > 0 && world.diag) world.diag.dropped.zones = (world.diag.dropped.zones || 0) + dropped
    state.cooldown += actualCooldown(lvl.cooldown, world.stats.cooldownMul)
    world.events.push({ type: 'weaponFired', id: 'raindrop' })
  },
}

// leaf_boomerang weapon object (01 §6.5): throws `count` leaves along the player's
// facing, `spreadDeg` apart; max distance × area. Flight/return/hit rules live in
// Projectiles.stepProjectiles (kind 'leaf'). Pool full → fewer leaves (diag counted).
export const leafBoomerang = {
  id: 'leaf_boomerang',
  index: WEAPONS.leaf_boomerang.index,
  tick(world, state, dt) {
    if (state.cooldown > 0) {
      state.cooldown -= dt
      if (state.cooldown > 0) return
    }
    const def = WEAPONS.leaf_boomerang
    const lvl = tierOf('leaf_boomerang', state)
    const p = world.player
    let angles
    if (lvl.radial) {
      // 秋风叶舞：360°/片数 间隔向四周掷出，不依赖朝向（01 §6.5）。
      angles = fanAngles(0, lvl.count, (2 * Math.PI) / lvl.count, world.weaponAngleBuf)
    } else {
      const fx = Number.isFinite(p.dirX) ? p.dirX : 0
      const fy = Number.isFinite(p.dirY) ? p.dirY : -1
      const base = Math.atan2(fy, fx)
      angles = fanAngles(base, lvl.count, def.spreadDeg * DEG, world.weaponAngleBuf)
    }
    const damage = actualDamage(lvl.damage, world.stats.might)
    const distance = lvl.maxDistance * world.stats.areaMul
    let fired = 0
    for (let i = 0; i < lvl.count; i += 1) {
      const shot = world.shots.acquire()
      if (!shot) {
        if (world.diag) world.diag.dropped.shots = (world.diag.dropped.shots || 0) + (lvl.count - i)
        break
      }
      resetLeaf(shot, {
        x: p.x,
        y: p.y,
        dirX: Math.cos(angles[i]),
        dirY: Math.sin(angles[i]),
        speed: lvl.speed,
        distance,
        damage,
        raw: lvl.damage * world.stats.might,
        knockback: lvl.knockback,
        r: def.leafRadius,
        catchR: def.catchRadius,
        life: def.maxLife,
      })
      fired += 1
    }
    state.cooldown += actualCooldown(lvl.cooldown, world.stats.cooldownMul)
    if (fired > 0) world.events.push({ type: 'weaponFired', id: 'leaf_boomerang' })
  },
}

// Closed circle/rectangle intersection, including corner tangency. Scan active
// entities directly: no viewport/grid clipping and no retained pool references.
export function intersectsWanjian(enemy, x, y) {
  const rect = WEAPONS.wanjian.rect
  const dx = Math.max(0, Math.abs(enemy.x - x) - rect.width / 2)
  const dy = Math.max(0, Math.abs(enemy.y - y) - rect.height / 2)
  return dx * dx + dy * dy <= enemy.r * enemy.r + 1e-7
}

function wanjianView(world) {
  if (!world.wanjianView) {
    const { width, height } = WEAPONS.wanjian.rect
    // Stable object owned by logic, read-only to the UI. active only means warning;
    // remainingSec counts the current warning or cooldown, and is 0 while ready.
    world.wanjianView = { active: false, x: 0, y: 0, width, height, remainingSec: 0, phase: 'ready' }
  }
  return world.wanjianView
}

// Run must invoke on death/abandon/cleansing/disposal because those states can stop
// invoking stepWeapons entirely. Pause and levelup must NOT invoke this function.
export function cancelWanjian(world) {
  for (const state of world.weapons || []) {
    if (state.id !== 'wanjian') continue
    state.phase = 'ready'
    state.strikeAtTick = 0
    state.readyAtTick = 0
    state.cooldown = 0
  }
  if (world.wanjianView) {
    Object.assign(world.wanjianView, { active: false, phase: 'ready', remainingSec: 0 })
  }
}

export const wanjian = {
  id: 'wanjian',
  index: WEAPONS.wanjian.index,
  tick(world, state) {
    if (world.ruleset !== 'xianxia') return
    if (world.state === 'paused' || world.state === 'levelup') return
    if (world.state && world.state !== 'playing') {
      cancelWanjian(world)
      return
    }
    const tick = Number.isSafeInteger(world.simulationTick)
      ? world.simulationTick : ++state.combatTick
    if (state.lastWanjianTick === tick) return
    state.lastWanjianTick = tick
    const view = wanjianView(world)
    const def = WEAPONS.wanjian
    if (state.phase === 'warning') {
      view.remainingSec = Math.max(0, state.strikeAtTick - tick) * DT
      if (tick < state.strikeAtTick) return
      // Coefficients are percent values; stats.might already contains ×10 units
      // and any currently active pill multiplier. Do not snapshot damage at cast.
      const tier = tierOf('wanjian', state)
      const raw = tier.coefPct * world.stats.might / 10
      const damage = Math.max(1, Math.round(raw))
      let hits = 0
      for (let i = 0; i < world.enemies.count; i++) {
        const e = world.enemies.active[i]
        if (e.hp <= 0 || !intersectsWanjian(e, state.castX, state.castY)) continue
        e.hp -= equipmentDamage(world, e, hitDamage(e, damage, raw), this.id)
        e.lastHitTime = world.time
        hits++
      }
      world.events.push({
        type: 'wanjianStrike', castId: state.castId, x: state.castX, y: state.castY,
        width: def.rect.width, height: def.rect.height, hits,
      })
      state.phase = 'cooldown'
      state.readyAtTick = tick + Math.ceil(actualCooldown(tier.cooldown, world.stats.cooldownMul) / DT)
      state.cooldown = (state.readyAtTick - tick) * DT
      Object.assign(view, { active: false, phase: 'cooldown', remainingSec: state.cooldown })
      return
    }
    if (state.phase === 'cooldown') {
      state.cooldown = Math.max(0, state.readyAtTick - tick) * DT
      view.remainingSec = state.cooldown
      if (tick < state.readyAtTick) return
      state.phase = 'ready'
      view.phase = 'ready'
    }
    let hasTarget = false
    for (let i = 0; i < world.enemies.count; i++) {
      const e = world.enemies.active[i]
      if (e.hp > 0 && intersectsWanjian(e, world.player.x, world.player.y)) {
        hasTarget = true
        break
      }
    }
    if (!hasTarget) return
    state.castX = world.player.x
    state.castY = world.player.y
    state.castId++
    state.phase = 'warning'
    state.strikeAtTick = tick + Math.round(def.warnSec / DT)
    Object.assign(view, {
      active: true, phase: 'warning', x: state.castX, y: state.castY, remainingSec: def.warnSec,
    })
    world.events.push({
      type: 'wanjianWarn', castId: state.castId, strikeAtTick: state.strikeAtTick,
      x: state.castX, y: state.castY, width: def.rect.width, height: def.rect.height,
    })
  },
}

// New sword skills deliberately do not share old spore-shot passive corrections.
function cancelSwordState(state) {
  state.phase = 'ready'
  state.strikeAtTick = 0
  state.readyAtTick = 0
  state.cooldown = 0
  state.swordTargets.length = 0
  state.bladeCount = 0
  state.orbitTick = -1
  state.pendingShadows.length = 0
  state.formations.length = 0
  state.rain = null
  state.rainReadyAtTick = 0
  state.orbitContacts.clear()
  state.orbitWindowEndTick = 0
  state.chargeLockAtTick = 0
}

// Parent Run calls once after committing an evolution. Do not run this on rank
// refresh or resume: doing so would discard live attacks or restart the rain clock.
export function initializeSwordEvolution(world, state) {
  if (!state.evolved || !state.id.startsWith('sj_')) return
  const tick = Number.isSafeInteger(world.simulationTick) ? world.simulationTick : state.combatTick
  const readyAtTick = state.readyAtTick
  cancelSwordState(state)
  if (world.shots) {
    for (let i = world.shots.count - 1; i >= 0; i--) {
      const shot = world.shots.active[i]
      if (shot.sourceId === state.id) world.shots.release(shot)
    }
  }
  state.evolutionInitialized = true
  state.readyAtTick = Math.max(tick, readyAtTick)
  state.cooldown = (state.readyAtTick - tick) * DT
  if (state.id === 'sj_yujian') state.rainReadyAtTick = tick + Math.round(tierOf(state.id, state).rainCooldown / DT)
  const window = tierOf(state.id, state).windowTicks || 30
  state.orbitWindowEndTick = (Math.floor(tick / window) + 1) * window
}

// Run must also call this when it stops stepping after death/abandon/Boss ending.
// Pause and levelup preserve pending casts and must not call cancellation.
export function cancelSwordSkills(world) {
  for (const state of world.weapons || []) {
    if (state.id.startsWith('sj_')) cancelSwordState(state)
  }
}

function swordTick(world, state) {
  if (world.ruleset !== 'xianxia') return null
  if (world.player.hp <= 0 || (world.state && !['playing', 'paused', 'levelup'].includes(world.state))) {
    cancelSwordState(state)
    return null
  }
  if (world.state === 'paused' || world.state === 'levelup') return null
  const tick = Number.isSafeInteger(world.simulationTick) ? world.simulationTick : ++state.combatTick
  if (tick === state.lastSwordTick) return null
  state.lastSwordTick = tick
  return tick
}

function swordCooldown(world, state, tier, tick) {
  const seconds = actualCooldown(tier.cooldown, Math.max(.5, world.stats.cooldownMul))
  state.readyAtTick = tick + Math.ceil(seconds / DT)
  state.cooldown = (state.readyAtTick - tick) * DT
}

// Bounded nearest list; distance ties use stable entity UID rather than pool order.
function swordTargets(world, out, count, range) {
  out.length = 0
  const px = world.player.x, py = world.player.y, range2 = range * range
  for (let i = 0; i < world.enemies.count; i++) {
    const e = world.enemies.active[i]
    if (e.hp <= 0) continue
    const d = (e.x - px) ** 2 + (e.y - py) ** 2
    if (d > range2) continue
    let j = 0
    while (j < out.length) {
      const other = out[j], od = (other.x - px) ** 2 + (other.y - py) ** 2
      if (d < od || (d === od && e.uid < other.uid)) break
      j++
    }
    if (j >= count) continue
    out.splice(j, 0, e)
    if (out.length > count) out.length = count
  }
  return out.length
}

export const swordYujian = {
  id: 'sj_yujian', index: WEAPONS.sj_yujian.index,
  tick(world, state) {
    const tick = swordTick(world, state)
    if (tick === null) return
    if (state.evolved) stepSwordRain(world, state, tick)
    state.cooldown = Math.max(0, state.readyAtTick - tick) * DT
    if (state.cooldown > 0) return
    const tier = tierOf(this.id, state), targets = state.swordTargets
    const found = swordTargets(world, targets, tier.count, WEAPONS.sj_yujian.range)
    if (!found) return
    const raw = tier.damage * world.stats.might
    let fired = 0
    for (let i = 0; i < tier.count; i++) {
      const shot = world.shots.acquire()
      if (!shot) {
        if (world.diag) world.diag.dropped.shots = (world.diag.dropped.shots || 0) + tier.count - i
        break
      }
      const target = targets[i < found ? i : 0]
      const angle = Math.atan2(target.y - world.player.y, target.x - world.player.x)
      resetShot(shot, {
        x: world.player.x, y: world.player.y,
        vx: Math.cos(angle) * tier.speed, vy: Math.sin(angle) * tier.speed,
        damage: actualDamage(tier.damage, world.stats.might), raw,
        knockback: tier.knockback, life: tier.life, pierce: tier.pierce,
      })
      shot.sourceId = this.id
      shot.castId = state.castId + 1
      shot.kind = 'sword'
      fired++
    }
    targets.length = 0
    if (fired) {
      state.castId++
      swordCooldown(world, state, tier, tick)
      world.events.push({ type: 'weaponFired', id: this.id })
    }
  },
}

function stepSwordRain(world, state, tick) {
  const tier = tierOf(state.id, state)
  const interval = Math.round(tier.rainInterval / DT)
  if (!state.evolutionInitialized) {
    initializeSwordEvolution(world, state)
    return
  }
  let rain = state.rain
  if (!rain && tick >= state.rainReadyAtTick) {
    swordTargets(world, state.swordTargets, 1, tier.rainRange)
    const target = state.swordTargets[0]
    if (target) {
      const firstTick = tick + Math.round(tier.rainWarnSec / DT)
      rain = state.rain = { x: target.x, y: target.y, size: tier.rainWidth,
        castId: ++state.castId, tick, nextPulseTick: firstTick,
        endTick: firstTick + (tier.rainHits - 1) * interval + 1, pulses: 0 }
      state.rainReadyAtTick = tick + Math.round(tier.rainCooldown / DT)
      world.events.push({ type: 'swordRainWarn', x: rain.x, y: rain.y,
        size: rain.size, castId: rain.castId, tick, endTick: rain.endTick })
    }
    state.swordTargets.length = 0
  }
  if (!rain || tick < rain.nextPulseTick) return
  if (tick >= rain.endTick) { state.rain = null; return }
  const targets = state.swordTargets
  targets.length = 0
  for (let i = 0; i < world.enemies.count; i++) {
    const e = world.enemies.active[i]
    const dx = Math.max(0, Math.abs(e.x - rain.x) - rain.size / 2)
    const dy = Math.max(0, Math.abs(e.y - rain.y) - rain.size / 2)
    if (e.hp > 0 && dx * dx + dy * dy <= e.r * e.r + 1e-7) targets.push(e)
  }
  targets.sort((a, b) => a.uid - b.uid)
  for (const e of targets) {
    if (e.hp > 0) applySwordHit(world, e, tier.rainDamage * world.stats.might, state.id, rain.castId)
  }
  targets.length = 0
  world.events.push({ type: 'swordRainPulse', x: rain.x, y: rain.y,
    size: rain.size, castId: rain.castId, tick, endTick: rain.endTick })
  rain.pulses++
  // Skip missed pulse times rather than burst them all on a resumed frame.
  rain.nextPulseTick += (Math.floor((tick - rain.nextPulseTick) / interval) + 1) * interval
  if (rain.pulses >= tier.rainHits || rain.nextPulseTick >= rain.endTick) state.rain = null
}

// Closed disk/sector intersection. Outside the angular wedge, the nearest point
// is on either finite radial edge (including its endpoints), not an infinite ray.
export function intersectsSwordArc(enemy, x, y, dirX, dirY, radius, angleDeg) {
  const dx = enemy.x - x, dy = enemy.y - y
  const along = dx * dirX + dy * dirY, across = dx * -dirY + dy * dirX
  const distance = Math.hypot(along, across)
  const half = angleDeg * DEG / 2, c = Math.cos(half), s = Math.sin(half)
  const rr = enemy.r * enemy.r + 1e-7
  if (along >= distance * c) return Math.max(0, distance - radius) ** 2 <= rr
  for (const sign of [-1, 1]) {
    const edgeY = s * sign
    const t = Math.max(0, Math.min(radius, along * c + across * edgeY))
    if ((along - t * c) ** 2 + (across - t * edgeY) ** 2 <= rr) return true
  }
  return false
}

function swordArcEvent(type, world, state) {
  return { type, x: world.player.x, y: world.player.y,
    dirX: state.castDirX, dirY: state.castDirY, radius: state.castRadius,
    angleDeg: state.castAngleDeg, castId: state.castId, strikeAtTick: state.strikeAtTick }
}

export const swordArc = {
  id: 'sj_arc', index: WEAPONS.sj_arc.index,
  tick(world, state) {
    const tick = swordTick(world, state)
    if (tick === null) return
    const tier = tierOf(this.id, state), targets = state.swordTargets
    if (state.phase === 'warning') {
      if (tick < state.strikeAtTick) return
      targets.length = 0
      for (let i = 0; i < world.enemies.count; i++) {
        const e = world.enemies.active[i]
        if (e.hp > 0 && intersectsSwordArc(e, world.player.x, world.player.y,
          state.castDirX, state.castDirY, state.castRadius, state.castAngleDeg)) targets.push(e)
      }
      targets.sort((a, b) => a.uid - b.uid)
      const raw = tier.damage * world.stats.might
      for (const e of targets) {
        if (e.hp <= 0) continue
        applySwordHit(world, e, raw, this.id, state.castId)
      }
      targets.length = 0
      world.events.push(swordArcEvent('swordArcStrike', world, state))
      state.phase = 'ready'
      swordCooldown(world, state, tier, tick)
      return
    }
    state.cooldown = Math.max(0, state.readyAtTick - tick) * DT
    if (state.cooldown > 0) return
    const radius = tier.radius * world.stats.areaMul
    // Select a reachable living target independently of movement direction.
    // Include its collision radius so tangencies and large bosses remain valid.
    let target = null, nearest2 = Infinity
    for (let i = 0; i < world.enemies.count; i++) {
      const e = world.enemies.active[i]
      if (e.hp <= 0) continue
      const dx = e.x - world.player.x, dy = e.y - world.player.y
      const d2 = dx * dx + dy * dy
      if (d2 > (radius + e.r) ** 2) continue
      if (d2 < nearest2 || (d2 === nearest2 && (!target || e.uid < target.uid))) {
        target = e; nearest2 = d2
      }
    }
    if (!target) return
    let dirX = target.x - world.player.x, dirY = target.y - world.player.y
    const length = Math.hypot(dirX, dirY)
    if (length > 0) { dirX /= length; dirY /= length } else { dirX = 1; dirY = 0 }
    state.castDirX = dirX
    state.castDirY = dirY
    state.castRadius = radius
    state.castAngleDeg = tier.angleDeg
    state.castId++
    state.strikeAtTick = tick + Math.ceil(WEAPONS.sj_arc.warnSec / DT)
    state.phase = 'warning'
    world.events.push(swordArcEvent('swordArcWarn', world, state))
  },
}

// Swept orbit uses short line segments with a curvature allowance; all swords
// share the same per-enemy gate, which is not affected by cooldown reduction.
function segmentDistance2(px, py, ax, ay, bx, by) {
  const dx=bx-ax, dy=by-ay, len=dx*dx+dy*dy
  const t=len ? Math.max(0,Math.min(1,((px-ax)*dx+(py-ay)*dy)/len)) : 0
  return (px-ax-t*dx)**2+(py-ay-t*dy)**2
}
export const swordOrbit = {
  id: 'sj_wanjian',
  tick(world,state) {
    const tick=swordTick(world,state)
    if(tick===null)return
    if(state.evolved&&!state.evolutionInitialized)initializeSwordEvolution(world,state)
    const tier=tierOf(this.id,state),p=world.player
    if(state.evolved&&tick>state.orbitWindowEndTick){
      state.orbitContacts.clear()
      state.orbitWindowEndTick=Math.ceil(tick/tier.windowTicks)*tier.windowTicks
    }
    const elapsed=state.orbitTick<0?1:Math.max(1,tick-state.orbitTick)
    const advance=tier.angularSpeedDeg*DEG*elapsed*DT, start=state.angle
    const ox=state.orbitTick<0?p.x:state.orbitX,oy=state.orbitTick<0?p.y:state.orbitY
    const radius=tier.orbitRadius*world.stats.areaMul,bladeR=WEAPONS[this.id].bladeRadius*world.stats.areaMul
    const pieces=Math.max(1,Math.ceil(advance/.035),Math.ceil(Math.hypot(p.x-ox,p.y-oy)/8))
    const padding=radius*(1-Math.cos(advance/pieces/2))
    state.angle=(start+advance)%(2*Math.PI);state.orbitTick=tick;state.orbitX=p.x;state.orbitY=p.y
    state.bladeCount=tier.count;state.bladeR=bladeR
    for(let j=0;j<tier.count;j++){
      const offset=j*2*Math.PI/tier.count
      state.bladeX[j]=p.x+Math.cos(state.angle+offset)*radius
      state.bladeY[j]=p.y+Math.sin(state.angle+offset)*radius
    }
    const index=WEAPONS[this.id].index,now=tick*DT
    const targets=state.swordTargets
    targets.length=0
    for(let i=0;i<world.enemies.count;i++)targets.push(world.enemies.active[i])
    targets.sort((a,b)=>a.uid-b.uid)
    for(const e of targets){
      if(e.hp<=0||(!state.evolved&&now+1e-9<e.hitAt[index]))continue
      let hit=false
      for(let j=0;j<tier.count&&!hit;j++){
        const offset=j*2*Math.PI/tier.count
        let ax=ox+Math.cos(start+offset)*radius,ay=oy+Math.sin(start+offset)*radius
        for(let k=1;k<=pieces;k++){
          const t=k/pieces,a=start+offset+advance*t
          const bx=ox+(p.x-ox)*t+Math.cos(a)*radius,by=oy+(p.y-oy)*t+Math.sin(a)*radius
          if(segmentDistance2(e.x,e.y,ax,ay,bx,by)<=(e.r+bladeR+padding)**2){hit=true;break}
          ax=bx;ay=by
        }
      }
      if(state.evolved){
        const inner=(e.x-p.x)**2+(e.y-p.y)**2<=(tier.innerRadius*world.stats.areaMul+e.r)**2
        const damage=hit?tier.damage:inner?tier.innerDamage:0
        if(damage>0){
          const previous=state.orbitContacts.get(e.uid)
          if(!previous||damage>previous.damage)state.orbitContacts.set(e.uid,{enemy:e,uid:e.uid,damage})
        }
        continue
      }
      if(!hit)continue
      e.hitAt[index]=now+tier.hitInterval
      const raw=tier.damage*world.stats.might
      applySwordHit(world,e,raw,this.id,tick)
    }
    targets.length=0
    if(state.evolved&&tick===state.orbitWindowEndTick){
      for(const contact of state.orbitContacts.values())targets.push(contact)
      targets.sort((a,b)=>a.uid-b.uid)
      for(const contact of targets){
        const e=contact.enemy
        if(e.uid!==contact.uid||e.hp<=0||!world.enemies.isActive(e))continue
        applySwordHit(world,e,contact.damage*world.stats.might,this.id,tick)
      }
      targets.length=0
      state.orbitContacts.clear()
      state.orbitWindowEndTick=tick+tier.windowTicks
    }
  },
}
export function intersectsSwordLine(e,x,y,dx,dy,length,width){
  const rx=e.x-x,ry=e.y-y,along=rx*dx+ry*dy,across=Math.abs(rx*-dy+ry*dx)
  const a=Math.max(0,-along,along-length),b=Math.max(0,across-width/2)
  return a*a+b*b<=e.r*e.r+1e-7
}
function lineEvent(type,state){return {type,x:state.castX,y:state.castY,dirX:state.castDirX,dirY:state.castDirY,
  length:state.castLength,width:state.castWidth,castId:state.castId,strikeAtTick:state.strikeAtTick,
  ...(state.evolved?{evolved:true}:{})}}
export const swordLine = {
  id:'sj_line',
  tick(world,state){
    const tick=swordTick(world,state)
    if(tick===null)return
    const tier=tierOf(this.id,state),targets=state.swordTargets
    if(state.evolved&&state.phase==='charging'){
      updateSwordLineAim(world,state,tier)
      if(tick<state.chargeLockAtTick){
        world.events.push({...lineEvent('swordLineCharge',state),tick})
        return
      }
      state.phase='warning'
      world.events.push({...lineEvent('swordLineWarn',state),tick})
    }
    if(state.phase==='warning'){
      if(tick<state.strikeAtTick)return
      targets.length=0
      for(let i=0;i<world.enemies.count;i++){
        const e=world.enemies.active[i]
        if(e.hp>0&&intersectsSwordLine(e,state.castX,state.castY,state.castDirX,state.castDirY,state.castLength,state.castWidth))targets.push(e)
      }
      const along=e=>(e.x-state.castX)*state.castDirX+(e.y-state.castY)*state.castDirY
      targets.sort((a,b)=>along(a)-along(b)||a.uid-b.uid)
      const cap=state.evolved?targets.length:Math.min(targets.length,tier.hitCap)
      for(let i=0;i<cap;i++){
        const e=targets[i]
        const raw=tier.damage*world.stats.might
        if(e.hp>0)applySwordHit(world,e,raw,this.id,state.castId)
      }
      targets.length=0;world.events.push({...lineEvent('swordLineStrike',state),tick})
      state.phase='ready';swordCooldown(world,state,tier,tick);return
    }
    state.cooldown=Math.max(0,state.readyAtTick-tick)*DT
    if(state.cooldown>0)return
    const length=tier.length*world.stats.areaMul,width=tier.width*world.stats.areaMul
    swordTargets(world,targets,world.enemies.count,Math.min(420,length))
    const target=targets.find(e=>e.behavior==='boss'||e.behavior==='charge'||e.kind.startsWith('elite_'))||targets[0]
    if(!target)return
    const dx=target.x-world.player.x,dy=target.y-world.player.y,d=Math.hypot(dx,dy)
    state.castX=world.player.x;state.castY=world.player.y;state.castDirX=d?dx/d:1;state.castDirY=d?dy/d:0
    state.castLength=length;state.castWidth=width;state.castId++
    if(state.evolved){
      state.strikeAtTick=tick+Math.round(tier.chargeSec/DT)
      state.chargeLockAtTick=state.strikeAtTick-Math.round(tier.lockSec/DT)
      state.phase='charging';targets.length=0
      world.events.push({...lineEvent('swordLineCharge',state),tick})
      return
    }
    state.strikeAtTick=tick+Math.ceil(WEAPONS[this.id].warnSec/DT);state.phase='warning';targets.length=0
    world.events.push(lineEvent('swordLineWarn',state))
  },
}

function updateSwordLineAim(world,state,tier){
  const targets=state.swordTargets
  swordTargets(world,targets,world.enemies.count,Math.min(420,tier.length*world.stats.areaMul))
  const target=targets.find(e=>e.behavior==='boss'||e.behavior==='charge'||e.kind.startsWith('elite_'))||targets[0]
  state.castX=world.player.x;state.castY=world.player.y
  if(target){
    const dx=target.x-state.castX,dy=target.y-state.castY,d=Math.hypot(dx,dy)
    state.castDirX=d?dx/d:1;state.castDirY=d?dy/d:0
  }
  targets.length=0
}

// Area contacts use current occupants, never retained pooled enemy references.
function swordAreaTargets(world, state, area) {
  const out = state.swordTargets
  out.length = 0
  for (let i = 0; i < world.enemies.count; i++) {
    const e = world.enemies.active[i]
    if (e.hp > 0 && intersectsSwordArea(e, area, e.r)) out.push(e)
  }
  out.sort((a, b) => a.uid - b.uid)
  return out
}

function intersectsSwordArea(e, area, padding = 0) {
  if (area.circles) {
    for (const circle of area.circles) {
      if ((e.x-circle.x)**2+(e.y-circle.y)**2 <= (circle.radius+padding)**2+1e-7) return true
    }
    return false
  }
  return (e.x-area.x)**2+(e.y-area.y)**2 <= (area.radius+padding)**2+1e-7
}

function swordAreaEvent(type, area, tick) {
  return { type, x: area.x, y: area.y, radius: area.radius,
    castId: area.castId, tick, endTick: area.endTick,
    strikeAtTick: area.strikeAtTick, rank: area.rank,
    ...(area.evolved ? { evolved: true, circles: area.circles } : {}) }
}

export const swordShadow = {
  id: 'sj_shadow',
  get index() { return WEAPONS.sj_shadow.index },
  tick(world, state) {
    const tick = swordTick(world, state)
    if (tick === null) return
    const tier = tierOf(this.id, state), def = WEAPONS[this.id]
    for (let i = 0; i < state.pendingShadows.length;) {
      const mark = state.pendingShadows[i]
      if (tick < mark.strikeAtTick) { i++; continue }
      // Remove first so a lethal hit's cancellation cannot retain the mark.
      state.pendingShadows.splice(i, 1)
      for (const e of swordAreaTargets(world, state, mark)) {
        if (e.hp > 0) applySwordHit(world, e, tier.damage * world.stats.might, this.id, mark.castId)
      }
      state.swordTargets.length = 0
      world.events.push(swordAreaEvent('swordShadowStrike', mark, tick))
    }
    state.cooldown = Math.max(0, state.readyAtTick - tick) * DT
    if (state.cooldown > 0 || state.pendingShadows.length >= def.maxPending) return
    const found = swordTargets(world, state.swordTargets, 1, def.range)
    state.swordTargets.length = 0
    if (!found) return
    const strikeAtTick = tick + Math.round(def.delaySec / DT)
    const mark = { x: world.player.x, y: world.player.y,
      radius: tier.radius * world.stats.areaMul, castId: ++state.castId,
      tick, endTick: strikeAtTick, strikeAtTick, rank: state.level }
    state.pendingShadows.push(mark)
    swordCooldown(world, state, tier, tick)
    world.events.push(swordAreaEvent('swordShadowPlace', mark, tick))
  },
}

// Sample at the movement phase, not via the previous frame's enemy.slow.
// Enemy and Boss movement both need this query to avoid stale/outside slows.
export function swordFormationSlow(world, enemy) {
  if (world.ruleset !== 'xianxia' || world.player.hp <= 0 ||
    (world.state && !['playing', 'paused', 'levelup'].includes(world.state))) return 0
  let slow = 0
  for (const state of world.weapons || []) {
    if (state.id !== 'sj_formation') continue
    const tick = Number.isSafeInteger(world.simulationTick) ? world.simulationTick : state.combatTick
    for (const area of state.formations) {
      if (tick >= area.endTick) continue
      // Auras require the target's center inside the drawn boundary.
      if (!intersectsSwordArea(enemy, area)) continue
      const def = area.evolved ? WEAPONS.sj_formation.evolved : WEAPONS.sj_formation
      slow = Math.max(slow, enemy.behavior === 'boss' ? def.bossSlow : def.slow)
    }
  }
  return slow
}

export const swordFormation = {
  id: 'sj_formation',
  get index() { return WEAPONS.sj_formation.index },
  tick(world, state) {
    const tick = swordTick(world, state)
    if (tick === null) return
    const tier = tierOf(this.id, state), def = WEAPONS[this.id]
    for (let i = state.formations.length - 1; i >= 0; i--) {
      if (tick >= state.formations[i].endTick) state.formations.splice(i, 1)
    }
    state.cooldown = Math.max(0, state.readyAtTick - tick) * DT
    if (state.cooldown === 0) {
      swordTargets(world, state.swordTargets, 1, def.range)
      const target = state.swordTargets[0]
      if (target) {
        // Replacing a formation never cashes out its remaining pulses.
        if (state.formations.length >= def.maxActive) state.formations.shift()
        const area = { x: target.x, y: target.y, radius: tier.radius * world.stats.areaMul,
          castId: ++state.castId, tick, endTick: tick + Math.round(tier.duration / DT),
          strikeAtTick: tick, nextPulseTick: tick, rank: state.level }
        if (state.evolved) {
          const offset = tier.eyeOffset * world.stats.areaMul
          area.evolved = true
          area.circles = [
            { x: area.x + offset, y: area.y, radius: area.radius },
            { x: area.x - offset, y: area.y, radius: area.radius },
            { x: area.x, y: area.y + offset, radius: area.radius },
            { x: area.x, y: area.y - offset, radius: area.radius },
          ]
        }
        state.formations.push(area)
        swordCooldown(world, state, tier, tick)
        world.events.push(swordAreaEvent('swordFormationPlace', area, tick))
      }
      state.swordTargets.length = 0
    }
    const interval = Math.round(def.interval / DT)
    for (const area of state.formations) {
      if (tick < area.nextPulseTick) continue
      for (const e of swordAreaTargets(world, state, area)) {
        if (e.hp > 0) applySwordHit(world, e, tier.damage * world.stats.might, this.id, area.castId)
      }
      state.swordTargets.length = 0
      world.events.push(swordAreaEvent('swordFormationPulse', area, tick))
      // Keep the original cadence; skipped simulation time never bursts damage.
      area.nextPulseTick += (Math.floor((tick - area.nextPulseTick) / interval) + 1) * interval
    }
  },
}

// Registry of weapon objects by id.
export const WEAPON_OBJECTS = Object.freeze({
  spore_shot: sporeShot,
  umbrella_blades: umbrellaBlades,
  dew_ring: dewRing,
  raindrop,
  leaf_boomerang: leafBoomerang,
  wanjian,
  sj_yujian: swordYujian,
  sj_arc: swordArc,
  sj_wanjian: swordOrbit,
  sj_line: swordLine,
  sj_shadow: swordShadow,
  sj_formation: swordFormation,
})

// Advance all equipped weapons for one step (03 §3.4 step 7).
export function stepWeapons(world, dt) {
  if (world.ruleset === 'xianxia') {
    if (world.player.hp <= 0 || (world.state && !['playing', 'paused', 'levelup'].includes(world.state))) cancelSwordSkills(world)
    if (world.state === 'paused' || world.state === 'levelup') return
    if (world.state && world.state !== 'playing') cancelWanjian(world)
  }
  for (let i = 0; i < world.weapons.length; i += 1) {
    const w = world.weapons[i]
    const obj = WEAPON_OBJECTS[w.id]
    if (obj) obj.tick(world, w, dt)
  }
}
