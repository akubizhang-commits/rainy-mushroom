// Opt-in local playtest records. Does not choose cards or modify combat.
export function playtestRequested(search) { return new URLSearchParams(search).get('playtest') === '1' }
export function playtestConfig(search) {
  const p = new URLSearchParams(search)
  if (p.get('ruleset') !== 'xianxia' || p.get('playtest') !== '1') return null
  const route = p.get('route')
  if (!['line', 'formation'].includes(route)) return null
  return { route, seed: 'sword-balance-0', ruleset: 'xianxia', arena: 'courtyard-v1', firstRun: true,
    viewport: { width: 720, height: 1560 } }
}

export function playtestState(r) {
  return { tick: r.simulationTick, time: r.time, state: r.state,
    hp: r.player.hp, maxHp: r.player.maxHp, x: r.player.x, y: r.player.y,
    dirX: r.player.dirX, dirY: r.player.dirY, level: r.appliedLevel,
    xp: r.progression.xp, pendingLevels: r.progression.pendingLevels, stats: { ...r.stats },
    weapons: r.weapons.map(w => ({ id: w.id, level: w.level, evolved: !!w.evolved })),
    passives: { ...r.passives }, purified: r.purified, killer: r.summary().killer,
    abandoned: r.summary().abandoned }
}

export class PlaytestRecord {
  constructor(run, config, fingerprint, id) {
    this.run = run
    this.data = { format: 'sword-playtest-v1', id, sourceFingerprint: fingerprint,
      config, controller: 'interactive-unverified', complete: true,
      operations: [], choices: [], samples: [], hurt: [], damage: {} }
    this.data.initial = playtestState(run)
    this.lastSample = -1
    this.capture()
  }
  append(op) {
    // Keep a bounded record; mark loss of replayability rather than silently truncate.
    if (this.data.operations.length >= 120000) { this.data.complete = false; return }
    this.data.operations.push(op)
  }
  steps(count, x, y) {
    if (this.run.simulationTick > 120000) this.data.complete = false
    const last = this.data.operations[this.data.operations.length - 1]
    if (last?.[0] === 'step' && last[2] === x && last[3] === y) last[1] += count
    else this.append(['step', count, x, y])
  }
  choice(index, card, offer) {
    this.append(['choose', index])
    this.data.choices.push({ tick: this.run.simulationTick, time: this.run.time,
      level: this.run.appliedLevel, card: { ...card }, offer: offer.map(c => ({ ...c })) })
    this.capture(true)
  }
  abandon() { this.append(['abandon']) }
  events(events) {
    for (const e of events) {
      if (e.type === 'playerHurt' && this.data.hurt.length < 10000)
        this.data.hurt.push({ ...e, observedTick: this.run.simulationTick, time: this.run.time })
      if (e.type === 'swordDamage') {
        const key = `${e.sourceId}:${e.evolved ? 'evolved' : 'base'}:${e.targetBoss ? 'boss' : 'ordinary'}`
        this.data.damage[key] = (this.data.damage[key] || 0) + e.effectiveAmount
      }
    }
    this.capture()
  }
  capture(force = false) {
    const second = Math.floor(this.run.time)
    if ((force || second !== this.lastSample) && this.data.samples.length < 10000) {
      this.data.samples.push(playtestState(this.run)); this.lastSample = second
    }
  }
  snapshot() { return { ...this.data, final: playtestState(this.run) } }
}
