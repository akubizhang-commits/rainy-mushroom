import { EQUIPMENT_TIERS, canUseEquipmentTier, equipmentTierRequirement, isStarterEquipment } from './TowerEquipmentTiers.js'
// Pure backpack queries. Commands are quotes only; Campaign revalidates and
// commits them atomically against the live save.
import { weaponName, weaponSummary } from './TowerWeapons.js'
import { equipmentName, equipmentSummary } from './TowerEquipment.js'
import { CAMP_PILLS, cultivationAt, TOWER_RESOURCE_CAP } from './TowerProfile.js'
import { ECONOMY } from './TowerContent.js'
import { EQUIPMENT_CAPACITY } from './TowerCrafting.js'

export const INVENTORY_CATEGORIES = ['all', 'equipment', 'pill']
const tierOrder = Object.fromEntries(EQUIPMENT_TIERS.map(t => [t.id, t.order]))
const copy = value => JSON.parse(JSON.stringify(value))
const blocked = state => state.activeRun ? '战斗中仅可查看' : state.readOnly ? '档案只读，暂不能操作' : ''
export function inventoryUsage(state, id, category) {
  return (state.loadouts || []).flatMap((row, index) => row[`${category}Id`] === id
    ? [{ index, name: row.name || `配装${index + 1}` }] : [])
}
export function inventoryEntries(state, filters = {}) {
  const rows = [
    ...Object.values(state.weapons || {}).map(item => ({ item, category: 'weapon' })),
    ...Object.values(state.equipment || {}).map(item => ({ item, category: item.category })),
  ].map(({ item, category }) => ({
    id: item.id, category, item, name: category === 'weapon' ? weaponName(item) : equipmentName(item),
    shortName: (category === 'weapon' ? weaponName(item) : equipmentName(item)).split('·').at(-1),
    tier: item.tier, quality: item.quality,
    count: 1, usedBy: inventoryUsage(state, item.id, category),
    equipped: state.loadouts?.[state.selectedLoadout]?.[`${category}Id`] === item.id,
    isNew: state.inventoryMeta?.[item.id]?.seen === false,
    order: state.inventoryMeta?.[item.id]?.order ?? Number(item.id.match(/\d+$/)?.[0] || 0),
  }))
  for (const [id, pill] of Object.entries(CAMP_PILLS)) if (state.pills?.[id] > 0) {
    rows.push({ id, category: 'pill', name: pill.name, shortName: pill.name, item: pill,
      count: state.pills[id], tier: 'basic', quality: 0, usedBy: [],
      equipped: false, isNew: false, order: -1 })
  }
  return rows.filter(row => (!filters.category || filters.category === 'all' || row.category === filters.category
    || (filters.category === 'equipment' && ['weapon', 'armor', 'ring'].includes(row.category)))
    && (!filters.tier || filters.tier === 'all' || row.tier === filters.tier)
    && (!filters.quality || filters.quality === 'all' || row.quality === Number(filters.quality))
    && (!filters.status || filters.status === 'all' || (filters.status === 'equipped' ? row.equipped : row.usedBy.length > 0)))
    .sort((a, b) => (filters.sort === 'name' ? a.name.localeCompare(b.name, 'zh-CN')
      : filters.sort === 'quality' ? ((tierOrder[b.tier] ?? -1) - (tierOrder[a.tier] ?? -1) || b.quality - a.quality) : 0)
      || b.order - a.order || a.id.localeCompare(b.id))
}
export function inventoryCapacity(state) {
  return { used: Object.keys(state.weapons || {}).length + Object.keys(state.equipment || {}).length,
    max: EQUIPMENT_CAPACITY }
}
export function inventoryQuote(state, id, operation) {
  const row = inventoryEntries(state).find(row => row.id === id)
  const fail = reason => ({ ok: false, reason })
  if (!row) return fail('物品已不在背包')
  if (blocked(state)) return fail(blocked(state))
  const { item, category } = row, weapon = category === 'weapon'
  if (operation === 'use') {
    if (category !== 'pill') return fail('不是丹药')
    const c = cultivationAt(state.xp)
    if (item.healShare && state.hp >= c.maxHp) return fail('生命已满，不消耗丹药')
    if (item.xp && c.capped) return fail('修为已封顶，不消耗丹药')
    return { ok: true, action: { type: 'usePill', id } }
  }
  if (category === 'pill') return fail('丹药不可执行此操作')
  if (operation === 'unequip') {
    if (!row.equipped) return fail('此物品未穿戴')
    return { ok: true, action: { type: 'setLoadout', index: state.selectedLoadout,
      loadout: { ...copy(state.loadouts[state.selectedLoadout]), [`${category}Id`]: '' } } }
  }
  if (operation === 'equip') {
    if (row.equipped) return fail('当前配装已装备')
    if (!canUseEquipmentTier(item.tier, cultivationAt(state.xp).level)) return fail(`需${equipmentTierRequirement(item.tier)}装备`)
    return { ok: true, action: weapon
      ? { type: 'setLoadout', index: state.selectedLoadout,
        loadout: { ...copy(state.loadouts[state.selectedLoadout]), weaponId: id } }
      : { type: 'equipEquipment', category, id } }
  }
  if (operation === 'dismantle') {
    if (isStarterEquipment(item)) return fail('基础赠送装备不可分解')
    if (row.usedBy.length) return fail(`${row.usedBy.map(u => u.name).join('、')}正在使用`)
    const refund = ECONOMY.duplicate_contribution[item.quality - 1]
    if (state.contribution > TOWER_RESOURCE_CAP - refund) return fail('贡献已达存储上限')
    return { ok: true, refund, action: { type: weapon ? 'dismantleWeapon' : 'dismantleEquipment', id } }
  }
  return fail('不支持的操作')
}
export function inventoryDescription(state, row) {
  if (row.category === 'pill') {
    const pill = row.item
    return [pill.healShare
      ? `只能在非战斗状态使用该道具，恢复最大生命值的${pill.healShare * 100}%，不超过生命上限。每次使用一颗。`
      : `只能在非战斗状态使用该道具，增加${pill.xp}修为。修为达到上限后无法使用。每次使用一颗。`, pill.description]
  }
  const detail = inventoryDetail(state, row)
  return [`境界要求：${detail.requirement}`, '', '基础信息', ...detail.basic,
    ...(detail.effects.length ? ['', '效果', ...detail.effects] : []), '', detail.description]
}

/** Presentation only: realm eligibility is independent of locks, combat or read-only state. */
export function inventoryDetail(state, row) {
  const weapon = row.category === 'weapon'
  const summary = weapon ? weaponSummary(row.item) : equipmentSummary(row.item)
  const basic = [], effects = []
  if (row.quality === 0) basic.push(...summary.lines)
  else if (weapon) {
    basic.push(summary.lines[0])
    summary.lines.slice(1).forEach((line, index) => {
      (['attack', 'physical', 'magic'].includes(summary.affixes[index].type) ? basic : effects).push(line)
    })
  } else if (row.category === 'armor') {
    basic.push(...summary.lines.slice(0, 2))
    effects.push(...summary.lines.slice(2))
  } else {
    // Ring base lines: crit chance plus crit bonus or cooldown reduction.
    const baseCount = row.quality === 1 ? 1 : 2
    basic.push(...summary.lines.slice(0, baseCount))
    effects.push(...summary.lines.slice(baseCount))
  }
  return {
    name: row.shortName,
    rank: `${summary.tierName}·${summary.qualityName}`,
    requirement: equipmentTierRequirement(row.tier),
    requirementMet: canUseEquipmentTier(row.tier, cultivationAt(state.xp).level),
    basic, effects, description: summary.description,
  }
}
