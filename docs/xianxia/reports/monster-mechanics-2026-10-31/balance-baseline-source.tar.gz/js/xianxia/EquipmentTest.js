// Sword-only TEST economy. Storage is synchronous { getItem, setItem }; no formal
// save keys, platform APIs, clock, or battle RNG. All successful actions commit
// one checksummed record before publishing an immutable state.
import { sanitizeProfile, checksum } from '../survivor/SurvivorSave.js'
import { settle as settleProfile, crystalsForRun } from '../survivor/Meta.js'
import { CRYSTAL_CAP } from '../survivor/data/permanent.js'
import { equipmentDamage, normalizeEquipment } from './EquipmentCombat.js'

export const SAVE_KEY = 'xianxia.equipment-test.v1'
export const RESOURCE_CAP = 1000000
const FORMAT = 'xianxia-equipment-test'
const SCHEMA = 1
const PRICES = [30, 60, 100, 160]
const copy = (value) => JSON.parse(JSON.stringify(value))
const object = (value) => value !== null && typeof value === 'object' && !Array.isArray(value)
const integer = (value, max = Number.MAX_SAFE_INTEGER) => Number.isSafeInteger(value) && value >= 0 && value <= max
function freeze(value) {
  if (value && typeof value === 'object') {
    Object.values(value).forEach(freeze)
    Object.freeze(value)
  }
  return value
}

export const QUALITIES = freeze([
  { id: 'green', name: '下品', color: '#4D9865', weaponBasePct: 3, robeBasePct: 1, chancePct: 40, duplicateSpiritStones: 10 },
  { id: 'blue', name: '中品', color: '#397DC3', weaponBasePct: 4, robeBasePct: 2, chancePct: 35, duplicateSpiritStones: 20 },
  { id: 'purple', name: '上品', color: '#9165B8', weaponBasePct: 6, robeBasePct: 3, chancePct: 20, duplicateSpiritStones: 40 },
  { id: 'gold', name: '极品', color: '#C38A29', weaponBasePct: 8, robeBasePct: 4, chancePct: 5, duplicateSpiritStones: 80 },
])
export const ITEMS = freeze([
  { id: 'eq_sword_suwen', name: '素问剑', slot: 'weapon', description: '无条件特性，适合混搭功法。' },
  { id: 'eq_sword_qingxiao', name: '青霄剑', slot: 'weapon', description: '御剑术伤害加6个百分点；剑气斩减3个百分点。' },
  { id: 'eq_sword_zhenyue', name: '镇岳剑', slot: 'weapon', description: '对强敌伤害加6个百分点；对普通怪减3个百分点。' },
  { id: 'eq_robe_suyun', name: '素云衣', slot: 'robe', description: '共用基础法衣，只增加最大生命。' },
  { id: 'eq_charm_pingan', name: '平安佩', slot: 'charm', description: '展示装备，不影响战斗。' },
])
const BY_ID = new Map(ITEMS.map((item) => [item.id, item]))
const WEAPONS = ITEMS.filter((item) => item.slot === 'weapon')
const rank = (id) => QUALITIES.findIndex((quality) => quality.id === id)

export function makeEquipmentSnapshot(state) {
  return {
    weaponId: state.equipped.weapon,
    weaponQuality: state.collection[state.equipped.weapon],
    robeQuality: state.collection[state.equipped.robe],
    weaponLevel: state.levels.weapon,
    robeLevel: state.levels.robe,
  }
}

// Read-only presentation of the existing combat formula. A 100-point reference
// hit exposes the integer percentage without claiming an actual in-game hit/DPS.
export function compareEquipmentWeapon(state, weaponId) {
  if (BY_ID.get(weaponId)?.slot !== 'weapon' ||
      !Object.hasOwn(state?.collection || {}, weaponId)) return null
  let current, candidate
  try {
    current = normalizeEquipment(makeEquipmentSnapshot(state))
    candidate = normalizeEquipment({
      ...current, weaponId, weaponQuality: state.collection[weaponId],
    })
  } catch {
    return null
  }
  const cases = [
    ['御剑·普怪', 'sj_yujian', 'chase'],
    ['御剑·强敌', 'sj_yujian', 'charge'],
    ['剑气·普怪', 'sj_arc', 'chase'],
    ['剑气·强敌', 'sj_arc', 'charge'],
  ]
  return cases.map(([label, sourceId, behavior]) => ({
    label,
    current: equipmentDamage({ruleset:'xianxia', equipment:current}, {behavior}, 100, sourceId) - 100,
    candidate: equipmentDamage({ruleset:'xianxia', equipment:candidate}, {behavior}, 100, sourceId) - 100,
  }))
}

function fresh(seedProfile) {
  const seed = object(seedProfile) ? copy(seedProfile) : {}
  return {
    profile: { ...seed, ...sanitizeProfile(seed) },
    sand: 300, marks: 0, pity: 0,
    collection: { eq_sword_suwen: 'blue', eq_robe_suyun: 'blue', eq_charm_pingan: 'blue' },
    equipped: { weapon: 'eq_sword_suwen', robe: 'eq_robe_suyun', charm: 'eq_charm_pingan' },
    levels: { weapon: 0, robe: 0 },
    rngState: 0x6d2b79f5,
    sequence: 0, activeRun: null, lastSettledRun: 0,
    firstEndClaimed: false, firstWinClaimed: false, lastResult: null,
  }
}

function validSnapshot(snapshot) {
  return object(snapshot) && BY_ID.get(snapshot.weaponId)?.slot === 'weapon'
    && rank(snapshot.weaponQuality) >= 0 && rank(snapshot.robeQuality) >= 0
    && integer(snapshot.weaponLevel, 4) && integer(snapshot.robeLevel, 4)
}

function validState(state) {
  if (!object(state) || !object(state.profile) || !object(state.collection)
    || !object(state.equipped) || !object(state.levels)) return false
  const sanitized = sanitizeProfile(state.profile)
  if (Object.keys(sanitized).some((key) => JSON.stringify(state.profile[key]) !== JSON.stringify(sanitized[key]))) return false
  if (!integer(state.sand, RESOURCE_CAP) || !integer(state.marks, RESOURCE_CAP)
    || !integer(state.pity, 19) || !integer(state.rngState, 0xffffffff)
    || !integer(state.sequence) || !integer(state.lastSettledRun)
    || state.lastSettledRun > state.sequence
    || typeof state.firstEndClaimed !== 'boolean' || typeof state.firstWinClaimed !== 'boolean'
    || (state.firstWinClaimed && !state.firstEndClaimed)
    || !(state.lastResult === null || object(state.lastResult))) return false
  if (Object.entries(state.collection).some(([id, quality]) => !BY_ID.has(id) || rank(quality) < 0)) return false
  for (const slot of ['weapon', 'robe', 'charm']) {
    const id = state.equipped[slot]
    if (BY_ID.get(id)?.slot !== slot || !Object.hasOwn(state.collection, id)) return false
  }
  for (const id of ['eq_sword_suwen', 'eq_robe_suyun', 'eq_charm_pingan']) {
    if (rank(state.collection[id]) < rank('blue')) return false
  }
  if (!integer(state.levels.weapon, 4) || !integer(state.levels.robe, 4)) return false
  if (state.activeRun === null) return state.lastSettledRun === state.sequence
  return object(state.activeRun) && state.activeRun.runId === state.sequence
    && state.sequence === state.lastSettledRun + 1 && validSnapshot(state.activeRun.snapshot)
}

function encode(state) {
  const data = JSON.stringify(state)
  return JSON.stringify({ format: FORMAT, schema: SCHEMA, checksum: checksum(data), data })
}

// Fixed, independent 32-bit LCG. Both identity and quality consume one sample
// even on a guaranteed draw, so reload/retry has an identical stream.
function random(state) {
  state.rngState = (Math.imul(state.rngState, 1664525) + 1013904223) >>> 0
  return state.rngState / 0x100000000
}

function acquire(state, id, quality) {
  const previousQuality = state.collection[id] ?? null
  const duplicate = rank(previousQuality) >= rank(quality)
  const spiritStones = duplicate ? QUALITIES[rank(quality)].duplicateSpiritStones : 0
  if (duplicate) state.profile.crystals += spiritStones
  else state.collection[id] = quality
  return { id, quality, previousQuality, duplicate, spiritStones }
}

function fail(reason, details = {}) { return { ok: false, reason, ...details } }
function capacity(resource, cap) { return fail('capacity', { resource, cap }) }

function validSummary(summary) {
  if (!object(summary) || !['won', 'lost', 'abandoned'].includes(summary.outcome)
    || !Number.isFinite(summary.survivalSec) || summary.survivalSec < 0
    || summary.survivalSec > Number.MAX_SAFE_INTEGER) return false
  for (const key of ['purified', 'eliteDefeated', 'shinyCards']) {
    if (summary[key] !== undefined && !integer(summary[key])) return false
  }
  for (const key of ['bossDefeated', 'abandoned']) {
    if (summary[key] !== undefined && typeof summary[key] !== 'boolean') return false
  }
  return !(summary.outcome === 'won' && summary.abandoned)
}

/**
 * Constructor loads only SAVE_KEY; missing saves stay in memory until an action.
 * .state is immutable. .readOnly/.locked and .error ('' when clear) expose
 * corrupt/newer/unreadable saves; transient save-failed errors can be retried.
 * .needsRecovery exposes an interrupted run after reload.
 * .act({type,...}) returns {ok,reason,...}; no reward is published on failure.
 * beginRun returns {runId,snapshot}; settle requires that same runId and a real
 * Run.summary(), optionally tutorial:{move:true,levelUp:true}. Reloaded starts
 * require recoverAbandon (optional runId defaults to active run, zero rewards).
 * settings accepts key:sound|vibration|reduceFlash and a boolean value.
 * draw returns items:[{id,quality,previousQuality,duplicate,spiritStones}],
 * also aliased as draws; state.lastResult persists the whole successful result.
 * Capacity failures reject the entire action; TEST has no pending-reward queue.
 */
export class EquipmentTestStore {
  constructor(storage, seedProfile) {
    this.storage = storage
    this.state = freeze(fresh(seedProfile))
    this.locked = false
    this.error = ''
    this.needsRecovery = false
    this._busy = false
    let raw
    try { raw = storage.getItem(SAVE_KEY) } catch {
      this._lock('unreadable')
      return
    }
    if (raw === null || raw === undefined) return
    try {
      const record = JSON.parse(raw)
      if (!object(record) || record.format !== FORMAT || !integer(record.schema) || record.schema < 1) throw Error()
      if (record.schema > SCHEMA) {
        this._lock('newer')
        return
      }
      if (typeof record.data !== 'string' || checksum(record.data) !== record.checksum) throw Error()
      const state = JSON.parse(record.data)
      if (!validState(state)) throw Error()
      this.state = freeze(state)
      this.needsRecovery = state.activeRun !== null
    } catch { this._lock('corrupt') }
  }

  _lock(reason) {
    this.locked = true
    this.error = reason
  }

  get readOnly() { return this.locked }

  act(action) {
    if (this.locked) return fail(this.error)
    if (this._busy) return fail('busy')
    if (!object(action)) return fail('invalid-action')
    this._busy = true
    try {
      const next = copy(this.state)
      const result = this._apply(next, action)
      if (!result.ok) return result
      if (next.profile.crystals > CRYSTAL_CAP) return capacity('crystals', CRYSTAL_CAP)
      if (next.sand > RESOURCE_CAP) return capacity('sand', RESOURCE_CAP)
      if (next.marks > RESOURCE_CAP) return capacity('marks', RESOURCE_CAP)
      next.lastResult = copy(result)
      if (!validState(next)) return fail('invalid-state')
      try { this.storage.setItem(SAVE_KEY, encode(next)) } catch {
        this.error = 'save-failed'
        return fail('save-failed')
      }
      this.state = freeze(next)
      this.error = ''
      if (action.type === 'recoverAbandon') this.needsRecovery = false
      return copy(result)
    } finally { this._busy = false }
  }

  _apply(state, action) {
    switch (action.type) {
      case 'draw': {
        if (action.count !== 1 && action.count !== 10) return fail('unsupported-count')
        if (action.slot !== undefined && action.slot !== 'weapon') return fail('unsupported-slot')
        const cost = action.count * 100
        if (state.sand < cost) return fail('insufficient', { resource: 'sand', cost })
        state.sand -= cost
        const draws = []
        for (let i = 0; i < action.count; i++) {
          const id = WEAPONS[Math.floor(random(state) * WEAPONS.length)].id
          const roll = random(state) * 100
          const quality = state.pity === 19 ? 'gold'
            : roll < 40 ? 'green' : roll < 75 ? 'blue' : roll < 95 ? 'purple' : 'gold'
          state.pity = quality === 'gold' ? 0 : state.pity + 1
          state.marks++
          draws.push(acquire(state, id, quality))
        }
        return { ok: true, reason: '', type: 'draw', cost, items: draws, draws }
      }
      case 'settings': {
        if (!['sound', 'vibration', 'reduceFlash'].includes(action.key)
          || typeof action.value !== 'boolean') return fail('invalid-settings')
        state.profile.settings[action.key] = action.value
        return { ok: true, reason: '', type: 'settings', key: action.key, value: action.value }
      }
      case 'equip': {
        const item = BY_ID.get(action.id)
        if (!item) return fail('unknown-item')
        if (!Object.hasOwn(state.collection, item.id)) return fail('not-owned')
        state.equipped[item.slot] = item.id
        return { ok: true, reason: '', type: 'equip', id: item.id, slot: item.slot }
      }
      case 'refine': {
        if (!['weapon', 'robe'].includes(action.slot)) return fail('unsupported-slot')
        const level = state.levels[action.slot]
        if (level === 4) return fail('max')
        const cost = PRICES[level]
        if (state.profile.crystals < cost) return fail('insufficient', { resource: 'crystals', cost })
        state.profile.crystals -= cost
        state.levels[action.slot]++
        return { ok: true, reason: '', type: 'refine', slot: action.slot, level: level + 1, cost }
      }
      case 'exchange': {
        if (!BY_ID.has(action.id)) return fail('unknown-item')
        if (!['blue', 'gold'].includes(action.quality)) return fail('unsupported-quality')
        const cost = action.quality === 'blue' ? 12 : 40
        if (state.marks < cost) return fail('insufficient', { resource: 'marks', cost })
        state.marks -= cost
        return { ok: true, reason: '', type: 'exchange', cost, ...acquire(state, action.id, action.quality) }
      }
      case 'beginRun': {
        if (state.activeRun) return fail(this.needsRecovery ? 'recovery-required' : 'active-run')
        if (state.sequence === Number.MAX_SAFE_INTEGER) return capacity('sequence', Number.MAX_SAFE_INTEGER)
        const runId = ++state.sequence
        const snapshot = makeEquipmentSnapshot(state)
        state.activeRun = { runId, snapshot }
        return { ok: true, reason: '', type: 'beginRun', runId, snapshot }
      }
      case 'settle':
      case 'recoverAbandon': {
        const recovering = action.type === 'recoverAbandon'
        const runId = recovering && action.runId === undefined ? state.activeRun?.runId : action.runId
        if (!integer(runId) || runId === 0) return fail('invalid-run')
        if (runId <= state.lastSettledRun) return fail('already-settled')
        if (!state.activeRun || runId !== state.activeRun.runId) return fail('invalid-run')
        if (!recovering && this.needsRecovery) return fail('recovery-required')
        if (recovering && !this.needsRecovery) return fail('not-interrupted')
        const summary = recovering ? { outcome: 'lost', survivalSec: 0, abandoned: true } : action.summary
        if (!validSummary(summary)) return fail('invalid-summary')
        if (!recovering && action.tutorial !== undefined
          && (!object(action.tutorial) || Object.entries(action.tutorial).some(([key, value]) =>
            !['move', 'levelUp'].includes(key) || value !== true))) return fail('invalid-tutorial')
        const earned = crystalsForRun(summary)
        if (earned.total > CRYSTAL_CAP - state.profile.crystals) return capacity('crystals', CRYSTAL_CAP)
        if (state.profile.runs === Number.MAX_SAFE_INTEGER
          || (summary.outcome === 'won' && state.profile.wins === Number.MAX_SAFE_INTEGER)) {
          return capacity('history', Number.MAX_SAFE_INTEGER)
        }
        const sandEarned = {
          milestones: recovering ? 0 : [120, 240, 360].filter((sec) => summary.survivalSec >= sec).length * 30,
          victory: !recovering && summary.outcome === 'won' ? 30 : 0,
          firstEnd: !recovering && !state.firstEndClaimed ? 100 : 0,
          firstWin: !recovering && summary.outcome === 'won' && !state.firstWinClaimed ? 100 : 0,
        }
        sandEarned.total = Object.values(sandEarned).reduce((sum, value) => sum + value, 0)
        state.profile = settleProfile(state.profile, summary).profile
        if (!recovering && action.tutorial) Object.assign(state.profile.tutorial, action.tutorial)
        state.sand += sandEarned.total
        if (!recovering) state.firstEndClaimed = true
        if (!recovering && summary.outcome === 'won') state.firstWinClaimed = true
        state.activeRun = null
        state.lastSettledRun = runId
        return { ok: true, reason: '', type: action.type, runId, earned, sandEarned, summary: copy(summary) }
      }
      default: return fail('unknown-action')
    }
  }
}
