// Sect/tower persistent growth and camp medicine. No engine, browser or clock
// globals. The host supplies timestamps; battle serialization/rewards belong to
// the future tower controller, not this first camp/profile slice.
import { checksum } from '../survivor/SurvivorSave.js'

export const TOWER_PROFILE_KEY = 'xianxia.sect-tower.profile.v1'
export const TOWER_XP_CAP = 10920
export const TOWER_RESOURCE_CAP = 2000000000
const FORMAT = 'xianxia-sect-tower-profile'
const SCHEMA = 1
const copy = value => JSON.parse(JSON.stringify(value))
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value)
const integer = (value, max = Number.MAX_SAFE_INTEGER) =>
  Number.isSafeInteger(value) && value >= 0 && value <= max
const fail = reason => ({ ok: false, reason })

function freeze(value) {
  if (object(value) || Array.isArray(value)) {
    Object.values(value).forEach(freeze)
    Object.freeze(value)
  }
  return value
}

export const CAMP_PILLS = freeze({
  huichun: { name: '回春丹', price: 5, healShare: 0.5,
    description: '一瓶色泽青碧的丹药，以回春草、白露花佐以清晨灵露炼成。启封时草木清香微散，是行脚修士常备的疗伤之物。' },
  peiyuan: { name: '培元丹', price: 20, xp: 50,
    description: '一瓶淡金色的丹药，以黄精、灵参须与凝露芝文火温养而成。药性绵长，旧时山中弟子闭关前，常由师长赐下一瓶。' },
})

export function cultivationAt(xp, legacy = false) {
  if (!integer(xp, TOWER_XP_CAP)) throw new RangeError('Invalid tower cultivation')
  let level = 1
  while (level < 27 && xp >= 30 * level + 15 * level * level) level++
  const stage = Math.floor((level - 1) / 9), minorSteps = level - 1 - stage
  const multiplier = legacy ? 1 + 0.2 * (level - 1) / 26 : 1.08 ** minorSteps * 1.35 ** stage
  return {
    level,
    realm: level <= 9 ? '炼气' : level <= 18 ? '筑基' : '金丹',
    maxHp: legacy ? 100 * multiplier : 100 * 1.08 ** minorSteps * 1.35 ** stage,
    attackMultiplier: multiplier,
    capped: level === 27,
  }
}

function fresh(nowMs) {
  return {
    xp: 0, hp: 100, cores: 20, contribution: 300,
    pills: { huichun: 3, peiyuan: 0 },
    skills: { sj_yujian: 1 },
    restAt: nowMs,
    attemptSequence: 0,
    activeAttempt: null,
  }
}

function valid(state) {
  if (!object(state) || !integer(state.xp, TOWER_XP_CAP)
    || !integer(state.cores, TOWER_RESOURCE_CAP)
    || !integer(state.contribution, TOWER_RESOURCE_CAP)
    || !object(state.pills)
    || Object.keys(state.pills).length !== 2
    || !Object.keys(CAMP_PILLS).every(id => integer(state.pills[id], TOWER_RESOURCE_CAP))
    || !object(state.skills) || state.skills.sj_yujian !== 1
    || Object.keys(state.skills).length !== 1
    || !integer(state.restAt) || !integer(state.attemptSequence)
    || !Number.isFinite(state.hp) || state.hp < 0
    || state.hp > cultivationAt(state.xp).maxHp) return false
  if (state.activeAttempt === null) return state.hp > 0
  const attempt = state.activeAttempt
  return object(attempt) && attempt.id === state.attemptSequence
    && attempt.id > 0 && integer(attempt.startedAt)
    && attempt.startedAt <= state.restAt
}

// Advance the timestamp even at full health: unused healing time is never banked.
// A backwards clock cannot manufacture a second interval after catching up.
function rest(state, nowMs) {
  const elapsed = Math.max(0, nowMs - state.restAt)
  if (state.activeAttempt === null) {
    const maxHp = cultivationAt(state.xp).maxHp
    state.hp = Math.min(maxHp, state.hp + maxHp * 0.01 * elapsed / 60000)
  }
  state.restAt = Math.max(nowMs, state.restAt)
}

function encode(state) {
  const data = JSON.stringify(state)
  return JSON.stringify({ format: FORMAT, schema: SCHEMA, data, checksum: checksum(data) })
}

/**
 * New-mode key only, no migration and no destructive cleanup of old saves.
 * Each successful action persists before publishing the immutable state.
 * .act(action, nowMs) uses explicit integer UTC milliseconds.
 *
 * sync: apply camp/offline healing.
 * buyPill: {id, count:1..99}; usePill: {id}, consumes exactly one.
 * beginAttempt: host bridge; inherits HP and blocks camp actions.
 * finishAttempt: {attemptId, outcome:'withdrawn'|'dead'|'cleared', hp}.
 *   Trusted host reports final HP. No kill rewards/floor unlock are implemented
 *   here; this bridge does not claim to restore an interrupted battle.
 *
 * Reloading an active attempt keeps it active: no camp healing or potion use.
 * A later tower adapter must restore its matching complete combat snapshot.
 */
export class TowerProfileStore {
  constructor(storage, nowMs) {
    if (!integer(nowMs)) throw new RangeError('Invalid timestamp')
    this.storage = storage
    this.state = freeze(fresh(nowMs))
    this.error = ''
    this.readOnly = false
    this._busy = false
    let raw
    try { raw = storage.getItem(TOWER_PROFILE_KEY) } catch {
      this.error = 'unreadable'
      this.readOnly = true
      return
    }
    if (raw === null || raw === undefined) return
    try {
      const record = JSON.parse(raw)
      if (!object(record) || record.format !== FORMAT || !integer(record.schema) || record.schema < 1) throw Error()
      if (record.schema > SCHEMA) {
        this.error = 'newer'
        this.readOnly = true
        return
      }
      if (typeof record.data !== 'string' || checksum(record.data) !== record.checksum) throw Error()
      const state = JSON.parse(record.data)
      if (!valid(state)) throw Error()
      this.state = freeze(state)
    } catch {
      this.error = 'corrupt'
      this.readOnly = true
    }
  }

  act(action, nowMs) {
    if (this.readOnly) return fail(this.error)
    if (this._busy) return fail('busy')
    if (!object(action) || !integer(nowMs)) return fail('invalid-action')
    this._busy = true
    try {
      const next = copy(this.state)
      rest(next, nowMs)
      const result = this._apply(next, action)
      if (!result.ok) return result
      if (!valid(next)) return fail('invalid-state')
      try { this.storage.setItem(TOWER_PROFILE_KEY, encode(next)) } catch {
        this.error = 'save-failed'
        return fail('save-failed')
      }
      this.state = freeze(next)
      this.error = ''
      return result
    } finally {
      this._busy = false
    }
  }

  _apply(state, action) {
    if (action.type === 'sync') return { ok: true, hp: state.hp }
    if (action.type === 'finishAttempt') {
      if (state.activeAttempt === null || action.attemptId !== state.activeAttempt.id) return fail('wrong-attempt')
      if (!['withdrawn', 'dead', 'cleared'].includes(action.outcome)
        || !Number.isFinite(action.hp) || action.hp < 0
        || action.hp > cultivationAt(state.xp).maxHp
        || (action.outcome === 'dead' ? action.hp !== 0 : action.hp <= 0)) return fail('invalid-result')
      state.hp = action.outcome === 'dead' ? 1 : action.hp
      state.activeAttempt = null
      // restAt already advanced without healing the time spent in battle.
      return { ok: true, hp: state.hp, outcome: action.outcome }
    }
    if (state.activeAttempt !== null) return fail('in-tower')
    if (action.type === 'beginAttempt') {
      if (state.attemptSequence === Number.MAX_SAFE_INTEGER) return fail('capacity')
      state.attemptSequence++
      state.activeAttempt = { id: state.attemptSequence, startedAt: state.restAt }
      return { ok: true, attemptId: state.attemptSequence, hp: state.hp, xp: state.xp }
    }
    if (!['buyPill', 'usePill'].includes(action.type)) return fail('unknown-action')
    if (!Object.prototype.hasOwnProperty.call(CAMP_PILLS, action.id)) return fail('unknown-pill')
    const pill = CAMP_PILLS[action.id]
    if (action.type === 'buyPill') {
      if (!integer(action.count, 99) || action.count < 1) return fail('invalid-count')
      const cost = pill.price * action.count
      if (state.contribution < cost) return fail('insufficient')
      if (state.pills[action.id] + action.count > TOWER_RESOURCE_CAP) return fail('capacity')
      state.contribution -= cost
      state.pills[action.id] += action.count
      return { ok: true, cost, id: action.id, count: action.count }
    }
    if (state.pills[action.id] < 1) return fail('no-pill')
    if (pill.healShare) {
      const maxHp = cultivationAt(state.xp).maxHp
      if (state.hp >= maxHp) return fail('full-health')
      const healed = Math.min(maxHp - state.hp, maxHp * pill.healShare)
      state.hp = Math.min(maxHp, state.hp + healed)
      state.pills[action.id]--
      return { ok: true, id: action.id, healed }
    }
    if (state.xp >= TOWER_XP_CAP) return fail('cultivation-capped')
    const gained = Math.min(pill.xp, TOWER_XP_CAP - state.xp)
    state.xp += gained
    state.pills[action.id]--
    // Gaining maximum HP through cultivation does not heal current HP.
    return { ok: true, id: action.id, gained, cultivation: cultivationAt(state.xp) }
  }
}
