// Sword-only damage attribution and passive effects. No renderer or draft RNG access.
import { PASSIVES } from '../survivor/data/passives.js'
import { SeededRandom } from '../survivor/SurvivorRandom.js'
import { equipmentDamage } from './EquipmentCombat.js'

const DIRECT = new Set(['sj_yujian','sj_arc','sj_wanjian','sj_line','sj_shadow','sj_formation'])
const STEP = 30, LIFE = 240, GATE_COOLDOWN = 24
export function swordPassive(world, id) {
  if (world.ruleset !== 'xianxia') return null
  const level=world.passives?.[id]
  return Number.isInteger(level)&&level>0 ? PASSIVES[id]?.levels[Math.min(5,level)-1] || null : null
}
export function ensureSwordCombat(world) {
  if (!world.swordCombat) world.swordCombat={marks:new Map(),kills:[],gateReadyTick:0,lastTick:-1,eventId:0,
    rng:world._combatRng || new SeededRandom(`${world.seed ?? 'sword'}:combat`)}
  return world.swordCombat
}
export function clearSwordCombat(world) {
  const c=world.swordCombat
  if(c){c.marks.clear();c.kills.length=0;c.gateReadyTick=0;c.lastTick=-1}
}
function tickOf(world){return Number.isSafeInteger(world.simulationTick)?world.simulationTick:Math.round((world.time||0)*60)}
function active(world,enemy,uid){
  return enemy.uid===uid && enemy.hp>0 && (world.enemies.isActive ? world.enemies.isActive(enemy) : world.enemies.active.slice(0,world.enemies.count).includes(enemy))
}
function deal(world,enemy,raw,sourceId,castId,direct,critical=false){
  if(enemy.hp<=0 || !Number.isFinite(raw) || raw<=0)return 0
  const c=ensureSwordCombat(world),before=enemy.hp
  const amount=equipmentDamage(world,enemy,Math.max(1,Math.round(raw*(enemy.takenMul??1))),sourceId)
  enemy.hp-=amount;enemy.lastHitTime=world.time
  world.events.push({type:'swordDamage',sourceClass:'sword',sourceId,castId,targetUid:enemy.uid,
    targetKind:enemy.kind,targetBoss:enemy.behavior==='boss',hpBefore:before,
    effectiveAmount:Math.min(before,amount),overkillAmount:Math.max(0,amount-before),
    evolved:!!world.weapons?.find(w=>w.id===sourceId)?.evolved,
    eventId:++c.eventId,kind:direct?'direct':sourceId==='sj_mark'?'dot':'burst',direct,critical,amount,tick:tickOf(world)})
  if(direct && before>0 && enemy.hp<=0){
    c.kills.push({uid:enemy.uid,x:enemy.x,y:enemy.y,sourceId,castId,tick:tickOf(world)})
    c.marks.delete(enemy.uid)
  }
  return amount
}
export function applySwordHit(world,enemy,rawDamage,sourceId,castId=0){
  if(enemy.hp<=0)return 0
  if(world.ruleset!=='xianxia'||!DIRECT.has(sourceId)){
    const amount=equipmentDamage(world,enemy,Math.max(1,Math.round(rawDamage*(enemy.takenMul??1))),sourceId)
    enemy.hp-=amount;enemy.lastHitTime=world.time;return amount
  }
  const c=ensureSwordCombat(world),tick=tickOf(world),heart=swordPassive(world,'sj_heart')
  const critical=!!heart && c.rng.next()<heart.critChance
  const amount=deal(world,enemy,rawDamage*(critical?heart.critMultiplier:1),sourceId,castId,true,critical)
  if(critical)world.events.push({type:'swordCritical',x:enemy.x,y:enemy.y,tick})
  const mark=swordPassive(world,'sj_mark')
  if(mark&&enemy.hp>0){
    let m=c.marks.get(enemy.uid)
    if(!m){m={enemy,expires:[],nextStackTick:0};c.marks.set(enemy.uid,m)}
    m.expires=m.expires.filter(end=>end>tick)
    if(tick>=m.nextStackTick){
      if(m.expires.length>=mark.maxStacks)m.expires.shift()
      m.expires.push(tick+LIFE);m.nextStackTick=tick+STEP
    }
  }
  return amount
}
// Execute after direct attacks, before pool recycling. Gate candidates are captured
// at lethal contact and sorted by UID; secondary damage never creates candidates.
export function stepSwordEffects(world){
  if(world.ruleset!=='xianxia')return
  const c=ensureSwordCombat(world)
  if(world.player.hp<=0||!['playing','paused','levelup'].includes(world.state)){clearSwordCombat(world);return}
  if(world.state!=='playing')return
  const tick=tickOf(world)
  if(tick===c.lastTick)return
  c.lastTick=tick
  const mark=swordPassive(world,'sj_mark')
  for(const [uid,m] of Array.from(c.marks.entries()).sort((a,b)=>a[0]-b[0])){
    if(!mark||!active(world,m.enemy,uid)){c.marks.delete(uid);continue}
    m.expires=m.expires.filter(end=>end>tick)
    if(!m.expires.length){c.marks.delete(uid);continue}
    if(tick%STEP===0){
      deal(world,m.enemy,mark.damagePerSecond*world.stats.might*m.expires.length*.5,'sj_mark',0,false)
      if(m.enemy.hp<=0)c.marks.delete(uid)
    }
  }
  const bossDead=()=>world.bossEnemy?.hp<=0||world.enemies.active.slice(0,world.enemies.count).some(e=>e.behavior==='boss'&&e.hp<=0)
  const gate=swordPassive(world,'sj_gate')
  const kills=c.kills.splice(0).sort((a,b)=>a.uid-b.uid)
  if(!gate||bossDead())return
  for(const k of kills){
    if(tick<c.gateReadyTick)break
    if(c.rng.next()>=gate.chance)continue
    c.gateReadyTick=tick+GATE_COOLDOWN
    const radius=gate.radius*world.stats.areaMul
    world.events.push({type:'swordGateBurst',x:k.x,y:k.y,radius,tick})
    const targets=world.enemies.active.slice(0,world.enemies.count).filter(e=>e.hp>0).sort((a,b)=>a.uid-b.uid)
    for(const e of targets){
      if((e.x-k.x)**2+(e.y-k.y)**2>(radius+e.r)**2)continue
      deal(world,e,gate.damage*world.stats.might,'sj_gate',k.castId,false)
      if(e.hp<=0)c.marks.delete(e.uid)
      if(bossDead())return
    }
  }
}
