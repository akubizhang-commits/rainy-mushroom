// Pure, version-one kill loot. Wallet credit and persistence belong to the caller.
import { ARCHETYPES, FLOORS, FLOOR01 } from './TowerContent.js'

export const CORE_RANK_VALUES = Object.freeze([0, 1, 6, 24, 30, 36, 42, 48])

const A = Object.fromEntries(ARCHETYPES.map(a => [a.id, a]))
const TARGETS = [63, 65, 78, 87, 90, 108, 105, 110, 119]
const OLD_ELITE = [0, 3, 5, 8, 10, 12, 15, 18]
const OLD_BOSS = [0, 10, 15, 20, 25, 30, 35, 40]
const MAX_PROPOSALS = 128
const oldCredit = u => u.role === 'normal' ? .05 : (u.role === 'elite' ? OLD_ELITE : OLD_BOSS)[u.rank]

// Offline, bounded calibration of the CONDITIONED role/rank marginals.
// Columns: normal ranks 1/2/3, elite ranks 2/3/4, this floor's boss.
// Absent groups are zero. See drop-denomination-prototype.json for the raw
// oldCredit/value proposal, exact forward/backward model, and selected iterations.
const CALIBRATED = [
  [.052983194626, 0, 0, .874370124364, 0, 0, .267608641521],
  [.052799497447, 0, 0, .871424772994, 0, 0, .292009915877],
  [.049642085354, .007333211459, 0, .843462803178, .389331701977, 0, .756169654068],
  [.050478842806, .009275620053, .002627180132, .828024411430, .326278150710, .338053058016, .767059699410],
  [.050257270119, .008644929235, 0, .832102239521, .351222358409, 0, .752009242000],
  [.049980847015, .007119740176, .002837957420, 0, 0, .337775853817, .769676998684],
  [.049792888190, .007436424580, .002142665724, .836777803070, 0, .348616656353, .802969802775],
  [.050229996669, .008416445294, .002273482009, 0, .332861922291, .352636697899, .785313783274],
  [0, .008044133968, .002367126583, 0, .348793060644, .353771604917, .787362135295],
]

// Match TowerRun's authored registration, without importing combat or consuming
// its RNG. Boss-first sorting explicitly preserves the order of tied groups.
const UNITS = FLOORS.map(f => Object.freeze(f.waves.flatMap(w => {
  if (f.floor === 1) return FLOOR01.waves[w.wave - 1].batches.flatMap(b =>
    b.unit_ids.map(localId => Object.freeze({
      key: `${w.wave}:${localId}`, rank: A[b.archetype].rank, role: A[b.archetype].role,
    })))
  const groups = w.enemy_groups.map((group, index) => ({ ...group, index }))
    .sort((a, b) => Number(A[b.archetype].role === 'boss')
      - Number(A[a.archetype].role === 'boss') || a.index - b.index)
  let index = 0
  return groups.flatMap(g => Array.from({ length: g.count }, () => Object.freeze({
    key: `${w.wave}:u${++index}`, rank: A[g.archetype].rank, role: A[g.archetype].role,
  })))
})))

const TARGET_COUNTS = UNITS.map(units =>
  units.reduce((sum, u) => sum + oldCredit(u) / CORE_RANK_VALUES[u.rank], 0))

export const CORE_DROP_RULES = Object.freeze(Object.fromEntries(UNITS.map((units, index) => {
  const targetValue = TARGETS[index], row = CALIBRATED[index], expectedCount = TARGET_COUNTS[index]
  const boss = Array(8).fill(0)
  boss[units.find(u => u.role === 'boss').rank] = row[6]
  const chancesByRole = Object.freeze({
    normal: Object.freeze([0, ...row.slice(0, 3), 0, 0, 0, 0]),
    elite: Object.freeze([0, 0, ...row.slice(3, 6), 0, 0, 0]),
    boss: Object.freeze(boss),
  })
  const summaryChance = role => {
    const group = units.filter(u => u.role === role)
    return group.reduce((sum, u) => sum + chancesByRole[role][u.rank], 0) / group.length
  }
  const minValue = Math.ceil(targetValue * .9), maxValue = Math.floor(targetValue * 1.1)
  let minimumPhysicalCount = 0, maximumValue = 0
  const descending = units.map(u => CORE_RANK_VALUES[u.rank]).sort((a, b) => b - a)
  while (maximumValue < minValue) maximumValue += descending[minimumPhysicalCount++]
  const minCount = Math.max(1, minimumPhysicalCount, Math.floor(expectedCount * .5))
  return [index + 1, Object.freeze({
    floor: index + 1,
    minCount, maxCount: Math.max(minCount + 2, Math.ceil(expectedCount * 1.5)),
    minValue, maxValue, chancesByRole,
    // Count-weighted display summaries only; sampling uses the indexed arrays.
    normalChance: summaryChance('normal'), eliteChance: summaryChance('elite'),
    bossChance: summaryChance('boss'), targetValue,
  })]
})))

const GROUPS = UNITS.map((units, floorIndex) => {
  const groups = []
  units.forEach((u, index) => {
    let group = groups.find(g => g.role === u.role && g.rank === u.rank)
    if (!group) {
      const chance = CORE_DROP_RULES[floorIndex + 1].chancesByRole[u.role][u.rank]
      if (!(chance > 0 && chance < 1)) throw new Error('Uncalibrated tower loot archetype')
      group = { role: u.role, rank: u.rank, value: CORE_RANK_VALUES[u.rank],
        logMiss: Math.log1p(-chance), indices: [] }
      groups.push(group)
    }
    group.indices.push(index)
  })
  return groups
})

// At most one recent immutable result and one eight-number fallback recipe per
// floor. No seed-keyed history; evicting either never changes future results.
const recent = Array(9).fill(null)
const recipes = Array(9).fill(null)

function lootRandom(floor, seed) {
  // Domain separation plus avalanche: seed 0 is valid, not a default sentinel.
  let state = (seed ^ Math.imul(floor, 0x9e3779b9) ^ 0x434f5245) >>> 0
  state = Math.imul(state ^ (state >>> 16), 0x85ebca6b)
  state = Math.imul(state ^ (state >>> 13), 0xc2b2ae35)
  state = (state ^ (state >>> 16)) >>> 0
  return () => {
    state = (state + 0x6d2b79f5) >>> 0
    let t = Math.imul(state ^ (state >>> 15), state | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 0x100000000
  }
}

function fallbackRecipe(floor) {
  if (recipes[floor - 1]) return recipes[floor - 1]
  const units = UNITS[floor - 1], rule = CORE_DROP_RULES[floor]
  const count = rule.maxCount, value = rule.maxValue, width = value + 1
  const available = Array(8).fill(0), blocks = []
  for (const u of units) available[u.rank]++
  // Binary blocks represent every feasible quantity 0..available for each rank.
  // This bounded knapsack runs only once per floor, not once per seed.
  for (let rank = 1; rank <= 7; rank++) {
    const denomination = CORE_RANK_VALUES[rank]
    let remaining = Math.min(available[rank], count, Math.floor(value / denomination))
    for (let size = 1; remaining > 0; size *= 2) {
      const quantity = Math.min(size, remaining)
      blocks.push({ rank, quantity, value: denomination * quantity })
      remaining -= quantity
    }
  }
  const parent = new Int16Array((count + 1) * width).fill(-1)
  parent[0] = -2
  blocks.forEach((block, index) => {
    for (let c = count; c >= block.quantity; c--) {
      for (let v = value; v >= block.value; v--) {
        const at = c * width + v, previous = (c - block.quantity) * width + v - block.value
        if (parent[at] === -1 && parent[previous] !== -1) parent[at] = index
      }
    }
  })
  // Denominations have gaps: floor nine's 119 target is not representable.
  // Choose the feasible value nearest target, then count nearest old-credit
  // expected count. Both dimensions stay inside the published budget.
  let chosenCount = -1, chosenValue = -1, bestValueDistance = Infinity, bestCountDistance = Infinity
  for (let v = rule.minValue; v <= value; v++) {
    for (let c = rule.minCount; c <= count; c++) {
      if (parent[c * width + v] === -1) continue
      const dv = Math.abs(v - rule.targetValue), dc = Math.abs(c - TARGET_COUNTS[floor - 1])
      if (dv < bestValueDistance || dv === bestValueDistance && dc < bestCountDistance) {
        chosenCount = c; chosenValue = v; bestValueDistance = dv; bestCountDistance = dc
      }
    }
  }
  if (chosenCount < 0) throw new Error(`Infeasible core budget: floor ${floor}`)
  const recipe = Array(8).fill(0)
  for (let c = chosenCount, v = chosenValue; c > 0;) {
    const block = blocks[parent[c * width + v]]
    recipe[block.rank] += block.quantity
    c -= block.quantity
    v -= block.value
  }
  recipes[floor - 1] = Object.freeze(recipe)
  return recipes[floor - 1]
}

function fallback(floor, random) {
  const recipe = fallbackRecipe(floor), pools = Array.from({ length: 8 }, () => [])
  for (const unit of UNITS[floor - 1]) pools[unit.rank].push(unit)
  const selected = new Set()
  for (let rank = 1; rank <= 7; rank++) {
    const pool = pools[rank]
    // Partial Fisher-Yates chooses distinct authored units of exactly this rank.
    for (let i = 0; i < recipe[rank]; i++) {
      const j = i + Math.floor(random() * (pool.length - i))
      ;[pool[i], pool[j]] = [pool[j], pool[i]]
      selected.add(pool[i].key)
    }
  }
  return Object.fromEntries(UNITS[floor - 1].filter(u => selected.has(u.key)).map(u => [u.key, u.rank]))
}

/**
 * Return a frozen drop-only {"wave:localId": rank} object for floor 1..9 and
 * uint32 seed. The caller must persist the ORIGINAL seed and credit actual kills
 * only; partial runs are never topped up to these full-floor bounds.
 */
export function buildCoreDropPlan(floor, seed) {
  if (!Number.isInteger(floor) || floor < 1 || floor > 9
    || !Number.isInteger(seed) || seed < 0 || seed > 0xffffffff) {
    throw new RangeError('Invalid tower loot floor or seed')
  }
  if (recent[floor - 1]?.seed === seed) return recent[floor - 1].plan
  const units = UNITS[floor - 1], rule = CORE_DROP_RULES[floor]
  const random = lootRandom(floor, seed)
  let result
  for (let attempt = 0; attempt < MAX_PROPOSALS; attempt++) {
    const selected = []
    let value = 0
    // Geometric failure runs are exactly Bernoulli sampling within equal-rate
    // groups. This avoids hundreds of RNG calls for rare high-value drops.
    for (const group of GROUPS[floor - 1]) {
      let cursor = 0
      while (cursor < group.indices.length) {
        cursor += Math.floor(Math.log1p(-random()) / group.logMiss)
        if (cursor >= group.indices.length) break
        selected.push(group.indices[cursor++])
        value += group.value
      }
    }
    const count = selected.length
    if (count >= rule.minCount && count <= rule.maxCount
      && value >= rule.minValue && value <= rule.maxValue) {
      result = Object.fromEntries(selected.sort((a, b) => a - b)
        .map(index => [units[index].key, units[index].rank]))
      break
    }
  }
  const plan = Object.freeze(result ?? fallback(floor, random))
  recent[floor - 1] = { seed, plan }
  return plan
}
