// Combat-only test equipment contract. Independent of inventory, saves and UI.
const WEAPON_BASE = Object.freeze({ green: 3, blue: 4, purple: 6, gold: 8 })
const ROBE_BASE = Object.freeze({ green: 1, blue: 2, purple: 3, gold: 4 })
const WEAPON_IDS = Object.freeze(['eq_sword_suwen', 'eq_sword_qingxiao', 'eq_sword_zhenyue'])

export function normalizeEquipment(snapshot) {
  if (!snapshot || typeof snapshot !== 'object' || Array.isArray(snapshot)) {
    throw new RangeError('equipment must be a complete snapshot')
  }
  const { weaponId, weaponQuality, robeQuality, weaponLevel, robeLevel } = snapshot
  if (!WEAPON_IDS.includes(weaponId) ||
      typeof weaponQuality !== 'string' || typeof robeQuality !== 'string' ||
      !Object.hasOwn(WEAPON_BASE, weaponQuality) || !Object.hasOwn(ROBE_BASE, robeQuality) ||
      !Number.isInteger(weaponLevel) || weaponLevel < 0 || weaponLevel > 4 ||
      !Number.isInteger(robeLevel) || robeLevel < 0 || robeLevel > 4) {
    throw new RangeError('Invalid equipment snapshot')
  }
  return Object.freeze({ weaponId, weaponQuality, robeQuality, weaponLevel, robeLevel })
}

// n0 is FINAL unequipped damage, including rounding and target takenMul.
export function equipmentDamage(world, enemy, n0, sourceId) {
  const equipment = world.ruleset === 'xianxia' && world.equipment
  if (!equipment) return n0
  let trait = 0
  if (equipment.weaponId === 'eq_sword_qingxiao') {
    if (sourceId === 'sj_yujian') trait = 6
    else if (sourceId === 'sj_arc') trait = -3
  } else if (equipment.weaponId === 'eq_sword_zhenyue') {
    trait = enemy.behavior === 'charge' || enemy.behavior === 'boss' || enemy === world.bossEnemy ? 6 : -3
  }
  const ePct = Math.min(12, WEAPON_BASE[equipment.weaponQuality] + equipment.weaponLevel) + trait
  return n0 + Math.floor(n0 * ePct / 100)
}

// Only apply to freshly composed stats, so repeated recomputes cannot compound.
export function applyEquipmentStats(world, stats) {
  if (world.ruleset !== 'xianxia' || !world.equipment) return stats
  const { robeQuality, robeLevel } = world.equipment
  stats.baseMaxHp = stats.maxHp
  stats.maxHp = stats.baseMaxHp + Math.floor(stats.baseMaxHp * (ROBE_BASE[robeQuality] + robeLevel) / 100)
  return stats
}
