// Runtime class pools and display names. Historical names remain for classic compatibility.
export const WEAPON_NAMES = Object.freeze({
  sj_yujian: '御剑术',
  sj_arc: '剑气斩',
  sj_cross: '纵横剑气',
  sj_wanjian: '环剑诀',
  sj_line: '一线天',
  sj_shadow: '剑影分光',
  sj_formation: '两仪剑阵',
  spore_shot: '飞剑',
  umbrella_blades: '绕身剑阵',
  dew_ring: '玄冰诀',
  raindrop: '天雷诀',
  leaf_boomerang: '惊鸿剑气',
  wanjian: '万剑归宗',
})

// Keys are the evolution IDs from data/weapons.js, not the base weapon IDs.
export const EVOLUTION_NAMES = Object.freeze({
  spore_storm: '分光剑影',
  umbrella_canopy: '周天剑阵',
  dawn_dew_ward: '玄冰领域',
  downpour: '九霄神雷',
  autumn_leaf_dance: '惊鸿剑雨',
})

export const PASSIVE_NAMES = Object.freeze({
  sj_heart: '剑心通明',
  sj_mark: '青萍剑意',
  sj_bone: '剑骨',
  sj_gate: '剑意余震',
  might: '破军心法',
  cooldown: '清心诀',
  area: '乾坤袖',
  regen: '长青诀',
  speed: '疾风步',
  magnet: '摄灵诀',
  vajra: '金刚诀',
})

export const ENEMY_NAMES = Object.freeze({
  gnat: '妖鼠',
  beetle: '岩甲蜥',
  moth: '风狼',
  snail: '铁背玄龟',
  sporeling: '瘴气蟾',
  elite_beetle: '裂山妖犀',
  boss_mist_snail: '瘴泽蛟王',
})

export const PICKUP_NAMES = Object.freeze({
  spore: '菌孢灵光',
  dew: '小灵露',
  bigDew: '大灵露',
  wind: '聚灵风',
})

export const CLASSES = Object.freeze({
  sword: Object.freeze({
    id: 'sword',
    name: '剑修',
    startWeapon: 'sj_yujian',
    classPassive: null,
    weaponPool: Object.freeze([
      'sj_yujian', 'sj_arc', 'sj_wanjian', 'sj_line', 'sj_shadow', 'sj_formation',
    ]),
    passivePool: Object.freeze([
      'sj_heart', 'sj_mark', 'sj_bone', 'sj_gate', 'vajra', 'magnet',
    ]),
    pillPool: Object.freeze(['pill_power', 'pill_wind', 'pill_body']),
    statMul: Object.freeze({ maxHp: 1, atk: 1, moveSpeed: 1.05, pickup: 1 }),
  }),
})

const NAMES_BY_KIND = Object.freeze({
  weapon: WEAPON_NAMES,
  passive: PASSIVE_NAMES,
  enemy: ENEMY_NAMES,
  pickup: PICKUP_NAMES,
  evolution: EVOLUTION_NAMES,
})

// Supported kinds are singular. Unknown kinds/IDs pass through unchanged.
export function displayName(kind, id) {
  if (typeof kind !== 'string' || typeof id !== 'string') return id
  if (!Object.prototype.hasOwnProperty.call(NAMES_BY_KIND, kind)) return id
  const names = NAMES_BY_KIND[kind]
  return Object.prototype.hasOwnProperty.call(names, id) ? names[id] : id
}
