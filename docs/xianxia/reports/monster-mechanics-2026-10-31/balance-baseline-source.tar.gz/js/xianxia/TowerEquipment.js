// Revision 43: ring offense and armor defense. Pure item data/quotes only;
// counters, actual-loss limits, healing timers and persistence belong to combat.
import { OPEN_EQUIPMENT_TIERS, equipmentTier, isStarterEquipment } from './TowerEquipmentTiers.js'
import { EQUIPMENT_LORE } from './TowerEquipmentLore.js'
function freeze(value) {
  if (value && typeof value === 'object') {
    Object.values(value).forEach(freeze)
    Object.freeze(value)
  }
  return value
}
const catalogs = {
  armor: [
    [['qingma','青麻法衣'],['chentie','衬铁短袍'],['bichen','避尘纱衣']],
    [['yunwen','云纹道衣'],['houlin','厚鳞战袍'],['liufeng','流风法袍']],
    [['ninglu','凝露长衣'],['fushan','伏山玄衣'],['dangyu','挡雨灵衣']],
    [['shouyi','守一法衣'],['zhenyue','镇岳宝衣'],['huilan','回澜宝衣']],
    [['mingche','明澈法衣'],['humai','护脉战衣'],['jingbo','净波长袍']],
    [['yuheng','玉衡道袍'],['jinsuo','金锁灵衣'],['wuyin','雾隐法衣']],
    [['taisu','太素玄衣'],['panshi','盘石宝袍'],['xingmu','星幕灵袍']],
    [['wugou','无垢法衣'],['budong','不动宝衣'],['chengxiao','澄霄法袍']],
  ],
  ring: [
    [['anxi','凝锋木戒'],['huyuan','锐意石戒'],['dingxin','明心铜戒']],
    [['qinglu','断芒玉戒'],['wenmai','追锋灵戒'],['wenpo','破隙银戒']],
    [['huichun','贯虹碧戒'],['shoudan','切玉玄戒'],['xuxi','凌刃朱戒']],
    [['changning','破妄宝戒'],['guyuan','决锋宝戒'],['weiming','照玄宝戒']],
    [['jingshui','剑鸣灵戒'],['hanyuan','洞锋玉戒'],['huming','逐刃玄戒']],
    [['guizhen','透隙玄戒'],['ningyuan','凝锐宝戒'],['bujing','惊锋灵戒']],
    [['taihe','断岳玉戒'],['shouzhen','析芒法戒'],['zhenxin','裂空宝戒']],
    [['chengshen','烛微宝戒'],['guiyuan','观隙法戒'],['dingwei','天锋灵戒']],
  ],
}
const categoryNames = { armor: '防具', ring: '戒指' }
const tierNames = Object.fromEntries(OPEN_EQUIPMENT_TIERS.map(t => [t, equipmentTier(t).name]))
const qualityNames = ['初始','下品','中品','上品','极品']
export const EQUIPMENT = freeze(['armor','ring'].flatMap(category => [
  { id: `eq_${category}_basic`, name: category === 'armor' ? '粗布道袍' : '素银戒',
    category, tier: 'fan', qualities: [0], tags: [], description: EQUIPMENT_LORE[`eq_${category}_basic`] },
  ...catalogs[category].flatMap((names,index) => names.map(([id,name]) => ({
    id: `eq_${category}_${id}`, name, category, tier: OPEN_EQUIPMENT_TIERS[Math.floor(index / 2)], qualities: [1, 2, 3, 4], tags: [],
    description: EQUIPMENT_LORE[`eq_${category}_${id}`],
  }))),
]))
export const ARMORS = freeze(EQUIPMENT.filter(d => d.category === 'armor'))
export const RINGS = freeze(EQUIPMENT.filter(d => d.category === 'ring'))
const definitions = new Map(EQUIPMENT.map(d => [d.id,d]))
// Base-only ranges. Values are percentage points except healDelay (seconds).
// Refinement is disabled; its former share is included in the base maxima.
// Ring share is bounded for p in [0,1], q in [0,.5] by .5*C+K+focus.
export const RING_AFFIX_RANGES = freeze({
  fan: [null,
    { critChance: [.2,.5] },
    { critChance: [.3,.6], critBonus: [.1,.3], cooldownReduction: [.1,.2] },
    { critChance: [.4,.8], critBonus: [.2,.4], cooldownReduction: [.2,.3] },
    { critChance: [.5,1], critBonus: [.2,.5], focus: [.1,.2], cooldownReduction: [.2,.4] }],
  fa: [null,
    { critChance: [.5,1] },
    { critChance: [.6,1.2], critBonus: [.2,.5], cooldownReduction: [.2,.4] },
    { critChance: [.8,1.5], critBonus: [.3,.7], cooldownReduction: [.3,.6] },
    { critChance: [1,2], critBonus: [.5,1], focus: [.2,.4], cooldownReduction: [.4,.8] }],
  bao: [null,
    { critChance:[1,2] },
    { critChance:[1,2], critBonus:[.5,1.5], cooldownReduction:[.5,1] },
    { critChance:[1,3], critBonus:[1,2], cooldownReduction:[1,1.5] },
    { critChance:[1,3], critBonus:[1,2], focus:[.4,.8], cooldownReduction:[1,1.5] },
  ],
  ling: [null,
    { critChance:[3,6] },
    { critChance:[2,4], critBonus:[1,2], cooldownReduction:[1,1.5] },
    { critChance:[3,5], critBonus:[1.5,3], cooldownReduction:[1.5,2.5] },
    { critChance:[3,6], critBonus:[2,3], focus:[1,2], cooldownReduction:[2,2.5] },
  ],
})
const upperArmor = freeze({
  bao: [null,
    { hpBonus:[2,3], reduction:[.5,1.5], healFraction:[.2,.3] },
    { hpBonus:[2,4], reduction:[1,2.5], healFraction:[.3,.4] },
    { hpBonus:[3,5], reduction:[1.5,3], healFraction:[.4,.5] },
    { hpBonus:[4,6], reduction:[2,3], healFraction:[.5,.6], healDelay:[2,2] },
  ],
  ling: [null,
    { hpBonus:[4,5], reduction:[1.5,3], healFraction:[.4,.5] },
    { hpBonus:[4,6], reduction:[2.5,4], healFraction:[.5,.6] },
    { hpBonus:[5,8], reduction:[3,5], healFraction:[.6,.8] },
    { hpBonus:[6,10], reduction:[4,6], healFraction:[.8,1], healDelay:[2,2] },
  ],
})
// Early armor preserves the same recovery timings, with smaller percentages.
const scaleArmor = factor => upperArmor.bao.map(spec => spec && Object.fromEntries(
  Object.entries(spec).map(([key, bounds]) => [key, key === 'healDelay' ? bounds :
    bounds.map(n => Math.max(.1, Math.floor(n * factor * 10 + 1e-8) / 10))])))
export const ARMOR_AFFIX_RANGES = freeze({ fan: scaleArmor(.3), fa: scaleArmor(.6), ...upperArmor })
const own = (o,k) => Object.prototype.hasOwnProperty.call(o,k)
const record = v => v !== null && typeof v === 'object' && !Array.isArray(v)
const exact = (v,keys) => record(v) && Object.keys(v).length === keys.length && keys.every(k => own(v,k))
const categoryValid = c => c === 'armor' || c === 'ring'
const integer = (n,lo,hi) => Number.isInteger(n) && n >= lo && n <= hi
const validId = id => typeof id === 'string' && id.trim().length > 0 && id === id.trim()
  && !['iron','basic-armor','basic-ring'].includes(id)
const dec = n => Number(n.toFixed(12))
function specFor(category,tier,quality) { return (category === 'ring' ? RING_AFFIX_RANGES : ARMOR_AFFIX_RANGES)[tier][quality] }
function affixTypes(category,quality,cooldown = false) {
  const secondary = cooldown ? 'cooldownReduction' : 'critBonus'
  return category === 'ring' ? quality === 1 ? ['critChance'] : quality === 4
    ? ['critChance',secondary,'focus'] : ['critChance',secondary]
    : quality === 4 ? ['hpBonus','reduction','healFraction','healDelay'] : ['hpBonus','reduction','healFraction']
}
export function createBasicEquipment(category) {
  if (!categoryValid(category)) throw new RangeError('Invalid equipment category')
  return {id:`basic-${category}`,definitionId:`eq_${category}_basic`,category,
    tier:'fan',quality:0,refine:0,locked:false,affixes:[]}
}
export function rollEquipment(category,tier,quality,random,instanceId) {
  if (!categoryValid(category) || !OPEN_EQUIPMENT_TIERS.includes(tier) || !integer(quality,1,4)
    || typeof random !== 'function' || !validId(instanceId)) throw new RangeError('Invalid equipment roll arguments')
  const choose = length => {
    const n = random()
    if (typeof n !== 'number' || !Number.isFinite(n) || n < 0 || n >= 1) throw new RangeError('Equipment RNG must return [0,1)')
    return Math.floor(n * length)
  }
  const pool = EQUIPMENT.filter(d => d.category === category && d.tier === tier && d.qualities.includes(quality))
  const definition = pool[choose(pool.length)], spec = specFor(category,tier,quality)
  // CDR replaces K with equal probability; it never replaces C or the top
  // quality's focus. No extra slot and no post-roll truncation of shown values.
  const cooldown = category === 'ring' && quality >= 2 && choose(2) === 1
  const affixes = affixTypes(category,quality,cooldown).map(type => {
    const [min,max] = spec[type], lo = Math.round(min*10), hi = Math.round(max*10)
    return {type,value:(lo+choose(hi-lo+1))/10}
  })
  return {id:instanceId,definitionId:definition.id,category,tier,quality,refine:0,locked:false,affixes}
}
export function validateEquipment(instance,category) {
  if (category !== undefined && !categoryValid(category)) return false
  if (!exact(instance,['id','definitionId','category','tier','quality','refine','locked','affixes'])) return false
  const d = definitions.get(instance.definitionId)
  if (!d || instance.category !== d.category || category !== undefined && category !== d.category
    || instance.tier !== d.tier || !d.qualities.includes(instance.quality) || instance.refine !== 0
    || typeof instance.locked !== 'boolean' || !Array.isArray(instance.affixes)) return false
  if (isStarterEquipment(instance)) return instance.id === `basic-${d.category}` && instance.refine === 0 && instance.affixes.length === 0
  if (!validId(instance.id)) return false
  const cooldown = d.category === 'ring' && instance.quality >= 2
    && instance.affixes.some(a => record(a) && a.type === 'cooldownReduction')
  // HP is an optional defensive slot. Its absence means zero bonus, but never
  // permits omitting reduction, recovery, or the top-quality delay slot.
  const hasHp = instance.affixes.some(a => record(a) && a.type === 'hpBonus')
  const types = affixTypes(d.category,instance.quality,cooldown).filter(type => type !== 'hpBonus' || hasHp)
  const spec = specFor(d.category,d.tier,instance.quality)
  if (instance.affixes.length !== types.length) return false
  const seen = new Set()
  for (const a of instance.affixes) {
    if (!exact(a,['type','value']) || !types.includes(a.type) || seen.has(a.type)
      || typeof a.value !== 'number' || !Number.isFinite(a.value)
      || Math.abs(a.value*10-Math.round(a.value*10)) > 1e-8) return false
    const [min,max] = spec[a.type]
    if (a.value < min || a.value > max) return false
    seen.add(a.type)
  }
  return true
}
function checked(instance,category) {
  if (!validateEquipment(instance,category)) throw new RangeError('Invalid equipment instance')
  return definitions.get(instance.definitionId)
}
const value = (instance,type) => instance.affixes.find(a => a.type === type)?.value ?? 0
export function ringDamageModifiers(instance) {
  const d = checked(instance,'ring')
  if (isStarterEquipment(instance)) return {critChance:0,critBonus:0,special:0}
  return {critChance:value(instance,'critChance')/100,
    critBonus:value(instance,'critBonus')/100,special:value(instance,'focus')/100}
}
/** Fraction applied to eligible base cooldowns by the runtime. Never changes
 * damage per hit, projectile count, windup, hit windows or healing cooldowns.
 * Caller must not apply the same reduction twice to an evolved parent. */
export function ringCooldownReduction(instance) {
  checked(instance,'ring')
  return value(instance,'cooldownReduction')/100
}
/** Recovery is capped by actual HP lost in the triggering hit, missing HP and
 * remaining per-floor allowance. Combat owns that check, the 20s cooldown and
 * entry max-HP snapshot. No counters or pending healing are stored on the item.
 * hpBonus is a fraction, defaults to zero for an omitted HP slot, and does not
 * imply healing when the wearer changes equipment or loads a save.
 */
export function armorModifiers(instance) {
  const d = checked(instance,'armor')
  if (isStarterEquipment(instance)) return {hpBonus:0,reduction:0,healFraction:0,healDelay:0,healCooldown:0,healFloorCap:0}
  return {hpBonus:value(instance,'hpBonus')/100,
    reduction:value(instance,'reduction')/100,healFraction:value(instance,'healFraction')/100,
    healDelay:instance.quality === 4 ? value(instance,'healDelay') : 3,healCooldown:20,healFloorCap:.1}
}
export function equipmentName(instance) {
  const d = checked(instance)
  return isStarterEquipment(instance) ? `凡器·${d.name}` : `${tierNames[d.tier]}${qualityNames[instance.quality]}·${d.name}`
}
export function equipmentDescription(instance) {
  const d = checked(instance)
  if (isStarterEquipment(instance)) return ['无属性加成']
  if (d.category === 'ring') {
    const m = ringDamageModifiers(instance)
    const lines = [`直接攻击暴击率＋${dec(m.critChance*100)}个百分点`]
    if (ringCooldownReduction(instance)) lines.push(`主动功法冷却缩短${value(instance,'cooldownReduction')}%；不缩短前摇或每跳间隔`)
    else if (instance.quality >= 2) lines.push(`直接攻击暴击额外伤害＋${value(instance,'critBonus')}个百分点`)
    if (instance.quality === 4) lines.push(`会心：每第5次有效直接攻击施放，附加${value(instance,'focus')}%非暴击基准伤害；同次施放只计一次`)
    lines.push('持续伤害不暴击、不触发会心；环绕剑不累计会心次数。')
    return lines
  }
  const m = armorModifiers(instance)
  return [`最大生命增加${dec(m.hpBonus*100)}%`, `受到伤害减少${dec(m.reduction*100)}%`,
    `受伤${m.healDelay}秒后最多恢复入层最大生命的${value(instance,'healFraction')}%，不超过该次实际失血与当前缺失生命`,
    `回复冷却${m.healCooldown}秒；每层回复总量最多为入层最大生命的10%；不会复活`]
}
export function equipmentSummary(instance) {
  const d = checked(instance)
  const modifiers = d.category === 'ring' ? ringDamageModifiers(instance) : armorModifiers(instance)
  return {id:instance.id,definitionId:d.id,name:equipmentName(instance),category:d.category,
    categoryName:categoryNames[d.category],tier:d.tier,tierName:tierNames[d.tier],quality:instance.quality,
    qualityName:qualityNames[instance.quality],tags:[...d.tags],refine:instance.refine,locked:instance.locked,description:d.description,
    affixes:instance.affixes.map(a => ({...a})),modifiers,
    ...(d.category === 'ring' ? {cooldownReduction:ringCooldownReduction(instance)} : {}),
    lines:equipmentDescription(instance)}
}
