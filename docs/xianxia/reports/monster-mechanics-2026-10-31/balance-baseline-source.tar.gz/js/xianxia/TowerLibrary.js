// Read-only encyclopedia for the sect/tower mode. Values come from the same
// definitions and ranges as crafting/combat; no inventory or save is consulted.
import { CAMP_PILLS, TOWER_XP_CAP, cultivationAt } from './TowerProfile.js'
import { WEAPONS, WEAPON_BASE_ATTACK, WEAPON_AFFIX_RANGES, WEAPON_FIXED_ATTACK_RANGES } from './TowerWeapons.js'
import { EQUIPMENT, RING_AFFIX_RANGES, ARMOR_AFFIX_RANGES, armorModifiers, equipmentDescription } from './TowerEquipment.js'
import { OPEN_EQUIPMENT_TIERS, equipmentTier, equipmentTierRequirement, isStarterEquipment } from './TowerEquipmentTiers.js'

function freeze(value) {
  if (value && typeof value === 'object') {
    Object.values(value).forEach(freeze)
    Object.freeze(value)
  }
  return value
}
const number = value => String(Number(value.toFixed(12)))
const range = values => values[0] === values[1] ? number(values[0]) : `${number(values[0])}～${number(values[1])}`
const tierIsOpen = definition => OPEN_EQUIPMENT_TIERS.includes(definition.tier)
const equipmentDefinitions = new Map([...WEAPONS, ...EQUIPMENT].filter(tierIsOpen).map(d => [d.id, d]))

// Only accepted runtime art belongs here. Missing art leaves a text placeholder;
// it must never borrow another item's identity or hide its encyclopedia entry.
const illustrated = new Set([
  'eq_sword_iron', 'eq_sword_suwen', 'eq_sword_songfeng', 'eq_sword_shoushan',
  'eq_sword_guiyan', 'eq_sword_caiyun', 'eq_sword_panxi', 'eq_sword_liuquan',
  'eq_sword_ningshuang', 'eq_sword_xingluo', 'eq_armor_basic', 'eq_armor_qingma',
  'eq_ring_basic', 'eq_ring_anxi', 'eq_ring_huyuan', 'eq_ring_dingxin',
  'eq_ring_qinglu', 'eq_ring_wenmai', 'eq_ring_wenpo',
])
const affinityNames = { general: '长剑', qi: '剑气长剑', formation: '剑阵长剑' }
const categoryNames = { armor: '防具', ring: '戒指' }
export const LIBRARY_QUALITY_NAMES = freeze(['不入品', '下品', '中品', '上品', '极品'])
export const LIBRARY_VOLUMES = freeze([
  { id: 'pills', name: '丹药录', subtitle: '药性与服用' },
  { id: 'weapons', name: '兵器谱', subtitle: '锋刃与用法' },
  { id: 'equipment', name: '百器鉴', subtitle: '法衣与灵戒' },
])
export const LIBRARY_ENTRIES = freeze([
  ...Object.entries(CAMP_PILLS).map(([id, pill]) => ({
    id: `pill_${id}`, volume: 'pills', chapter: '丹药篇', name: pill.name,
    category: pill.healShare ? '疗伤丹药' : '修为丹药',
    icon: `tower-stones/pill_${id}`, description: pill.description, qualities: [0],
  })),
  ...WEAPONS.filter(tierIsOpen).map(d => ({
    id: d.id, volume: 'weapons', chapter: '长剑篇', name: d.name,
    category: `${equipmentTier(d.tier).name} · ${affinityNames[d.affinity]}`,
    icon: illustrated.has(d.id) ? `tower-equipment/${d.id}` : '',
    description: d.description, qualities: [...d.qualities],
  })),
  ...EQUIPMENT.filter(tierIsOpen).map(d => ({
    id: d.id, volume: 'equipment', chapter: d.category === 'armor' ? '防具篇' : '戒指篇', name: d.name,
    category: `${equipmentTier(d.tier).name} · ${categoryNames[d.category]}`,
    icon: illustrated.has(d.id) ? `tower-equipment/${d.id}` : '',
    description: d.description, qualities: [...d.qualities],
  })),
])
const entriesById = new Map(LIBRARY_ENTRIES.map(entry => [entry.id, entry]))

/** Detached arrays of immutable entries. Query tokens match names/categories,
 * never ownership, player level, or a different game mode's item catalogue. */
export function libraryEntries(volume, query = '', chapter = '全部') {
  const tokens = typeof query === 'string' ? query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean) : []
  return LIBRARY_ENTRIES.filter(entry => entry.volume === volume
    && (chapter === '全部' || chapter === entry.chapter)
    && tokens.every(token => `${entry.name} ${entry.category} ${entry.chapter}`.toLocaleLowerCase().includes(token)))
}
export function libraryChapters(volume) {
  return [...new Set(libraryEntries(volume).map(entry => entry.chapter))]
}

function pillDetails(entry) {
  const pill = CAMP_PILLS[entry.id.slice('pill_'.length)]
  const healing = !!pill.healShare
  return {
    summary: healing ? '恢复气血，适合再次挑战前补充生命。' : '温养根基，补充修为。',
    requirement: '境界要求：无',
    effects: [healing ? `恢复最大生命值的${number(pill.healShare * 100)}%` : `增加${number(pill.xp)}修为`],
    conditions: ['仅在宗门使用，塔内不可服用；每次消耗1颗。',
      healing ? '满血时不可服用且不消耗；恢复后的生命不超过上限。'
        : `修为上限为${cultivationAt(TOWER_XP_CAP).realm}圆满（${number(TOWER_XP_CAP)}修为）。封顶不可服用且不消耗；接近上限只获得剩余额度。`],
    tips: [healing ? '丹药按最大生命计算恢复量，先查看缺失生命，再决定服用时机。'
      : '临近修为上限时，超出上限的药力不会保留。'],
    source: `丹霞峰 · 购买丹药 · ${number(pill.price)}贡献／颗`,
    note: '丹药录收录当前宗门可用的丹药，服用操作在背包中进行。',
  }
}

function initialDetails(d, entry) {
  return {
    summary: entry.volume === 'weapons' ? '初入宗门时的基础长剑。' : '初入宗门时的基础装备。',
    requirement: '境界要求：无',
    effects: entry.volume === 'weapons' ? [`基础攻击＋${number(WEAPON_BASE_ATTACK[d.tier][0])}`] : ['无属性加成'],
    conditions: ['穿戴在对应装备位后生效。'],
    tips: ['可用作比较新装备收益的起点。'],
    source: '初始配装',
    note: '初始装备没有随机词条。',
  }
}

function weaponDetails(d, quality, common) {
  const spec = WEAPON_AFFIX_RANGES[d.tier][quality]
  const attackRange = WEAPON_FIXED_ATTACK_RANGES[d.tier][quality]
  const alternatives = [`固定攻击＋${range(attackRange)}`, `物理伤害＋${range(spec.A)}%`]
  if (d.affinity === 'formation') alternatives.push(`法术伤害＋${range(spec.A)}%`)
  const effects = [
    `基础攻击＋${number(WEAPON_BASE_ATTACK[d.tier][quality])}`,
    `基础词条随机一种：${alternatives.join('；')}。`,
    `${quality === 2 || quality === 4 ? '两条不同目标' : '一条'}功法词条：对应功法伤害＋${range(spec.S)}%。`,
  ]
  if (spec.F) effects.push(`${d.affinity === 'general' ? '剑气或剑阵' : d.affinity === 'qi' ? '剑气' : '剑阵'}流派伤害＋${range(spec.F)}%。`)
  return {
    ...common,
    summary: d.affinity === 'formation' ? '偏向剑阵功法的长剑。' : d.affinity === 'qi' ? '偏向剑气功法的长剑。' : '偏向御剑与剑影功法的长剑。',
    effects,
    conditions: ['穿戴后生效；功法与流派词条只强化对应目标。'],
    tips: ['比较基础攻击及实际词条，选择与你修习功法相符的长剑。',
      '物理、法术加成按伤害类型生效；混合伤害分别计算对应部分。'],
    source: '炼器峰 · 长剑锻造',
  }
}

// A minimal valid instance lets the existing modifier/description helpers
// supply timing and trigger rules without copying those combat constants.
function minimumEquipment(d, quality, spec, omit = []) {
  return {
    id: 'library-readonly-description', definitionId: d.id, category: d.category,
    tier: d.tier, quality, refine: 0, locked: false,
    affixes: Object.entries(spec).filter(([type]) => !omit.includes(type)).map(([type, bounds]) => ({ type, value: bounds[0] })),
  }
}
function ringDetails(d, quality, common) {
  const spec = RING_AFFIX_RANGES[d.tier][quality]
  const description = equipmentDescription(minimumEquipment(d, quality, spec, ['cooldownReduction']))
  const effects = [`直接攻击暴击率＋${range(spec.critChance)}个百分点`]
  if (spec.critBonus) effects.push(`第二词条二选一：暴击额外伤害＋${range(spec.critBonus)}个百分点，或主动功法冷却缩短${range(spec.cooldownReduction)}%。两者不会在同一枚戒指上同时出现。`)
  if (spec.focus) {
    effects.push(description.find(line => line.startsWith('会心：'))
      .replace(`附加${number(spec.focus[0])}%`, `附加${range(spec.focus)}%`))
  }
  return {
    ...common,
    summary: '强化直接攻击，品质决定可出现的词条。',
    effects,
    conditions: ['穿戴后生效。', description[description.length - 1],
      ...(spec.cooldownReduction ? ['冷却缩短不改变前摇、命中窗口或持续伤害每跳间隔。'] : [])],
    tips: ['同一名称可有不同品质与随机词条，请以背包实物比较收益。'],
    source: '炼器峰 · 戒指锻造',
  }
}
function armorDetails(d, quality, common) {
  const spec = ARMOR_AFFIX_RANGES[d.tier][quality]
  const modifiers = armorModifiers(minimumEquipment(d, quality, spec))
  return {
    ...common,
    summary: '降低承伤，并提供受伤后的有限回复。',
    effects: [
      `最大生命增加${range(spec.hpBonus)}%`,
      `受到伤害减少${range(spec.reduction)}%`,
      `受伤${number(modifiers.healDelay)}秒后，最多恢复入层最大生命的${range(spec.healFraction)}%。`,
    ],
    conditions: [
      '穿戴后生效。回复不超过该次实际失血与当前缺失生命。',
      `回复冷却${number(modifiers.healCooldown)}秒；每层回复总量最多为入层最大生命的${number(modifiers.healFloorCap * 100)}%；不会复活。`,
    ],
    tips: ['换装增加最大生命不等于立即恢复生命。',
      '若实物没有生命加成词条，该项收益为零。'],
    source: '炼器峰 · 防具锻造',
  }
}

/** Invalid IDs return null. Unsupported quality falls back to the item's first
 * allowed quality; immutable results cannot mutate the source catalogue. */
export function libraryDetails(id, quality) {
  const entry = entriesById.get(id)
  if (!entry) return null
  if (entry.volume === 'pills') return freeze(pillDetails(entry))
  const d = equipmentDefinitions.get(id)
  const selected = d.qualities.includes(quality) ? quality : d.qualities[0]
  if (isStarterEquipment({ definitionId: id, quality: selected })) return freeze(initialDetails(d, entry))
  const common = {
    requirement: `境界要求：${equipmentTierRequirement(d.tier)}`,
    note: '这里展示该品质可出现的属性范围；背包详情显示实物的实际词条。',
  }
  return freeze(entry.volume === 'weapons' ? weaponDetails(d, selected, common)
    : d.category === 'ring' ? ringDetails(d, selected, common) : armorDetails(d, selected, common))
}
