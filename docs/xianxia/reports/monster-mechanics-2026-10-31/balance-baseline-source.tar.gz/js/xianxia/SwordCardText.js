import { WEAPONS } from '../survivor/data/weapons.js'
import { PASSIVES } from '../survivor/data/passives.js'
import { WEAPON_NAMES, PASSIVE_NAMES } from './Catalog.js'

const numberText = n => String(Number(n.toFixed(3)))
const delta = (before, after) => before === undefined || before === after
  ? numberText(after) : `${numberText(before)}→${numberText(after)}`

// Shared presentation data for the S2/S3 cards. The host can use this before its
// existing S1 formatter; null leaves all other cards and classic text unchanged.
export function swordS2CardText(card, ruleset = 'survivor') {
  if (ruleset !== 'xianxia') return null
  if (card?.kind === 'evolve') return swordEvolutionText(card)
  if (!['weapon', 'passive'].includes(card?.kind)) return null
  const { id, level } = card
  const passive = card.kind === 'passive'
  const ids = passive ? ['sj_heart', 'sj_mark', 'sj_bone', 'sj_gate']
    : ['sj_wanjian', 'sj_line', 'sj_shadow', 'sj_formation']
  if (!ids.includes(id)) return null
  if (!Number.isInteger(level) || level < 1 || level > 5 || (card.isNew === true && level !== 1)) return null
  const def = passive ? PASSIVES[id] : WEAPONS[id]
  const current = def.levels[level - 1]
  const before = def.levels[level - 2]
  const value = key => delta(before?.[key], current[key])
  const scaled = (key, scale) => delta(before ? before[key] * scale : undefined, current[key] * scale)
  if (passive) {
    const descriptions = {
      sj_heart: () => [
        `暴击率${scaled('critChance', 100)}% · 暴击倍率${value('critMultiplier')}倍`,
        '直接剑技可暴击；剑痕与击杀爆发不暴击',
      ],
      sj_mark: () => [
        `剑痕上限${value('maxStacks')}层 · 每层每秒${scaled('damagePerSecond', 10)}%攻击`,
        '直接命中叠层，间隔0.5秒；每层持续4秒',
        '每0.5秒跳伤，满层刷新最早层',
        '不暴击、不叠剑痕、不触发击杀爆发',
      ],
      sj_bone: () => [
        `伤害+${scaled('might', 100)}% · 冷却缩减${scaled('cooldown', 100)}%`,
        `移动速度+${scaled('moveSpeed', 100)}%`,
        '冷却缩减合并计算，最终冷却倍率最低0.5',
      ],
      sj_gate: () => [
        `直接剑技击杀触发率${scaled('chance', 100)}% · 爆发${scaled('damage', 10)}%攻击`,
        `爆发半径${value('radius')}u · 共享0.4秒内置冷却`,
        '在敌人死亡位置爆发；不暴击、不叠剑痕、不连锁触发',
      ],
    }
    return {
      name: PASSIVE_NAMES[id],
      tag: `心法 · ${level === 1 ? '新 · Lv1' : `Lv${level - 1}→${level}`}`,
      description: descriptions[id]().join('\n'),
      kind: 'passive',
    }
  }
  const damage = scaled('damage', 10)
  if (id === 'sj_shadow' || id === 'sj_formation') {
    const description = id === 'sj_shadow' ? [
      `单次${damage}%攻击 · 爆发半径${value('radius')}u`,
      `基础冷却${value('cooldown')}秒 · 延迟${def.delaySec}秒`,
      `${def.range}u内有敌时留影，之后在原地爆发`,
      `最多${def.maxPending}处待爆；装饰剑影不增加伤害`,
    ] : [
      `每跳${damage}%攻击 · 半径${value('radius')}u`,
      `基础冷却${value('cooldown')}秒 · 持续${value('duration')}秒`,
      `${def.range}u内最近敌人处布阵，每${def.interval}秒跳伤（到期不补跳）`,
      `减速${def.slow * 100}%（首领最多${def.bossSlow * 100}%）；最多${def.maxActive}阵，替换最早阵`,
    ]
    return {
      name: WEAPON_NAMES[id],
      tag: `功法 · ${level === 1 ? '新 · Lv1' : `Lv${level - 1}→${level}`}`,
      description: description.join('\n'), kind: 'weapon',
    }
  }
  const description = id === 'sj_wanjian' ? [
    `环绕剑${value('count')}把 · 单次${damage}%攻击`,
    `轨道半径${value('orbitRadius')}u · 角速度${value('angularSpeedDeg')}°/秒`,
    `同一目标共享${value('hitInterval')}秒命中间隔，不受冷却缩减影响`,
    '增加剑数扩大覆盖；贴身有空档，不拦截敌弹',
  ].join('\n') : [
    `单次${damage}%攻击 · 最多命中${value('hitCap')}目标`,
    `长度${value('length')}u · 宽度${value('width')}u`,
    `基础冷却${value('cooldown')}秒 · 预告${def.warnSec}秒`,
    '优先瞄准范围内精英或首领；预告锁定位置与方向，按近到远贯穿',
  ].join('\n')
  return {
    name: WEAPON_NAMES[id],
    tag: `功法 · ${level === 1 ? '新 · Lv1' : `Lv${level - 1}→${level}`}`,
    description,
    kind: 'weapon',
  }
}

// New callers can use the version-neutral name; S2 hosts retain their import.
export const swordCardText = swordS2CardText

// Keep the parent skill ID on the card and the equipped instance; only its tier changes.
function swordEvolutionText(card) {
  const def = WEAPONS[card.id]
  if (!def || def.ruleset !== 'xianxia' || !def.evolved || card.level !== 6 || card.isNew === true ||
      card.evolution !== def.evolution) return null
  const tier = def.evolved
  const descriptions = {
    sj_yujian: () => [
      `替换${def.name}；保留${tier.count}剑×${tier.damage * 10}%攻击，基础冷却${tier.cooldown}秒`,
      `额外剑雨每${tier.rainCooldown}秒一次，${tier.rainWidth}×${tier.rainHeight}u固定区域`,
      `${tier.rainWarnSec}秒预告后${tier.rainHits}次各${tier.rainDamage * 10}%攻击；不随镜头移动`,
      '剑雨不受冷却缩减影响；新获得时等待完整周期',
    ],
    sj_wanjian: () => [
      `替换${def.name}；外圈单次${tier.damage * 10}%攻击`,
      `新增${tier.innerRadius}u内圈，每0.5秒${tier.innerDamage * 10}%攻击`,
      '内外圈每目标每0.5秒只取较高伤害，窗尾结算一次',
      '外圈仍需剑刃接触；内圈不减速、不免伤',
    ],
    sj_line: () => [
      `替换${def.name}；单次${tier.damage * 10}%攻击，长${tier.length}u、宽${tier.width}u`,
      `移动中蓄势${tier.chargeSec}秒，最后${tier.lockSec}秒锁定起点与方向`,
      `贯穿长度内全部目标；释放后基础冷却${tier.cooldown}秒`,
      '蓄势不受冷却缩减影响；首领正常承伤',
    ],
    sj_formation: () => [
      `替换${def.name}；${tier.eyeCount}个半径${tier.radius}u阵眼，中心各偏移${tier.eyeOffset}u`,
      `每${tier.interval}秒${tier.damage * 10}%攻击，持续${tier.duration}秒，共9跳`,
      '阵眼重叠不叠加伤害，同一目标每跳最多受击一次',
      `基础冷却${tier.cooldown}秒；减速${tier.slow * 100}%（首领最多${tier.bossSlow * 100}%），最多${tier.maxActive}组`,
    ],
  }
  if (!descriptions[card.id]) return null
  return { name: tier.name, tag: '功法 · 进化', description: descriptions[card.id]().join('\n'), kind: 'evolve' }
}
