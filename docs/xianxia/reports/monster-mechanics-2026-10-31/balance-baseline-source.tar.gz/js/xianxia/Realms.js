// E01: standalone realm/scaling rules (xianxia 00 §4 and 04 §§2–3).
// SurvivorRun xianxia ruleset integration. Values exclude classes, passives and meta bonuses.
export const REALMS = Object.freeze([
  Object.freeze({
    key: 'lianqi', name: '练气', hpBase: 100, hpStep: 3,
    attackBase: 1, attackSpeed: 1, moveMul: 1, pickupMul: 1,
  }),
  Object.freeze({
    key: 'zhuji', name: '筑基', hpBase: 150, hpStep: 4,
    attackBase: 1.3, attackSpeed: 1.1, moveMul: 1.05, pickupMul: 1.1,
  }),
  Object.freeze({
    key: 'jindan', name: '金丹', hpBase: 210, hpStep: 5,
    attackBase: 1.7, attackSpeed: 1.2, moveMul: 1.1, pickupMul: 1.2,
  }),
])

export const K = Object.freeze([1, 1.1, 1.25, 1.45, 1.55, 1.8, 1.9, 2.15])
export const D = Object.freeze([1, 1, 1, 1.25, 1.3, 1.45, 1.6, 1.75])

const LAYERS_PER_REALM = 9
const MAX_LEVEL = REALMS.length * LAYERS_PER_REALM

function finite(value, name) {
  if (!Number.isFinite(value)) throw new RangeError(`${name} must be a finite number`)
  return value
}

function nonNegative(value, name) {
  finite(value, name)
  if (value < 0) throw new RangeError(`${name} must be non-negative`)
  return value
}

// stage is zero-based; layer is 1..9. Preserve the actual floored level past 27.
export function realmAt(level) {
  finite(level, 'level')
  if (level < 1) throw new RangeError('level must be at least 1')
  const actualLevel = Math.floor(level)
  const cappedLevel = Math.min(MAX_LEVEL, actualLevel)
  const stage = Math.floor((cappedLevel - 1) / LAYERS_PER_REALM)
  const layer = (cappedLevel - 1) % LAYERS_PER_REALM + 1
  const def = REALMS[stage]
  return {
    key: def.key,
    name: def.name,
    stage,
    layer,
    level: actualLevel,
    cappedLevel,
    isMax: actualLevel >= MAX_LEVEL,
  }
}

export function realmStats(level) {
  const { stage, layer } = realmAt(level)
  const def = REALMS[stage]
  return {
    maxHp: def.hpBase + def.hpStep * (layer - 1),
    attackMul: def.attackBase * (1 + 0.02 * (layer - 1)),
    attackSpeed: def.attackSpeed,
    moveMul: def.moveMul,
    pickupMul: def.pickupMul,
  }
}

function scaleEnemy(base, growthPerMin, minute, table, unitScale) {
  nonNegative(base, 'base')
  nonNegative(growthPerMin, 'growthPerMin')
  const actualMinute = Math.max(0, Math.floor(finite(minute, 'minute')))
  // Only the compensation lookup caps at 7; ordinary growth keeps increasing.
  return base * unitScale * (1 + growthPerMin * actualMinute)
    * table[Math.min(actualMinute, table.length - 1)]
}

// Inputs use the original enemy units. Keep fractional results; do not round.
export function scaleEnemyHp(base, growthPerMin, minute) {
  return scaleEnemy(base, growthPerMin, minute, K, 10)
}

export function scaleEnemyDamage(base, growthPerMin, minute) {
  return scaleEnemy(base, growthPerMin, minute, D, 1)
}

// Boss has no ordinary per-minute growth.
export function scaleBossHp(base = 5500) {
  return nonNegative(base, 'base') * 10 * K[7]
}
