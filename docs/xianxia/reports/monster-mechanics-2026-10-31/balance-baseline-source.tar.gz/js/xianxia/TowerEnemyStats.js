import { FLOORS } from './TowerContent.js'

// Fixed authored floor/role/family stats. Never uses the player's level.
export function towerEnemyStats(archetype, floor, wave = 1) {
  const scale = FLOORS[floor - 1]?.floor_stat_scale
  if (!scale) return { hp: archetype.hp, damage: archetype.damage, moveSpeed: archetype.move_speed }
  const role = archetype.role
  const early = role === 'normal' && wave <= scale.early_normal_through_wave
    ? scale.early_normal_hp_multiplier : 1
  return {
    hp: scale[`${role}_hp`] * (archetype.floor_hp_factor ?? 1) * early,
    damage: scale[`${role}_damage`],
    moveSpeed: archetype.move_speed * (archetype.floor_speed_factor ?? 1),
  }
}
