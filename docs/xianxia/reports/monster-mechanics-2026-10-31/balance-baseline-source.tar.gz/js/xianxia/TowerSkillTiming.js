// Only cast cycles are shortened. Windups, projectile travel, zone ticks,
// orbit hit windows and triggered-effect internal cooldowns keep their timing.
import { ringCooldownReduction } from './TowerEquipment.js'

export function skillCooldown(seconds, loadout) {
  if (!Number.isFinite(seconds) || seconds <= 0) return seconds
  return seconds * (1 - (loadout?.ring ? ringCooldownReduction(loadout.ring) : 0))
}
