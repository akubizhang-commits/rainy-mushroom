// Shared presentation and transaction rules for the three independent forges.
export const CRAFTING_COSTS = Object.freeze({
  weapon: Object.freeze({ spiritStones: 100, contribution: 100 }),
  armor: Object.freeze({ spiritStones: 80, contribution: 40 }),
  ring: Object.freeze({ spiritStones: 80, contribution: 40 }),
})
export const EQUIPMENT_CAPACITY = 240

// No fixed guaranteed draw. After 15 misses, the NEXT draw gains 2 percentage
// points per miss, up to 33%. Only the common rate pays for that increase.
export function craftingRates(misses) {
  if (!Number.isSafeInteger(misses) || misses < 0) throw new RangeError('Invalid crafting misses')
  const top = misses < 15 ? 3 : Math.min(33, 3 + 2 * Math.min(15, misses - 14))
  return [(50 - top) / 100, .35, .15, top / 100]
}

export function craftingQuality(misses, roll) {
  if (!Number.isFinite(roll) || roll < 0 || roll >= 1) throw new RangeError('Invalid crafting roll')
  const rates = craftingRates(misses)
  let total = 0
  for (let i = 0; i < 3; i++) {
    total += rates[i]
    if (roll < total - 1e-12) return i + 1
  }
  return 4
}

// Public forge batches share a price across equipment pools. Ten costs nine singles.
export function forgeCost(count) {
  if (count !== 1 && count !== 10) throw new RangeError('Invalid forge count')
  const price = count === 10 ? 900 : 100
  return { spiritStones: price, contribution: price }
}
