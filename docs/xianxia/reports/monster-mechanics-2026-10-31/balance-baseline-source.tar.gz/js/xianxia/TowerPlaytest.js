// Isolate assisted play from normal progression. Uses the existing storage
// contract so Campaign retains its checksum, compare-and-swap and failure rules.
import { TOWER_CAMPAIGN_KEY } from './TowerCampaign.js'
export { PLAYTEST_STONE_CAP, PLAYTEST_RESOURCE_AMOUNT } from './TowerCampaign.js'
export const TOWER_PLAYTEST_KEY = 'xianxia.sect-tower.playtest.v1'
export const TOWER_PLAYTEST_TOOLS_KEY = 'xianxia.sect-tower.playtest-tools.v1'
export const PLAYTEST_SPEEDS = Object.freeze([1, 2, 3])
// Explicit additive labels: wallet denominations still normalize at 100:1.
export const PLAYTEST_RESOURCE_ACTIONS = Object.freeze([
  Object.freeze({ label: '+999灵石、贡献', action: Object.freeze({ type: 'playtestResources' }) }),
])
export function playtestStorage(storage, seed = null) {
  if (storage.getItem(TOWER_PLAYTEST_KEY) === null && seed !== null) storage.setItem(TOWER_PLAYTEST_KEY, seed)
  const key = value => {
    if (value !== TOWER_CAMPAIGN_KEY) throw new TypeError('Unknown playtest record')
    return TOWER_PLAYTEST_KEY
  }
  return {
    allowPlaytestTools: true,
    getItem: value => storage.getItem(key(value)),
    setItem: (value, record) => storage.setItem(key(value), record),
  }
}
export function readPlaytestTools(storage) {
  try {
    const v = JSON.parse(storage.getItem(TOWER_PLAYTEST_TOOLS_KEY))
    if (v && PLAYTEST_SPEEDS.includes(v.speed) && typeof v.invincible === 'boolean') {
      return { speed: v.speed, invincible: v.invincible }
    }
  } catch { /* Tool preferences never repair or replace a campaign record. */ }
  return { speed: 1, invincible: false }
}
export function savePlaytestTools(storage, tools) {
  if (!PLAYTEST_SPEEDS.includes(tools.speed) || typeof tools.invincible !== 'boolean') {
    throw new RangeError('Invalid playtest tools')
  }
  storage.setItem(TOWER_PLAYTEST_TOOLS_KEY, JSON.stringify({ speed: tools.speed, invincible: tools.invincible }))
}

// One live campaign; developer actions use the same atomic save contract.
export function towerStorage(storage) {
  return {
    allowPlaytestTools: true,
    getItem: key => storage.getItem(key),
    setItem: (key, record) => storage.setItem(key, record),
  }
}
