// Revision 43 pure weapon data. Affix values are percentage points in saves,
// except `attack` which is fixed attack points; modifiers are fractions.
// No RNG, counters, persistence or combat side effects
// are owned here. The caller supplies RNG and a unique instance ID.
import { OPEN_EQUIPMENT_TIERS, equipmentTier, isStarterEquipment } from './TowerEquipmentTiers.js'
import { EQUIPMENT_LORE } from './TowerEquipmentLore.js'
function freeze(value) {
  if (value && typeof value === 'object') {
    Object.values(value).forEach(freeze)
    Object.freeze(value)
  }
  return value
}
const rows = [
  ['fan', 1, [['suwen', '素问剑', 'general'], ['songfeng', '松风剑', 'qi'], ['shoushan', '守山剑', 'formation']]],
  ['fan', 2, [['guiyan', '归燕剑', 'general'], ['caiyun', '裁云剑', 'qi'], ['panxi', '磐溪剑', 'formation']]],
  ['fa', 3, [['liuquan', '流泉剑', 'general'], ['ningshuang', '凝霜剑', 'qi'], ['xingluo', '星罗剑', 'formation']]],
  ['fa', 4, [['lingxi', '灵犀剑', 'general'], ['zhaodan', '照胆剑', 'qi'], ['dingyue', '定岳剑', 'formation']]],
  ['bao', 1, [['qingxiao', '青霄剑', 'general'], ['zhufeng', '逐风剑', 'qi'], ['zhenyue', '镇岳剑', 'formation']]],
  ['bao', 2, [['tingyu', '听雨剑', 'general'], ['liuxia', '流霞剑', 'qi'], ['xuanjun', '玄钧剑', 'formation']]],
  ['ling', 3, [['jinghong', '惊鸿剑', 'general'], ['biluo', '碧落剑', 'qi'], ['tianshu', '天枢剑', 'formation']]],
  ['ling', 4, [['zhaoyuan', '照渊剑', 'qi'], ['taiheng', '太衡剑', 'formation']]],
]
export const WEAPONS = freeze([
  { id: 'eq_sword_iron', name: '普通铁剑', tier: 'fan', qualities: [0], tags: [], affinity: 'general', description: EQUIPMENT_LORE.eq_sword_iron },
  ...rows.flatMap(([tier, quality, entries]) => entries.map(([id, name, affinity]) => ({
    id: `eq_sword_${id}`, name, tier, qualities: [1, 2, 3, 4], tags: [], affinity, description: EQUIPMENT_LORE[`eq_sword_${id}`],
  }))),
])
const definitions = new Map(WEAPONS.map(w => [w.id, w]))
// Revision 62: all fixed attack and affixes fit the total equipment budget.
export const WEAPON_BASE_ATTACK = freeze({
  fan: [5, 6, 6.5, 7, 8], fa: [0, 10, 11, 12, 13],
  bao: [0, 20, 24, 28, 32], ling: [0, 70, 80, 90, 100],
})
export const WEAPON_AFFIX_RANGES = freeze({
  fan: [null,
    { A: [.1, .3], S: [.3, .7] }, { A: [.2, .4], S: [.4, 1] },
    { A: [.3, .5], S: [.5, 1], F: [.2, .5] }, { A: [.4, .6], S: [.6, 1.2], F: [.3, .7] }],
  fa: [null,
    { A: [.3, .5], S: [.5, 1] }, { A: [.4, .8], S: [.8, 1.5] },
    { A: [.5, 1], S: [1, 2], F: [.3, .7] }, { A: [.6, 1.2], S: [1.2, 2.5], F: [.5, 1] }],
  bao: [null,
    { A: [.4, .8], S: [.8, 1.5] }, { A: [.5, 1], S: [1, 2] },
    { A: [.6, 1.2], S: [1.2, 2.5], F: [.5, 1] }, { A: [.8, 1.5], S: [1.5, 3], F: [.7, 1.5] }],
  ling: [null,
    { A: [.5, 1], S: [1, 3] }, { A: [.7, 1.5], S: [1.5, 3.5] },
    { A: [1, 2], S: [2, 3], F: [.5, 1] }, { A: [1, 2], S: [2, 4], F: [1, 2] }],
})
export const WEAPON_ATTACK_REFERENCE = freeze(Object.fromEntries(
  OPEN_EQUIPMENT_TIERS.map(tier => [tier, equipmentTier(tier).referenceAttack])))
export const WEAPON_FIXED_ATTACK_RANGES = freeze(Object.fromEntries(
  Object.entries(WEAPON_AFFIX_RANGES).map(([tier, specs]) => [tier, specs.map(spec =>
    spec && spec.A.map(amount => Math.max(.1, Math.floor(amount * .008 * WEAPON_ATTACK_REFERENCE[tier] * 10 + 1e-8) / 10)))])))
const families = freeze({
  general: ['sj_yujian', 'sj_shadow'], qi: ['sj_arc', 'sj_line', 'sj_cross'], formation: ['sj_wanjian', 'sj_formation'],
})
const evolutionFamilies = freeze({
  evo_wanjian: 'sj_yujian', evo_tiandi: 'sj_line', evo_wuwo: 'sj_wanjian', evo_sixiang: 'sj_formation',
})
const skillNames = freeze({ sj_yujian: '御剑术', sj_shadow: '剑影分光', sj_arc: '剑气斩', sj_cross: '纵横剑气',
  sj_line: '一线天', sj_wanjian: '环剑诀', sj_formation: '两仪剑阵' })
const typeRange = freeze({ attack: 'A', physical: 'A', magic: 'A', skill: 'S', flow: 'F' })
const own = (o, key) => Object.prototype.hasOwnProperty.call(o, key)
const record = x => x !== null && typeof x === 'object' && !Array.isArray(x)
const exactKeys = (x, keys) => record(x) && Object.keys(x).length === keys.length && keys.every(k => own(x, k))
const integer = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi
const validId = id => typeof id === 'string' && id.trim().length > 0 && id === id.trim() && id !== 'iron'

function affixRange(spec, type, tier, quality) {
  const bounds = spec[typeRange[type]]
  if (!bounds) return null
  // Fixed points retain a margin for multiplication by other damage bonuses.
  return type === 'attack' ? WEAPON_FIXED_ATTACK_RANGES[tier][quality] : bounds
}

export function createIronWeapon() {
  // `locked` is a retired serialized field, with no gameplay or UI behavior.
  return { id: 'iron', definitionId: 'eq_sword_iron', tier: 'fan', quality: 0, refine: 0, locked: false, affixes: [] }
}

/** RNG must return [0,1); generated affix values use uniform inclusive 0.1 steps.
 * Duplicate identity/affixes are allowed. Instance ID uniqueness is the owner's
 * responsibility. Returned instances are mutable, independent plain JSON data.
 */
export function rollWeapon(tier, quality, random, instanceId) {
  if (!own(WEAPON_AFFIX_RANGES, tier) || !integer(quality, 1, 4) || typeof random !== 'function' || !validId(instanceId)) {
    throw new RangeError('Invalid weapon roll arguments')
  }
  const pick = choices => {
    const n = random()
    if (typeof n !== 'number' || !Number.isFinite(n) || n < 0 || n >= 1) throw new RangeError('Weapon RNG must return [0, 1)')
    return choices[Math.floor(n * choices.length)]
  }
  const definition = pick(WEAPONS.filter(w => w.tier === tier && w.qualities.includes(quality)))
  const spec = WEAPON_AFFIX_RANGES[tier][quality]
  const aType = pick(definition.affinity === 'formation' ? ['attack', 'physical', 'magic'] : ['attack', 'physical'])
  const roll = (type, target) => {
    const [min, max] = affixRange(spec, type, tier, quality)
    const lo = Math.round(min * 10), hi = Math.round(max * 10)
    const value = pick(Array.from({ length: hi - lo + 1 }, (_, i) => (lo + i) / 10))
    return { type, value, ...(target === undefined ? {} : { target }) }
  }
  const pool = families[definition.affinity]
  const firstTarget = pick(pool)
  const flow = () => roll('flow', definition.affinity === 'general' ? pick(['qi', 'formation']) : definition.affinity)
  const affixes = [roll(aType), roll('skill', firstTarget)]
  if (quality === 2 || quality === 4) affixes.push(roll('skill', pick(pool.filter(id => id !== firstTarget))))
  if (quality >= 3) affixes.push(flow())
  return { id: instanceId, definitionId: definition.id, tier, quality, refine: 0, locked: false, affixes }
}

/** Strict save-shape validation, including identity, legal slots, target pools,
 * tenth-point ranges. Affix order is immaterial.
 */
export function validateWeapon(instance) {
  if (!exactKeys(instance, ['id', 'definitionId', 'tier', 'quality', 'refine', 'locked', 'affixes'])) return false
  const d = definitions.get(instance.definitionId)
  if (!d || instance.tier !== d.tier || !d.qualities.includes(instance.quality)
    || instance.refine !== 0 || typeof instance.locked !== 'boolean' || !Array.isArray(instance.affixes)) return false
  if (isStarterEquipment(instance)) return instance.id === 'iron' && instance.refine === 0 && instance.affixes.length === 0
  if (!validId(instance.id) || instance.affixes.length !== [0, 2, 3, 3, 4][instance.quality]) return false
  const spec = WEAPON_AFFIX_RANGES[d.tier][instance.quality]
  const counts = {}, targets = new Set()
  for (const a of instance.affixes) {
    if (!record(a) || !own(typeRange, a.type)) return false
    const targeted = a.type === 'skill' || a.type === 'flow'
    if (!exactKeys(a, targeted ? ['type', 'value', 'target'] : ['type', 'value'])) return false
    if (typeof a.value !== 'number' || !Number.isFinite(a.value)
      || Math.abs(a.value * 10 - Math.round(a.value * 10)) > 1e-8) return false
    const range = affixRange(spec, a.type, d.tier, instance.quality)
    if (!range) return false
    if (a.value < range[0] || a.value > range[1]) return false
    if (a.type === 'magic' && d.affinity !== 'formation') return false
    if (a.type === 'skill') {
      if (!families[d.affinity].includes(a.target) || targets.has(a.target)) return false
      targets.add(a.target)
    }
    if (a.type === 'flow' && (!['qi', 'formation'].includes(a.target)
      || d.affinity !== 'general' && a.target !== d.affinity)) return false
    counts[a.type] = (counts[a.type] || 0) + 1
  }
  if ((counts.attack || 0) + (counts.physical || 0) + (counts.magic || 0) !== 1) return false
  const c = type => counts[type] || 0
  return c('skill') === (instance.quality === 2 || instance.quality === 4 ? 2 : 1)
    && c('flow') === (instance.quality >= 3 ? 1 : 0)
}
function checked(instance) {
  if (!validateWeapon(instance)) throw new RangeError('Invalid weapon instance')
  return definitions.get(instance.definitionId)
}
const zero = () => ({ flat: 0, critChance: 0, critBonus: 0, special: 0, lifesteal: 0 })
const decimal = n => Number(n.toFixed(12))

/** Fixed points added AFTER cultivation: 100 * cultivation + fixedAttack.
 * Includes fixed weapon base plus a rolled attack affix. Do not add
 * summary.baseAttack again; it is already included in this total.
 */
export function weaponFlatAttack(instance) {
  const d = checked(instance)
  return WEAPON_BASE_ATTACK[d.tier][instance.quality]
    + (instance.affixes.find(a => a.type === 'attack')?.value ?? 0)
}

/** Weapon-only additive coefficients. Crit/focus/lifesteal fields remain zero
 * for API compatibility; ring effects are supplied by TowerEquipment instead.
 * `hybrid` weights physical/magic A by 50%; S/F each apply once. Refinement is disabled.
 * Fixed points are excluded here; use weaponFlatAttack separately.
 */
export function weaponDamageModifiers(instance, skillId, damageType) {
  const d = checked(instance)
  if (!['physical', 'hybrid', 'magic', 'none'].includes(damageType) || typeof skillId !== 'string') {
    throw new RangeError('Invalid weapon damage query')
  }
  const result = zero()
  if (isStarterEquipment(instance) || damageType === 'none') return result
  const family = own(evolutionFamilies, skillId) ? evolutionFamilies[skillId] : skillId
  const flow = families.qi.includes(family) ? 'qi' : families.formation.includes(family) ? 'formation' : null
  for (const a of instance.affixes) {
    const v = a.value / 100
    if (a.type === 'physical' || a.type === 'magic') {
      if (damageType === a.type) result.flat += v
      else if (damageType === 'hybrid') result.flat += v / 2
    } else if (a.type === 'skill' && a.target === family || a.type === 'flow' && a.target === flow) result.flat += v
  }
  return Object.fromEntries(Object.entries(result).map(([k, v]) => [k, decimal(v)]))
}
const tierNames = Object.fromEntries(OPEN_EQUIPMENT_TIERS.map(t => [t, equipmentTier(t).name]))
const qualityNames = ['初始', '下品', '中品', '上品', '极品']
export function weaponName(instance) {
  const d = checked(instance)
  return isStarterEquipment(instance) ? `凡器·${d.name}` : `${tierNames[d.tier]}${qualityNames[instance.quality]}·${d.name}`
}
export function weaponDescription(instance) {
  const d = checked(instance)
  if (isStarterEquipment(instance)) return ['基础攻击＋5']
  const lines = instance.affixes.map(a => {
    const v = a.value
    switch (a.type) {
      case 'attack': return `攻击＋${v}`
      case 'physical': return `锋锐：物理伤害＋${v}%`
      case 'magic': return `灵蕴：法术伤害＋${v}%`
      case 'skill': return `${skillNames[a.target]}${Object.values(evolutionFamilies).includes(a.target) ? '及其进化' : ''}伤害＋${v}%`
      case 'flow': return `${a.target === 'qi' ? '剑气' : '剑阵'}流派伤害＋${v}%`
      default: throw new RangeError('Invalid affix')
    }
  })
  return [`基础攻击＋${WEAPON_BASE_ATTACK[d.tier][instance.quality]}`, ...lines]
}
/** Detached UI view. `fixedAttack` is the total fixed point bonus, including
 * iron's +5. `baseAttack` is the fixed tier/quality part of that total;
 * these are not additive. `refineBonus` stays zero while refinement is disabled. Learned-skill status
 * cannot be inferred from an instance; callers can match `skillTargets` against
 * the character's skill set without unlocking anything.
 */
export function weaponSummary(instance) {
  const d = checked(instance)
  return {
    id: instance.id, definitionId: d.id, name: weaponName(instance),
    tier: d.tier, tierName: tierNames[d.tier], quality: instance.quality, qualityName: qualityNames[instance.quality],
    affinity: d.affinity, tags: [...d.tags], description: d.description, refine: instance.refine, locked: instance.locked,
    baseAttack: WEAPON_BASE_ATTACK[d.tier][instance.quality],
    fixedAttack: weaponFlatAttack(instance),
    refineBonus: 0,
    skillTargets: instance.affixes.filter(a => a.type === 'skill').map(a => a.target),
    affixes: instance.affixes.map(a => ({ ...a })), lines: weaponDescription(instance),
  }
}
