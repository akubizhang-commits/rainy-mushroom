// Equipment rank is independent of rolled quality. Future ranks are metadata,
// never legal generation targets until their content and cultivation are ready.
const rows = [
  ['fan', '凡器', '白', '#E4E6E3', 1, '炼气初期', true],
  ['fa', '法器', '绿', '#329867', 4, '炼气中期', true],
  ['bao', '宝器', '蓝', '#358DCA', 10, '筑基初期', true],
  ['ling', '灵器', '紫', '#A376C7', 19, '金丹初期', true],
  ['fabao', '法宝', '橙', '#DB893B', null, '元婴', false],
  ['lingbao', '灵宝', '红', '#CD5655', null, '化神', false],
  ['xian', '仙器', '金', '#D5AF42', null, '炼虚', false],
  ['shen', '神器', '彩／幻金', '#EAD394', null, '大乘', false],
]
export const EQUIPMENT_TIERS = Object.freeze(rows.map(([id, name, colorName, color, minLevel, realm, available], index) =>
  Object.freeze({ id, name, colorName, color, minLevel, realm, available, order: index,
    referenceAttack: available ? 100 * 1.08 ** (minLevel - 1 - Math.floor((minLevel - 1) / 9))
      * 1.35 ** Math.floor((minLevel - 1) / 9) : null })))
export const OPEN_EQUIPMENT_TIERS = Object.freeze(EQUIPMENT_TIERS.filter(t => t.available).map(t => t.id))
const tiers = new Map(EQUIPMENT_TIERS.map(t => [t.id, t]))
export function equipmentTier(id) { return tiers.get(id) || null }
export function canUseEquipmentTier(id, level) {
  const tier = equipmentTier(id)
  return !!tier?.available && Number.isInteger(level) && level >= tier.minLevel
}
export function equipmentTierRequirement(id) {
  const tier = equipmentTier(id)
  return tier ? `${tier.realm}${tier.available ? '' : ' · 暂未开放'}` : '未知品阶'
}
export function isStarterEquipment(item) {
  return item?.quality === 0 && ['eq_sword_iron', 'eq_armor_basic', 'eq_ring_basic'].includes(item.definitionId)
}
// Reserved identities, not additional power tiers. No source issues these tags yet.
export const EQUIPMENT_TAGS = Object.freeze([
  Object.freeze({ id: 'natal', name: '本命法宝', available: false }),
  Object.freeze({ id: 'ancient', name: '古宝', available: false }),
  Object.freeze({ id: 'replica', name: '仿灵宝', available: false }),
  Object.freeze({ id: 'heavenly', name: '玄天宝', available: false }),
])
