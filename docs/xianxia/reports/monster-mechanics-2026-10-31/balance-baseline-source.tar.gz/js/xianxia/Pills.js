// Pure pill state at 60 simulation ticks/second. Callers own ruleset/card gating,
// tick advancement and stat refresh; no wall clock, XP banking or event emission.
export const PILLS = Object.freeze({
  pill_power: Object.freeze({
    index: 0,
    nameKey: 'card_pill_power',
    durationSec: 30,
    effects: Object.freeze({ damageMul: 2, moveSpeedMul: 1, damageTakenMul: 1 }),
    onTake: null,
  }),
  pill_wind: Object.freeze({
    index: 1,
    nameKey: 'card_pill_wind',
    durationSec: 30,
    effects: Object.freeze({ damageMul: 1, moveSpeedMul: 1.2, damageTakenMul: 1 }),
    onTake: 'attractSpores',
  }),
  pill_body: Object.freeze({
    index: 2,
    nameKey: 'card_pill_body',
    durationSec: 20,
    effects: Object.freeze({ damageMul: 1, moveSpeedMul: 1, damageTakenMul: 0.5 }),
    onTake: null,
  }),
})

const DEFINITIONS = Object.freeze(Object.values(PILLS))
const TICKS_PER_SECOND = 60

// Assign these fresh arrays to each world; world.simulationTick starts at zero.
export function makePillState() {
  return {
    pillEndTicks: new Float64Array(DEFINITIONS.length),
    pillTakenCounts: new Uint32Array(DEFINITIONS.length),
  }
}

// A successful take always refreshes to now + duration, including repeat wind pulls.
// The caller invokes this only for a committed card and refreshes stats on true.
export function takePill(world, id) {
  if (!Object.hasOwn(PILLS, id)) return false
  const def = PILLS[id]
  const tick = world.simulationTick
  const endTick = tick + def.durationSec * TICKS_PER_SECOND
  if (!Number.isSafeInteger(tick) || tick < 0 || !Number.isSafeInteger(endTick)) return false
  world.pillEndTicks[def.index] = endTick
  world.pillTakenCounts[def.index] += 1
  if (def.onTake === 'attractSpores') {
    for (let i = 0; i < world.spores.count; i += 1) world.spores.active[i].wind = true
  }
  return true
}

// Call at the start of the simulation step, before movement and damage.
// True means at least one deadline was cleared and cached stats need refreshing.
export function expirePills(world) {
  let changed = false
  for (const def of DEFINITIONS) {
    const end = world.pillEndTicks[def.index]
    if (end > 0 && world.simulationTick >= end) {
      world.pillEndTicks[def.index] = 0
      changed = true
    }
  }
  return changed
}

// Pure snapshot: a pill is inactive at its exact deadline even before cleanup.
export function pillModifiers(world) {
  const out = { damageMul: 1, moveSpeedMul: 1, damageTakenMul: 1 }
  for (const def of DEFINITIONS) {
    if (world.pillEndTicks[def.index] > world.simulationTick) {
      out.damageMul *= def.effects.damageMul
      out.moveSpeedMul *= def.effects.moveSpeedMul
      out.damageTakenMul *= def.effects.damageTakenMul
    }
  }
  return out
}
