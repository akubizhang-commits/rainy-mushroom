// MAP-1: gameplay geometry is authored separately from the background art.
// Only the central rectangle is walkable; painted buildings are not collision areas.
const WALKABLE_BOUNDS = Object.freeze({ xmin: -912, xmax: 978, ymin: -1140, ymax: 1020 })
export const COURTYARD = Object.freeze({
  id: 'courtyard-v1',
  source: Object.freeze({ width: 1248, height: 1664 }),
  worldScale: 3,
  origin: Object.freeze({ x: 624, y: 900 }),
  imageBounds: Object.freeze({ xmin: -1872, xmax: 1872, ymin: -2292, ymax: 2700 }),
  walkableSource: Object.freeze({ xmin: 320, xmax: 950, ymin: 560, ymax: 1280 }),
  bounds: WALKABLE_BOUNDS,
  walkableBounds: WALKABLE_BOUNDS,
  playerSpawn: Object.freeze({ x: 0, y: 0 }),
})

export function courtyardSourceToWorld(sx, sy) {
  return { x: (sx - COURTYARD.origin.x) * COURTYARD.worldScale,
    y: (COURTYARD.origin.y - sy) * COURTYARD.worldScale }
}

export function isCourtyard(world) {
  return world.ruleset === 'xianxia' && world.arena === COURTYARD.id
}

function clampAxis(value, min, max, inset) {
  if (min + inset > max - inset) return (min + max) / 2
  return Math.max(min + inset, Math.min(max - inset, value))
}

// Mutates and returns the entity. Oversized radii/viewport axes are centered.
export function clampToCourtyard(entity) {
  const b = COURTYARD.walkableBounds
  const r = Math.max(0, entity.r || 0)
  entity.x = clampAxis(entity.x, b.xmin, b.xmax, r)
  entity.y = clampAxis(entity.y, b.ymin, b.ymax, r)
  return entity
}

// Camera center and viewport dimensions are in world units.
export function courtyardCamera(x, y, width, height) {
  const b = COURTYARD.imageBounds
  return { x: clampAxis(x, b.xmin, b.xmax, Math.max(0, width) / 2),
    y: clampAxis(y, b.ymin, b.ymax, Math.max(0, height) / 2) }
}

// Preserve already-safe authored/test positions. Otherwise choose the closest safe
// candidate to the requested point, preferring off-camera positions. The projected
// point and 36 perimeter candidates bound the work and consume no random numbers.
export function courtyardSpawnPosition(world, x, y, r = 0) {
  const p = world.player
  const b = COURTYARD.walkableBounds
  const minimum = Math.max(300, (p.r || 0) + r + 120)
  const safe = (cx, cy) => Math.hypot(cx - p.x, cy - p.y) >= minimum
  const projected = clampToCourtyard({ x, y, r })
  if (projected.x === x && projected.y === y && safe(x, y)) return { x, y }
  const camera = courtyardCamera(p.x, p.y, world.viewport.width, world.viewport.height)
  const outside = (cx, cy) =>
    Math.abs(cx - camera.x) >= world.viewport.width / 2 + r ||
    Math.abs(cy - camera.y) >= world.viewport.height / 2 + r
  let best = null
  let bestOutside = false
  let bestDistance = Infinity
  const consider = (cx, cy) => {
    if (!safe(cx, cy)) return
    const offscreen = outside(cx, cy)
    const distance = (cx - x) ** 2 + (cy - y) ** 2
    if (!best || (offscreen && !bestOutside) || (offscreen === bestOutside && distance < bestDistance)) {
      best = { x: cx, y: cy }
      bestOutside = offscreen
      bestDistance = distance
    }
  }
  consider(projected.x, projected.y)
  const left = b.xmin + r, right = b.xmax - r
  const bottom = b.ymin + r, top = b.ymax - r
  for (let i = 0; i <= 8; i += 1) {
    const cx = left + (right - left) * i / 8
    const cy = bottom + (top - bottom) * i / 8
    consider(cx, bottom)
    consider(cx, top)
    consider(left, cy)
    consider(right, cy)
  }
  // Current enemy radii always fit and have a safe perimeter candidate.
  return best || { x: projected.x, y: projected.y }
}
